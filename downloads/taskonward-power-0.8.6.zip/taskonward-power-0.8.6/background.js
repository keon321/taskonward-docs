importScripts("config.js", "capture.js");

const CONFIG = globalThis.MEMORY_V5_POWER_CONFIG;
const AUTH_KEY = "memory_v5_power_auth";
const BACKEND_HEALTH_KEY = "memory_v5_backend_health";
const CONTINUITY_BINDING_PREFIX = "taskonward_continuity_binding:";
const RESUME_ARM_PREFIX = "taskonward_resume_arm:";
const RESUME_CLAIM_PREFIX = "taskonward_resume_claim:";
const RESUME_ARM_TTL_MS = 24 * 60 * 60_000;
const LOCAL_EMERGENCY_RECENT_MAX_BYTES = 16 * 1024;
const LOCAL_EMERGENCY_MAX_BYTES = 64 * 1024;
const CONVERSATION_RE = /\/c\/([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})(?:\/|$)/i;
const OFFSCREEN_PATH = "offscreen.html";
let offscreenCreating = null;
let clipboardCopyQueue = Promise.resolve();

function bytesToBase64Url(bytes) {
  let binary = "";
  for (const b of bytes) binary += String.fromCharCode(b);
  return btoa(binary)
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/g, "");
}

function randomUrlSafe(byteLength = 32) {
  const bytes = new Uint8Array(byteLength);
  crypto.getRandomValues(bytes);
  return bytesToBase64Url(bytes);
}

async function sha256UrlSafe(text) {
  const digest = await crypto.subtle.digest(
    "SHA-256",
    new TextEncoder().encode(text)
  );
  return bytesToBase64Url(new Uint8Array(digest));
}

function storageGet(keys) {
  return new Promise((resolve) => chrome.storage.local.get(keys, resolve));
}

function storageSet(values) {
  return new Promise((resolve) => chrome.storage.local.set(values, resolve));
}

function storageRemove(keys) {
  return new Promise((resolve) => chrome.storage.local.remove(keys, resolve));
}

function sessionStorageGet(keys) {
  return new Promise((resolve) => chrome.storage.session.get(keys, resolve));
}

function sessionStorageSet(values) {
  return new Promise((resolve) => chrome.storage.session.set(values, resolve));
}

function sessionStorageRemove(keys) {
  return new Promise((resolve) => chrome.storage.session.remove(keys, resolve));
}

async function fetchWithTimeout(url, options = {}, timeoutMs = 15000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, {
      ...options,
      signal: controller.signal,
    });
  } catch (error) {
    if (controller.signal.aborted) throw new Error("network_timeout");
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

function snapshotRecentMessages(snapshot) {
  return Array.isArray(snapshot?.recentMessages)
    ? snapshot.recentMessages.filter(
        (item) =>
          (item?.role === "user" || item?.role === "assistant") &&
          String(item?.content || "").trim()
      )
    : [];
}

function apiSnapshotUsable(snapshot) {
  return snapshot?.ok === true && snapshotRecentMessages(snapshot).length > 0;
}

function domSnapshotUsable(snapshot) {
  const messages = snapshotRecentMessages(snapshot);
  return (
    messages.some((item) => item.role === "user") &&
    messages.some((item) => item.role === "assistant")
  );
}

function normalizedCaptureText(value) {
  return String(value || "")
    .replace(/[\u200B-\u200D\uFEFF]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

function snapshotTailRelation(apiSnapshot, domSnapshot) {
  const apiTail = snapshotRecentMessages(apiSnapshot).at(-1);
  const domTail = snapshotRecentMessages(domSnapshot).at(-1);
  if (!apiTail || !domTail) return "unknown";

  if (
    apiTail.role &&
    domTail.role &&
    apiTail.role !== domTail.role
  ) {
    return "mismatch";
  }

  const apiWitness = apiSnapshot?.tailWitness;
  const domWitness = domSnapshot?.tailWitness;
  if (apiWitness && domWitness) {
    const apiId = String(apiWitness.id || "").trim();
    const domId = String(domWitness.id || "").trim();
    if (apiId && domId && apiId === domId) return "match";

    const apiHead = normalizedCaptureText(apiWitness.head);
    const domHead = normalizedCaptureText(domWitness.head);
    const apiTailText = normalizedCaptureText(apiWitness.tail);
    const domTailText = normalizedCaptureText(domWitness.tail);
    const apiLength = Number(apiWitness.length || 0);
    const domLength = Number(domWitness.length || 0);

    // Same head + API at least as long means the API is the same turn or a
    // newer superset of the click-time DOM witness. A materially shorter API
    // tail is stale even when both 8 KiB payload prefixes would look identical.
    if (apiHead && domHead && apiHead === domHead) {
      return apiLength + 64 >= domLength ? "match" : "mismatch";
    }
    if (
      apiLength === domLength &&
      apiTailText &&
      domTailText &&
      apiTailText === domTailText
    ) {
      return "match";
    }
  }

  const apiText = normalizedCaptureText(apiTail.content);
  const domText = normalizedCaptureText(domTail.content);
  if (!apiText || !domText) return "unknown";
  if (apiText === domText) return "match";

  const shorter = apiText.length <= domText.length ? apiText : domText;
  const longer = apiText.length > domText.length ? apiText : domText;
  if (shorter.length >= 16 && longer.includes(shorter)) return "match";

  return "mismatch";
}

async function collectDomConversationSnapshot(tabId) {
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      world: "ISOLATED",
      func: collectCurrentConversationOnDemand,
    });
    const snapshot = results?.[0]?.result;
    return snapshot && typeof snapshot === "object" ? snapshot : null;
  } catch {
    return null;
  }
}

async function collectApiConversationSnapshot(tabId, conversationId) {
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      world: "MAIN",
      func: collectChatGPTConversationApiOnDemand,
      args: [String(conversationId || "")],
    });
    const snapshot = results?.[0]?.result;
    return snapshot && typeof snapshot === "object"
      ? snapshot
      : { ok: false, reason: "api_capture_missing" };
  } catch (error) {
    return {
      ok: false,
      reason: "api_injection_failed:" + String(error?.message || error || "unknown"),
    };
  }
}

function apiCaptureRetryable(snapshot) {
  const reason = String(snapshot?.reason || "");
  return (
    /^(?:current_branch_empty|current_node_missing|current_branch_ambiguous)$/.test(
      reason,
    ) ||
    /^api_fetch_failed:/.test(reason) ||
    /^conversation_http_(?:408|409|425|429|5\d\d)$/.test(reason) ||
    /^api_injection_failed:/.test(reason)
  );
}

async function collectConversationSnapshot(tabId, conversationId) {
  if (!Number.isInteger(tabId)) throw new Error("tab_id_missing");

  // Freeze a lightweight DOM witness at click time while reading the
  // authoritative current_node branch. The DOM is a freshness witness and a
  // last-resort fallback; it is no longer allowed to silently override a newer
  // API snapshot or to make an old API snapshot look successful.
  const [domSnapshot, firstApiSnapshot] = await Promise.all([
    collectDomConversationSnapshot(tabId),
    collectApiConversationSnapshot(tabId, conversationId),
  ]);

  const apiFailures = [];
  let apiSnapshot = firstApiSnapshot;
  for (let attempt = 0; attempt < 3; attempt += 1) {
    if (attempt > 0) {
      await new Promise((resolve) =>
        setTimeout(resolve, attempt === 1 ? 90 : 240)
      );
      apiSnapshot = await collectApiConversationSnapshot(
        tabId,
        conversationId,
      );
    }

    if (apiSnapshotUsable(apiSnapshot)) {
      const relation = snapshotTailRelation(apiSnapshot, domSnapshot);
      if (relation !== "mismatch") {
        apiSnapshot.diagnostic = {
          ...(apiSnapshot.diagnostic || {}),
          source: "chatgpt_conversation_api",
          api_attempts: attempt + 1,
          dom_witness: relation,
        };
        return apiSnapshot;
      }
      apiFailures.push("api_tail_stale");
    } else {
      apiFailures.push(String(apiSnapshot?.reason || "api_capture_empty"));
      if (!apiCaptureRetryable(apiSnapshot)) break;
    }
  }

  let fallbackDom = domSnapshot;
  if (!domSnapshotUsable(fallbackDom)) {
    for (let attempt = 1; attempt < 3; attempt += 1) {
      await new Promise((resolve) =>
        setTimeout(resolve, attempt === 1 ? 80 : 200)
      );
      fallbackDom = await collectDomConversationSnapshot(tabId);
      if (domSnapshotUsable(fallbackDom)) break;
    }
  }

  if (domSnapshotUsable(fallbackDom)) {
    fallbackDom.diagnostic = {
      ...(fallbackDom.diagnostic || {}),
      source: "dom_fallback",
      api_failures: apiFailures.slice(-3),
    };
    return fallbackDom;
  }

  throw new Error(
    "conversation_capture_unavailable:" +
      (apiFailures.slice(-3).join(",") || "no_current_tail")
  );
}

async function verifyResumeTokenInTab(tabId, token) {
  if (!Number.isInteger(tabId) || !token) return false;
  const results = await chrome.scripting.executeScript({
    target: { tabId },
    world: "ISOLATED",
    func: verifyResumeTokenOnDemand,
    args: [String(token)],
  });
  return results?.[0]?.result === true;
}

function continuityBindingKey(conversationId) {
  return CONTINUITY_BINDING_PREFIX + conversationId;
}

async function getContinuityBinding(conversationId) {
  if (!conversationId) return null;
  const key = continuityBindingKey(conversationId);
  const values = await storageGet(key);
  const value = values[key];
  if (!value || typeof value !== "object") return null;
  if (typeof value.taskId !== "string" || !value.taskId) return null;
  return value;
}

async function setContinuityBinding(
  conversationId,
  taskId,
  titleSeed = ""
) {
  if (!conversationId || !taskId) throw new Error("binding_missing_identity");
  const value = {
    taskId: String(taskId),
    titleSeed: cleanTitleSeed(titleSeed),
    updatedAt: new Date().toISOString(),
  };
  await storageSet({ [continuityBindingKey(conversationId)]: value });
  return value;
}

async function clearContinuityBinding(conversationId) {
  if (!conversationId) return;
  await storageRemove(continuityBindingKey(conversationId));
}

function resumeArmKey(tabId) {
  return RESUME_ARM_PREFIX + String(tabId);
}

async function resumeArmGet(tabId) {
  if (!Number.isInteger(tabId)) return null;
  const key = resumeArmKey(tabId);
  const values = await sessionStorageGet(key);
  const value = values[key];
  if (!value || typeof value !== "object") return null;
  if (Number(value.expiresAt || 0) <= Date.now()) {
    await sessionStorageRemove(key);
    return null;
  }
  return value;
}

async function resumeArmSet(tabId, token) {
  if (!Number.isInteger(tabId) || !token) return null;
  const value = {
    token: String(token),
    armedAt: Date.now(),
    expiresAt: Date.now() + RESUME_ARM_TTL_MS,
  };
  await sessionStorageSet({ [resumeArmKey(tabId)]: value });
  return value;
}

async function resumeArmClear(tabId) {
  if (!Number.isInteger(tabId)) return;
  await sessionStorageRemove(resumeArmKey(tabId));
}

function resumeClaimKey(conversationId) {
  return RESUME_CLAIM_PREFIX + String(conversationId || "");
}

async function resumeClaimGet(conversationId) {
  if (!conversationId) return null;
  const key = resumeClaimKey(conversationId);
  const values = await storageGet(key);
  const value = values[key];
  if (!value || typeof value !== "object") return null;
  if (Number(value.expiresAt || 0) <= Date.now()) {
    await storageRemove(key);
    return null;
  }
  return value;
}

async function resumeClaimSet(conversationId, token) {
  if (!conversationId || !token) return null;
  const value = {
    token: String(token),
    claimedAt: Date.now(),
    expiresAt: Date.now() + RESUME_ARM_TTL_MS,
  };
  await storageSet({ [resumeClaimKey(conversationId)]: value });
  return value;
}

async function resumeClaimClear(conversationId) {
  if (!conversationId) return;
  await storageRemove(resumeClaimKey(conversationId));
}

function conversationIdFromUrl(url) {
  return String(url || "").match(CONVERSATION_RE)?.[1] ?? null;
}

function isTransientServiceError(value) {
  const text = String(value || "");
  return /service_quota_unavailable|service_unavailable|network_timeout|automatic_request_budget_exhausted|oauth_metadata_unavailable|authorization_server_metadata_unavailable|daily request limit|limit exceeded|error code\s*1027|http[_ -]?429|http[_ -]?5\d\d|failed to fetch/i.test(text);
}

function publicFailureMessage(message) {
  const text = String(message || "");
  if (isTransientServiceError(text)) {
    return "TaskOnward 暂时无法连接，请稍后重试。";
  }
  if (/auth|oauth|unauthor|forbidden/i.test(text)) {
    return "TaskOnward 登录状态需要更新，请重新登录后再试。";
  }
  if (/provisional_bootstrap_context_missing/i.test(text)) {
    return "当前 Chat 没有可恢复的任务内容。请回到原任务 Chat，或重新发送最近一次有效的 TaskOnward 续聊内容后再试。";
  }
  if (/legacy_handoff_recovery_required|provisional_handoff_requires_bootstrap/i.test(text)) {
    return "检测到旧版 Power 留下的未完成续聊，请更新 Power 后重新点击。";
  }
  if (/handoff_in_progress|handoff_refresh_conflict/i.test(text)) {
    return "已有续聊正在进行。请先在新 Chat 完成恢复；如果刚才恢复失败，再回当前 Chat 重试 Power。";
  }
  if (/continuity_anchors_incomplete/i.test(text)) {
    return "当前任务状态还没有保存完整，暂不能安全换 Chat。请先完成本次任务校准后再试。";
  }
  if (/conversation|chat|binding|handoff|lane|checkpoint|canonical|collector|capture|token/i.test(text)) {
    return "当前对话暂时无法可靠接续，请刷新页面后重试。";
  }
  return "TaskOnward 暂时无法完成这次操作，请重试。";
}

function externalFailure(error) {
  const message = String(error?.message || error || "unknown_error");
  return {
    ok: false,
    error: publicFailureMessage(message),
    degraded: isTransientServiceError(message),
  };
}

function utf8Bytes(text) {
  return new TextEncoder().encode(String(text || "")).byteLength;
}

function clipUtf8(text, maxBytes) {
  const value = String(text || "");
  if (utf8Bytes(value) <= maxBytes) return value;
  let low = 0;
  let high = value.length;
  while (low < high) {
    const mid = Math.ceil((low + high) / 2);
    if (utf8Bytes(value.slice(0, mid)) <= maxBytes) low = mid;
    else high = mid - 1;
  }
  return value.slice(0, low);
}

function containsHighConfidenceSecretText(value) {
  const text = String(value || "");
  return [
    /-----BEGIN(?: [A-Z0-9]+)? PRIVATE KEY-----/i,
    /\bsk-[A-Za-z0-9_-]{16,}\b/,
    /\bgh[pousr]_[A-Za-z0-9]{20,}\b/,
    /\bAKIA[0-9A-Z]{16}\b/,
    /\bAIza[0-9A-Za-z_-]{30,}\b/,
    /\bxox[baprs]-[A-Za-z0-9-]{16,}\b/,
    /\bBearer\s+[A-Za-z0-9._~+\/-]{20,}\b/i,
  ].some((pattern) => pattern.test(text));
}

async function backendHealthGet() {
  const value = (await storageGet(BACKEND_HEALTH_KEY))[BACKEND_HEALTH_KEY];
  return value && typeof value === "object" ? value : null;
}

async function backendHealthBlock(reason) {
  const normalized = String(reason || "service_unavailable");
  if (normalized !== "service_quota_unavailable") {
    await backendHealthClear();
    return null;
  }

  const now = Date.now();
  const value = {
    reason: normalized,
    blockedUntil: Date.UTC(
      new Date(now).getUTCFullYear(),
      new Date(now).getUTCMonth(),
      new Date(now).getUTCDate() + 1
    ),
    updatedAt: now,
  };
  await storageSet({ [BACKEND_HEALTH_KEY]: value });
  return value;
}

async function backendHealthClear() {
  await storageRemove(BACKEND_HEALTH_KEY);
}

async function assertBackendAvailable() {
  const health = await backendHealthGet();
  if (!health) return;

  if (
    String(health.reason || "") !== "service_quota_unavailable" ||
    Number(health.blockedUntil || 0) <= Date.now()
  ) {
    await backendHealthClear();
    return;
  }

  throw new Error("service_quota_unavailable");
}

async function backendFetch(url, options = {}) {
  try {
    return await fetchWithTimeout(url, options);
  } catch (error) {
    const message = String(error?.message || error || "network_timeout");
    if (isTransientServiceError(message)) {
      await backendHealthBlock("service_unavailable");
    }
    throw error;
  }
}

async function injectCurrentArchitecture(tabId) {
  await chrome.scripting.executeScript({
    target: { tabId },
    world: "ISOLATED",
    files: ["page_agent.js"],
  });
}

async function cleanupLegacyMainAgent(tabId) {
  await chrome.scripting.executeScript({
    target: { tabId },
    world: "MAIN",
    func: () => {
      try {
        window.__memoryV5PowerPageAgent?.stop?.();
      } catch {}
      try {
        delete window.__memoryV5PowerPageAgent;
      } catch {}
      document.getElementById("memory-v5-power-root")?.remove();
      document.getElementById("memory-v5-power-toast")?.remove();
      return true;
    },
  });
}

async function rehydrateOpenChatgptTabs(reason = "extension_reload") {
  const tabs = await chrome.tabs.query({ url: ["https://chatgpt.com/*"] });
  const results = [];

  for (const tab of tabs) {
    if (!Number.isInteger(tab.id)) continue;
    const tabId = tab.id;
    try {
      await cleanupLegacyMainAgent(tabId).catch(() => {});
      await injectCurrentArchitecture(tabId);

      let identityRecovered = false;
      const tabUrl = String(tab.url || "");
      const conversationId = conversationIdFromUrl(tabUrl);
      if (conversationId) {
        const arm = await resumeArmGet(tabId);
        if (arm?.token) {
          const attached = await attachArmedResumeForTab(
            tabId,
            tabUrl,
            cleanTitleSeed(tab.title || "")
          );
          identityRecovered = attached.status === "bound";
        }
      }

      results.push({
        tabId,
        ok: true,
        reinjected: true,
        identityRecovered,
        legacyMainCleaned: true,
      });
    } catch (error) {
      results.push({
        tabId,
        ok: false,
        error: String(error?.message || error),
      });
    }
  }

  await storageSet({
    memory_v5_power_last_rehydrate: {
      reason,
      at: new Date().toISOString(),
      results,
    },
  });
  return results;
}

async function oauthMetadata() {
  const issuer = String(CONFIG.authIssuer || "").replace(/\/$/, "");
  if (!issuer) throw new Error("oauth_issuer_not_configured");
  return {
    issuer,
    authorization_endpoint: issuer + "/oauth2/authorize",
    token_endpoint: issuer + "/oauth2/token",
  };
}

function authConfigKey() {
  return [
    String(CONFIG.authIssuer || "").replace(/\/$/, ""),
    String(CONFIG.oauthClientId || ""),
    String(CONFIG.resource || ""),
  ].join("|");
}

function authMatchesCurrentConfig(auth) {
  return Boolean(auth && auth.configKey === authConfigKey());
}

async function storedAuthForCurrentConfig() {
  const auth = (await storageGet(AUTH_KEY))[AUTH_KEY] ?? null;
  if (!auth) return null;
  if (authMatchesCurrentConfig(auth)) return auth;
  await storageRemove(AUTH_KEY);
  return null;
}

async function storeTokens(payload) {
  if (!payload?.access_token) throw new Error("oauth_token_missing");
  const stored = (await storageGet(AUTH_KEY))[AUTH_KEY] ?? {};
  const prior = authMatchesCurrentConfig(stored) ? stored : {};
  const expiresIn = Number(payload.expires_in ?? 3600);
  const auth = {
    accessToken: payload.access_token,
    refreshToken: payload.refresh_token ?? prior.refreshToken ?? null,
    expiresAt: Date.now() + Math.max(60, expiresIn) * 1000,
    scope: payload.scope ?? prior.scope ?? null,
    tokenType: payload.token_type ?? "Bearer",
    configKey: authConfigKey(),
  };
  await storageSet({ [AUTH_KEY]: auth });
  return auth;
}

async function refreshAuth() {
  const stored = await storedAuthForCurrentConfig();
  if (!stored?.refreshToken) throw new Error("auth_required");
  if (!CONFIG.oauthClientId) throw new Error("oauth_client_not_configured");

  const metadata = await oauthMetadata();
  const body = new URLSearchParams({
    grant_type: "refresh_token",
    client_id: CONFIG.oauthClientId,
    refresh_token: stored.refreshToken,
    resource: CONFIG.resource,
  });

  const response = await fetchWithTimeout(metadata.token_endpoint, {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body,
  });
  if (!response.ok) {
    if (response.status === 400 || response.status === 401) {
      await storageRemove(AUTH_KEY);
      throw new Error("auth_required");
    }
    if (response.status === 429) {
      await backendHealthBlock("service_quota_unavailable");
      throw new Error("service_quota_unavailable");
    }
    if (response.status >= 500) {
      await backendHealthBlock("service_unavailable");
      throw new Error("service_unavailable");
    }
    throw new Error("oauth_token_refresh_failed");
  }
  return storeTokens(await response.json());
}

async function accessToken() {
  const stored = await storedAuthForCurrentConfig();
  if (!stored?.accessToken) throw new Error("auth_required");
  if (Number(stored.expiresAt ?? 0) > Date.now() + 60_000) {
    return stored.accessToken;
  }
  const refreshed = await refreshAuth();
  return refreshed.accessToken;
}

async function login() {
  if (!CONFIG.oauthClientId) throw new Error("oauth_client_not_configured");

  const metadata = await oauthMetadata();
  const redirectUri = chrome.identity.getRedirectURL("memory-v5");
  const verifier = randomUrlSafe(48);
  const challenge = await sha256UrlSafe(verifier);
  const state = randomUrlSafe(24);

  const authorize = new URL(metadata.authorization_endpoint);
  authorize.searchParams.set("client_id", CONFIG.oauthClientId);
  authorize.searchParams.set("redirect_uri", redirectUri);
  authorize.searchParams.set("response_type", "code");
  authorize.searchParams.set("scope", CONFIG.scopes.join(" "));
  authorize.searchParams.set("code_challenge", challenge);
  authorize.searchParams.set("code_challenge_method", "S256");
  authorize.searchParams.set("state", state);
  authorize.searchParams.set("resource", CONFIG.resource);

  const redirected = await chrome.identity.launchWebAuthFlow({
    url: authorize.href,
    interactive: true,
  });
  if (!redirected) throw new Error("oauth_redirect_missing");

  const callback = new URL(redirected);
  if (callback.searchParams.get("state") !== state) {
    throw new Error("oauth_state_mismatch");
  }
  const callbackError = callback.searchParams.get("error");
  if (callbackError) throw new Error("oauth_" + callbackError);

  const code = callback.searchParams.get("code");
  if (!code) throw new Error("oauth_code_missing");

  const body = new URLSearchParams({
    grant_type: "authorization_code",
    client_id: CONFIG.oauthClientId,
    code,
    code_verifier: verifier,
    redirect_uri: redirectUri,
    resource: CONFIG.resource,
  });

  const response = await fetchWithTimeout(metadata.token_endpoint, {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body,
  });
  if (!response.ok) throw new Error("oauth_token_exchange_failed");
  const auth = await storeTokens(await response.json());
  return {
    authenticated: true,
    expiresAt: auth.expiresAt,
    redirectUri,
  };
}

async function companionFetch(path, payload, token) {
  try {
    return await backendFetch(CONFIG.apiBase.replace(/\/$/, "") + path, {
      method: "POST",
      headers: {
        authorization: "Bearer " + token,
        "content-type": "application/json",
      },
      body: JSON.stringify({
        ...payload,
        client_version: chrome.runtime.getManifest().version,
      }),
    });
  } catch (error) {
    if (isTransientServiceError(error?.message || error)) {
      await backendHealthBlock("service_unavailable");
    }
    throw error;
  }
}

async function companionPost(path, payload) {
  await assertBackendAvailable();
  let token = await accessToken();
  let response = await companionFetch(path, payload, token);

  if (response.status === 401) {
    const refreshed = await refreshAuth();
    token = refreshed.accessToken;
    response = await companionFetch(path, payload, token);
  }

  const text = await response.text();
  let data = null;
  try {
    data = text ? JSON.parse(text) : {};
  } catch {
    data = null;
  }

  if (!response.ok) {
    if (
      response.status === 429 ||
      /daily request limit|limit exceeded|error code\s*1027/i.test(text)
    ) {
      await backendHealthBlock("service_quota_unavailable");
      throw new Error("service_quota_unavailable");
    }
    if (response.status >= 500) {
      await backendHealthBlock("service_unavailable");
      throw new Error("service_unavailable");
    }
    throw new Error(data?.error || ("companion_http_" + response.status));
  }
  if (!data || typeof data !== "object") throw new Error("invalid_json");
  await backendHealthClear();
  return data;
}

async function ensureContinuityBinding(
  conversationId,
  titleSeed = ""
) {
  if (!conversationId) throw new Error("conversation_id_missing");
  const result = await companionPost(
    "/companion/continuity/binding/ensure",
    {
      source_conversation_id: conversationId,
      title_seed: cleanTitleSeed(titleSeed),
    }
  );
  const taskId =
    String(result?.task_id || result?.binding?.task_id || "").trim();
  if (!taskId) throw new Error("binding_ensure_failed");
  return setContinuityBinding(
    conversationId,
    taskId,
    titleSeed || result?.display_title || ""
  );
}

async function bindContinuityFromResumeToken({
  conversationId,
  token,
  titleSeed = "",
}) {
  if (!conversationId || !token) throw new Error("resume_code_incomplete");

  try {
    const result = await companionPost(
      "/companion/continuity/binding/from-handoff",
      {
        source_conversation_id: conversationId,
        token,
      }
    );
    const taskId =
      String(result?.task_id || result?.binding?.task_id || "").trim();
    if (!taskId) throw new Error("resume_code_invalid");
    return setContinuityBinding(
      conversationId,
      taskId,
      titleSeed || result?.display_title || ""
    );
  } catch (error) {
    if (String(error?.message || error) !== "handoff_not_found") {
      throw error;
    }

    // One release window of backward compatibility: validate an older
    // TaskOnward token through the legacy exact-binding proof, then start a new
    // lightweight task identity for the target Chat. No legacy semantic state
    // is copied into the new continuity path.
    await validateLegacyResumeToken({
      conversationId,
      token,
    });
    return ensureContinuityBinding(conversationId, titleSeed);
  }
}

async function validateLegacyResumeToken({
  conversationId,
  token,
}) {
  if (!conversationId || !token) throw new Error("resume_code_incomplete");
  const status = await companionPost("/companion/handoff/status", { token });
  const laneId = String(status?.lane_id || "");
  const savedVersion = Number(status?.snapshot_version);
  if (!laneId || !Number.isSafeInteger(savedVersion)) {
    throw new Error("resume_code_invalid");
  }
  const result = await companionPost(
    "/companion/binding/from-handoff",
    {
      source_conversation_id: conversationId,
      token,
      lane_id: laneId,
      snapshot_version: savedVersion,
    }
  );
  if (
    result?.status !== "ok" ||
    result?.lane_id !== laneId ||
    Number(result?.snapshot_version) !== savedVersion ||
    result?.binding?.lane_id !== laneId
  ) {
    throw new Error("handoff_binding_proof_mismatch");
  }
  return true;
}


function terminalResumeAttachError(value) {
  return /handoff_(?:not_found|expired|invalid_status|target_conflict|target_same_as_source|binding_proof_mismatch)|binding_conflict|resume_code_invalid/i.test(
    String(value || "")
  );
}

async function attachArmedResumeForTab(tabId, tabUrl, titleSeed = "") {
  if (!Number.isInteger(tabId)) return { status: "none" };
  const arm = await resumeArmGet(tabId);
  if (!arm?.token) return { status: "none" };
  const conversationId = conversationIdFromUrl(tabUrl);
  if (!conversationId) return { status: "waiting_for_conversation" };

  // A tab id can be reused or the user can navigate elsewhere after a failed
  // send. Never turn a tab-scoped arm into a durable Conversation claim until
  // the exact opaque resume token is visible in a user message in this Chat.
  let tokenVisible = false;
  try {
    tokenVisible = await verifyResumeTokenInTab(tabId, arm.token);
  } catch {
    tokenVisible = false;
  }
  if (!tokenVisible) {
    return { status: "waiting_for_token_evidence", conversationId };
  }

  // Persist the exact token -> Conversation claim before any network/auth work.
  // This survives service-worker restarts and lets a later explicit Power click
  // finish binding even if auth/network was unavailable during the first send.
  await resumeClaimSet(conversationId, arm.token);

  const auth = await authStatus();
  if (!auth.configured || !auth.authenticated) {
    return { status: "waiting_for_auth", conversationId };
  }

  try {
    const binding = await bindContinuityFromResumeToken({
      conversationId,
      token: arm.token,
      titleSeed,
    });
    await Promise.all([
      resumeArmClear(tabId),
      resumeClaimClear(conversationId),
    ]);
    return { status: "bound", binding };
  } catch (error) {
    const reason = String(error?.message || error);
    if (terminalResumeAttachError(reason)) {
      await Promise.all([
        resumeArmClear(tabId),
        resumeClaimClear(conversationId),
      ]);
      return { status: "terminal_error", reason };
    }
    return { status: "retryable_error", reason };
  }
}

async function authStatus() {
  const auth = await storedAuthForCurrentConfig();
  return {
    configured: Boolean(CONFIG.oauthClientId),
    authenticated: Boolean(auth?.accessToken || auth?.refreshToken),
    expiresAt: auth?.expiresAt ?? null,
    redirectUri: chrome.identity.getRedirectURL("memory-v5"),
    apiBase: CONFIG.apiBase,
  };
}

function looksLikeLocalEmergencyPackage(value) {
  const text = String(value || "");
  if (/TaskOnward\s*临时恢复编号\s*[:：]\s*[A-Za-z0-9_-]+/i.test(text)) {
    return true;
  }
  if (!/\[memory-v5-local-emergency\]/.test(text)) return false;
  return (
    /\[memory-v5-emergency-id:[^\]]+\]/.test(text) ||
    /@EmergencyId\s+\S+/.test(text) ||
    /【本地未同步用户请求】/.test(text) ||
    /这是本地(?:应急续聊|续聊恢复)包/.test(text)
  );
}

function cleanTitleSeed(value) {
  return String(value || "")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 120);
}

function isControlLikeSeed(value) {
  const text = String(value || "").trim();
  if (!text) return true;
  return /(?:memory-(?:v5-)?handoff|memory-(?:v5-)?lane|memory-control|devspace plain|先恢复并校准任务|恢复原对话上下文|确认任务目的.{0,20}当前主线|使用已连接的 (?:taskonward|memory v5)|待校准：power 自动建 lane|正式任务目的尚未)/i.test(text);
}

function conciseSeedPart(value, max = 42) {
  const text = cleanTitleSeed(value)
    .replace(/^[\s#>*\-–—:：]+/, "")
    .replace(/[。；;，,]+$/g, "")
    .trim();
  if (!text || isControlLikeSeed(text)) return "";
  return text.slice(0, max);
}

function continuationText(result) {
  const taskTitle =
    cleanTitleSeed(result?.display_title || result?.task_title || "") ||
    "TaskOnward";
  return [
    taskTitle + "|",
    "",
    "TaskOnward 续聊码：" + result.token,
    "",
    "请使用 TaskOnward 恢复这次任务交接。",
    "只根据 TaskOnward 返回的本次交接现场，简短说明：最近在做什么、刚做到哪里、下一步待做什么。不要补写或推断交接包里没有的历史。",
    "如果最后一条回复可能中断，请明确说明。",
    "如果恢复正确，请回复「确认」；如果不正确，直接指出需要修改的地方。",
    "我回复「确认」时无需再次调用 TaskOnward；这只表示确认这次交接正确，不代表授权你立即继续执行原任务。确认后请只告诉我已接回任务和当前下一步，然后等待我的下一条指令。",
  ].join("\n");
}

function normalizedEmergencyContent(value) {
  return String(value || "")
    .replace(/^\s*(?:纯文本|复制代码|Copy code|已分析|Analyzed)\s*$/gim, "")
    .replace(/\s+/g, " ")
    .trim();
}

function emergencyDedupCanonical(value) {
  return normalizedEmergencyContent(value)
    .replace(/(?:\s|\u00a0)*(?:\.\.\.|…)+\s*$/u, "")
    .trim();
}

function looksLikeInternalControlContent(value) {
  const text = String(value || "");
  if (looksLikeLocalEmergencyPackage(text)) return true;
  return [
    /\[memory-v5-(?:handoff|lane|version):[^\]]+\]/i,
    /\[memory-(?:handoff|lane):[^\]]+\]/i,
    /\[memory-control:sync:[^\]]+\]/i,
    /@(?:Lane|Version|EmergencyId)\s+\S+/i,
    /TaskOnward\s*续聊码\s*[:：]\s*[A-Za-z0-9_-]+/i,
    /(?:只)?使用已连接的\s*(?:TaskOnward|Memory V5 Beta)[\s\S]{0,240}(?:精确恢复|恢复并继续|handoff|Lane|checkpoint)/i,
  ].some((pattern) => pattern.test(text));
}

function publicEmergencyContent(value, maxBytes = 4 * 1024) {
  const text = String(value || "").trim();
  if (!text) return "（空）";
  if (containsHighConfidenceSecretText(text)) {
    return "（检测到敏感内容，正文已省略）";
  }
  if (looksLikeInternalControlContent(text)) {
    return "（这里是一条较早的 TaskOnward 接续指令，已省略。）";
  }
  return clipUtf8(text, maxBytes);
}

function emergencyMessageView(recentMessages) {
  const source = Array.isArray(recentMessages)
    ? recentMessages.slice(-8)
    : [];
  const messages = [];
  let overflowed = false;
  let sensitiveOmitted = 0;

  for (const item of source) {
    const role = String(item?.role || "");
    if (role !== "user" && role !== "assistant") continue;
    const raw = String(item?.content || "").trim();
    if (!raw) continue;
    if (looksLikeInternalControlContent(raw)) continue;
    if (containsHighConfidenceSecretText(raw)) {
      sensitiveOmitted += 1;
      continue;
    }

    const maxBytes = role === "assistant" ? 6 * 1024 : 4 * 1024;
    const content = clipUtf8(raw, maxBytes);
    if (!content) continue;
    if (utf8Bytes(raw) > utf8Bytes(content)) overflowed = true;
    messages.push({
      role,
      content,
      complete: role === "assistant" ? item?.complete !== false : true,
    });
  }

  return {
    messages,
    overflowed,
    sensitive_omitted: sensitiveOmitted,
  };
}

function localEmergencyContinuationText({
  view,
  emergencyFingerprint,
}) {
  const messages = Array.isArray(view?.messages) ? view.messages : [];
  const latestUser = [...messages]
    .reverse()
    .find((item) => item.role === "user");
  const latestRequest = latestUser
    ? publicEmergencyContent(latestUser.content, 4 * 1024)
    : "（没有读取到新的用户请求）";

  const dialogue = messages.length
    ? messages
        .map((item) => {
          const label =
            item.role === "user"
              ? "用户"
              : item.complete === false
                ? "ChatGPT（回答中）"
                : "ChatGPT";
          return label + "：" + publicEmergencyContent(
            item.content,
            item.role === "assistant" ? 6 * 1024 : 4 * 1024,
          );
        })
        .join("\n\n")
    : "（没有读取到可用的最近对话）";

  const warnings = [];
  if (view?.overflowed) {
    warnings.push("部分较长内容已缩短；无法确认的细节不要推断。");
  }
  if (Number(view?.sensitive_omitted || 0) > 0) {
    warnings.push("检测到敏感内容，相关正文没有复制。");
  }
  warnings.push("这份内容只代表本次 Power 点击实际读到的最近对话，不代表完整历史。");

  const text = [
    "TaskOnward 临时恢复",
    "",
    "TaskOnward 临时恢复编号：" + emergencyFingerprint,
    "",
    "TaskOnward 暂时无法连接。下面使用本次 Power 点击已经冻结的最近对话继续；服务恢复后，请重新使用 TaskOnward。",
    "",
    "【最近请求】",
    latestRequest,
    "",
    "【最近对话】",
    dialogue,
    "",
    "注意：" + warnings.join(" "),
    "",
    "请先根据以上内容继续，并把无法确认的部分明确说出来。",
  ].join("\n");
  return clipUtf8(text, LOCAL_EMERGENCY_MAX_BYTES);
}

async function copyLocalEmergency({
  recentMessages,
  conversationId,
  reason,
  normalContinuation = false,
}) {
  const view = emergencyMessageView(recentMessages);
  if (!view.messages.length) {
    return pageUi(
      "idle",
      "读取当前对话失败",
      "没有生成续聊内容。请稍后再点一次 Power。",
      true,
      { captureFailed: true }
    );
  }

  const emergencyFingerprint = (
    await sha256UrlSafe(JSON.stringify({
      sourceConversationId: String(conversationId || ""),
      messages: view.messages.map((item) => ({
        role: item.role,
        content: emergencyDedupCanonical(item.content),
        complete: item.complete !== false,
      })),
      overflowed: Boolean(view.overflowed),
      sensitiveOmitted: Number(view.sensitive_omitted || 0),
    }))
  ).slice(0, 24);

  const text = localEmergencyContinuationText({
    view,
    emergencyFingerprint,
  });
  await copyWithOffscreen(text);
  return pageUi(
    normalContinuation ? "locked" : "degraded",
    normalContinuation
      ? "已复制续聊信息"
      : "正式续聊暂不可用 · 已复制应急续聊内容",
    normalContinuation
      ? "请打开新 Chat 后粘贴发送。这次只使用刚刚读取到的最近内容。"
      : "新建 Chat 后可以临时粘贴继续；服务恢复后请重新使用 TaskOnward 继续。",
    false,
    {
      emergencyLocal: !normalContinuation,
      localContinuationCopied: normalContinuation,
      emergencyFingerprint,
      reason: String(reason || ""),
    }
  );
}

async function ensureOffscreenDocument() {
  const offscreenUrl = chrome.runtime.getURL(OFFSCREEN_PATH);
  const contexts = await chrome.runtime.getContexts({
    contextTypes: ["OFFSCREEN_DOCUMENT"],
    documentUrls: [offscreenUrl],
  });
  if (contexts.length > 0) return;

  if (!offscreenCreating) {
    offscreenCreating = chrome.offscreen.createDocument({
      url: OFFSCREEN_PATH,
      reasons: ["CLIPBOARD"],
      justification: "Copy the one-time TaskOnward handoff command without exposing it to the ChatGPT page.",
    }).finally(() => {
      offscreenCreating = null;
    });
  }
  await offscreenCreating;
}

async function copyWithOffscreenOnce(text) {
  await ensureOffscreenDocument();
  try {
    const response = await chrome.runtime.sendMessage({
      target: "offscreen",
      type: "OFFSCREEN_COPY",
      text: String(text || ""),
    });
    if (!response?.ok) throw new Error(response?.error || "clipboard_copy_failed");
    return true;
  } finally {
    await chrome.offscreen.closeDocument().catch(() => {});
  }
}

function copyWithOffscreen(text) {
  const operation = clipboardCopyQueue.then(() => copyWithOffscreenOnce(text));
  clipboardCopyQueue = operation.catch(() => {});
  return operation;
}

function pageUi(state, title = "", toast = "", toastError = false, extra = {}) {
  return { state, title, toast, toastError, ...extra };
}

function exactResumePendingUi(reason = "service_unavailable") {
  return pageUi(
    "degraded",
    "续聊身份已保存",
    "TaskOnward 暂时无法完成精确恢复；续聊身份已保留。网络或登录恢复后重新点击 Power 即可继续，不会改成新任务。",
    false,
    {
      exactResumePending: true,
      retryReason: String(reason || "service_unavailable"),
    }
  );
}

async function prebindClaimedResumeBeforeCapture({
  conversationId,
  titleSeed = "",
}) {
  const claimedResume = await resumeClaimGet(conversationId);
  if (!claimedResume?.token) return { status: "none" };

  let auth = await authStatus();
  if (!auth.configured || !auth.authenticated) {
    try {
      await login();
      auth = await authStatus();
    } catch {
      return {
        status: "pending",
        ui: exactResumePendingUi("auth_unavailable"),
      };
    }
  }

  try {
    const binding = await bindContinuityFromResumeToken({
      conversationId,
      token: claimedResume.token,
      titleSeed,
    });
    await resumeClaimClear(conversationId);
    return { status: "bound", binding };
  } catch (error) {
    const reason = String(error?.message || error);
    if (isTransientServiceError(reason)) {
      return { status: "pending", ui: exactResumePendingUi(reason) };
    }
    if (terminalResumeAttachError(reason)) {
      await resumeClaimClear(conversationId);
      throw error;
    }
    return { status: "pending", ui: exactResumePendingUi(reason) };
  }
}

async function handlePowerActivate(message, sender = {}) {
  const tabId = sender?.tab?.id;
  const tabUrl = String(sender?.tab?.url || "");
  if (!Number.isInteger(tabId) || !tabUrl.startsWith("https://chatgpt.com/")) {
    throw new Error("power_activation_requires_chatgpt_tab");
  }

  const runtimeVersion = chrome.runtime.getManifest().version;
  if (String(message?.pageVersion || "") !== runtimeVersion) {
    await injectCurrentArchitecture(tabId);
    return pageUi(
      "idle",
      "TaskOnward 已更新",
      "页面按钮已更新到 " + runtimeVersion + "，请再点一次 Power。"
    );
  }

  const conversationId = conversationIdFromUrl(tabUrl);
  if (!conversationId) {
    return pageUi(
      "idle",
      "当前还没有可接续的 Chat",
      "先在 ChatGPT 中发送至少一条消息，等当前 Chat 获得正式地址后再点 Power。"
    );
  }

  // Exact recovery identity is more important than transcript capture. A
  // durable Conversation claim was written when the continuation code was
  // pasted. Bind that exact task first, before any DOM collection, so a
  // transient/virtualized ChatGPT page cannot strand the recovery identity.
  const preboundResume = await prebindClaimedResumeBeforeCapture({
    conversationId,
    titleSeed: cleanTitleSeed(sender?.tab?.title || ""),
  });
  if (preboundResume.status === "pending") {
    return preboundResume.ui;
  }

  let snapshot;
  try {
    snapshot = await collectConversationSnapshot(tabId, conversationId);
  } catch (error) {
    return pageUi(
      "idle",
      "读取当前对话失败",
      "没有生成续聊内容。请稍后再点一次 Power。",
      true,
      {
        captureFailed: true,
        captureReason: String(error?.message || error || "unknown"),
      }
    );
  }

  const pathname = (() => {
    try {
      return new URL(tabUrl).pathname;
    } catch {
      return "";
    }
  })();

  const primaryRecentMessages = snapshotRecentMessages(snapshot);

  const trustedMessage = {
    type: "POWER_PAGE_CLICK",
    pageVersion: runtimeVersion,
    context: {
      conversationId,
      titleSeed: cleanTitleSeed(sender?.tab?.title || ""),
      pathname,
    },
    recentMessages: primaryRecentMessages,
    captureDiagnostic: {
      ...(snapshot.diagnostic || {}),
      generation_in_progress: snapshot.generationInProgress === true,
      source: snapshot?.diagnostic?.source || "unknown",
    },
  };

  const result = await pageClickLite(trustedMessage, sender);
  if (result?.state === "locked" && snapshot.recentMessagesTruncated) {
    return {
      ...result,
      detail:
        String(result.detail || "") +
        " 较早内容未包含在本次有界交接中。",
      warning: true,
    };
  }
  return result;
}

function localEmergencyOrRequest({
  recentMessages,
  conversationId,
  reason,
}) {
  if (!Array.isArray(recentMessages) || !recentMessages.length) {
    return pageUi(
      "idle",
      "读取当前对话失败",
      "没有生成续聊内容。请稍后再点一次 Power。",
      true,
      { captureFailed: true }
    );
  }
  return copyLocalEmergency({
    recentMessages,
    conversationId,
    reason,
  });
}

async function pageClickLite(message, sender = {}) {
  const context = message.context || {};
  const conversationId = context.conversationId || null;
  if (!conversationId) {
    return pageUi("idle", "当前还没有可接续的 Chat");
  }

  const recentMessages = Array.isArray(message.recentMessages)
    ? message.recentMessages.filter(
        (item) =>
          (item?.role === "user" || item?.role === "assistant") &&
          String(item?.content || "").trim()
      )
    : [];
  if (!recentMessages.length) {
    return pageUi(
      "idle",
      "读取当前对话失败",
      "没有生成续聊内容。请稍后再点一次 Power。",
      true,
      { captureFailed: true }
    );
  }

  const handoffRecentMessages = recentMessages;

  let binding = await getContinuityBinding(conversationId);
  const claimedResume = await resumeClaimGet(conversationId);
  const armedResume = Number.isInteger(sender?.tab?.id)
    ? await resumeArmGet(sender.tab.id)
    : null;

  let resumeToken = String(claimedResume?.token || "").trim();
  if (!resumeToken && !binding?.taskId && armedResume?.token) {
    let witnessed = false;
    try {
      witnessed = await verifyResumeTokenInTab(
        sender.tab.id,
        armedResume.token
      );
    } catch {
      witnessed = false;
    }
    if (witnessed) {
      await resumeClaimSet(conversationId, armedResume.token);
      await resumeArmClear(sender.tab.id);
      resumeToken = armedResume.token;
    }
  }

  const health = await backendHealthGet();
  if (
    health &&
    String(health.reason || "") === "service_quota_unavailable" &&
    Number(health.blockedUntil || 0) > Date.now()
  ) {
    if (resumeToken) {
      return exactResumePendingUi("service_quota_unavailable");
    }
    return localEmergencyOrRequest({
      recentMessages,
      conversationId,
      reason: "service_quota_unavailable",
    });
  } else if (health) {
    await backendHealthClear();
  }

  let auth = await authStatus();
  if (!auth.configured || !auth.authenticated) {
    try {
      await login();
      auth = await authStatus();
    } catch (error) {
      if (resumeToken) return exactResumePendingUi("auth_unavailable");
      return localEmergencyOrRequest({
        recentMessages,
        conversationId,
        reason: "auth_unavailable:" + String(error?.message || error),
      });
    }
  }

  if (resumeToken && !binding?.taskId) {
    await resumeClaimSet(conversationId, resumeToken);
    try {
      binding = await bindContinuityFromResumeToken({
        conversationId,
        token: resumeToken,
        titleSeed: context.titleSeed || "",
      });
      await resumeClaimClear(conversationId);
      if (Number.isInteger(sender?.tab?.id)) {
        await resumeArmClear(sender.tab.id);
      }
    } catch (error) {
      const reason = String(error?.message || error);
      if (isTransientServiceError(reason)) {
        return exactResumePendingUi(reason);
      }
      if (terminalResumeAttachError(reason)) {
        await resumeClaimClear(conversationId);
        if (Number.isInteger(sender?.tab?.id)) {
          await resumeArmClear(sender.tab.id);
        }
        throw error;
      }
      return exactResumePendingUi(reason);
    }
  }

  if (!binding?.taskId) {
    try {
      binding = await ensureContinuityBinding(
        conversationId,
        context.titleSeed || ""
      );
    } catch (error) {
      if (isTransientServiceError(error?.message || error)) {
        return localEmergencyOrRequest({
          recentMessages,
          conversationId,
          reason: String(error?.message || error),
        });
      }
      throw error;
    }
  }

  const prepare = () =>
    companionPost("/companion/continuity/handoff/prepare", {
      task_id: binding.taskId,
      source_conversation_id: conversationId,
      title_seed: context.titleSeed || binding.titleSeed || "",
      recent_messages: handoffRecentMessages,
    });

  let prepared;
  try {
    prepared = await prepare();
  } catch (error) {
    const reason = String(error?.message || error);
    if (
      reason === "binding_conflict" ||
      reason === "binding_missing" ||
      reason === "task_not_found"
    ) {
      await clearContinuityBinding(conversationId);
      binding = await ensureContinuityBinding(
        conversationId,
        context.titleSeed || ""
      );
      prepared = await prepare();
    } else if (reason === "handoff_context_missing") {
      return copyLocalEmergency({
        recentMessages,
        conversationId,
        reason,
        normalContinuation: true,
      });
    } else if (reason === "source_conversation_retired") {
      return pageUi(
        "idle",
        "此窗口已完成交接",
        "请继续使用已经接回任务的新 Chat。旧窗口不会重新成为主线。",
        false,
        { sourceConversationRetired: true }
      );
    } else if (isTransientServiceError(reason)) {
      return localEmergencyOrRequest({
        recentMessages,
        conversationId,
        reason,
      });
    } else {
      throw error;
    }
  }

  const text = continuationText(prepared);
  await copyWithOffscreen(text);

  const warnings = [];
  if (prepared.context_truncated) {
    warnings.push("较早内容已按上限截去");
  }
  if (Number(prepared.sensitive_omitted || 0) > 0) {
    warnings.push("敏感内容未上传");
  }
  const suffix = warnings.length ? "；" + warnings.join("；") + "。" : "。";

  return pageUi(
    "locked",
    "已保存，续聊内容已复制",
    "续聊内容已复制；已带上最近 " +
      Number(prepared.message_count || handoffRecentMessages.length || 0) +
      " 条对话" +
      suffix,
    false,
    {
      handoffCopied: true,
      mode: "continuity_lite",
    }
  );
}

async function handle(message, sender = {}) {
  if (!message || typeof message.type !== "string") {
    throw new Error("invalid_message");
  }

  if (message.type === "POWER_ACTIVATE") {
    return handlePowerActivate(message, sender);
  }
  if (message.type === "POWER_POPUP_ACTIVATE") {
    const [activeTab] = await chrome.tabs.query({
      active: true,
      currentWindow: true,
    });
    if (
      !activeTab?.id ||
      !String(activeTab.url || "").startsWith("https://chatgpt.com/")
    ) {
      return pageUi(
        "idle",
        "当前不是 ChatGPT",
        "请先切到需要续聊的 ChatGPT 对话，再点击这里。"
      );
    }
    return handlePowerActivate(
      {
        type: "POWER_ACTIVATE",
        pageVersion: chrome.runtime.getManifest().version,
      },
      { tab: activeTab }
    );
  }
  if (message.type === "POWER_RESUME_ARM") {
    const tabId = sender?.tab?.id;
    const token = String(message?.token || "").trim();
    if (!Number.isInteger(tabId) || !/^(?:to|mh)_[A-Za-z0-9_-]+$/.test(token)) {
      throw new Error("resume_arm_invalid");
    }
    // Record the exact opaque token locally only; never touch the network on
    // paste. If ChatGPT has already assigned this tab a Conversation URL, the
    // paste itself is enough to durably associate the token with that exact
    // Conversation so extension reloads / DOM virtualization cannot erase the
    // recovery identity before the next explicit Power click. Root/new-chat
    // pages still use the short-lived tab arm until a Conversation URL exists.
    await resumeArmSet(tabId, token);
    const pastedConversationId = conversationIdFromUrl(sender?.tab?.url || "");
    if (pastedConversationId) {
      await resumeClaimSet(pastedConversationId, token);
    }
    return {
      state: "idle",
      resumeArmed: true,
      resumeClaimed: Boolean(pastedConversationId),
    };
  }
  if (message.type === "POWER_AUTH_STATUS") return authStatus();
  if (message.type === "POWER_AUTH_LOGIN") return login();
  if (message.type === "POWER_AUTH_LOGOUT") {
    await storageRemove(AUTH_KEY);
    return { authenticated: false };
  }

  throw new Error("unknown_message_type");
}

chrome.runtime.onInstalled.addListener((details) => {
  chrome.offscreen.closeDocument().catch(() => {}).finally(() => {
    rehydrateOpenChatgptTabs(details?.reason || "onInstalled").catch(() => {});
  });
});

chrome.runtime.onStartup?.addListener?.(() => {
  chrome.offscreen.closeDocument().catch(() => {}).finally(() => {
    rehydrateOpenChatgptTabs("onStartup").catch(() => {});
  });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.target === "offscreen") return false;

  handle(message, sender)
    .then((data) => sendResponse({ ok: true, data }))
    .catch((error) => sendResponse(externalFailure(error)));
  return true;
});

// Identity-only route hook. It does nothing unless this tab was explicitly
// armed by pasting a TaskOnward continuation code. URL assignment and the
// eventual "complete" event each provide a one-shot chance to verify that the
// exact token is now visible in the target Conversation and bind it durably.
// No page-side polling/timer is needed.
chrome.tabs?.onUpdated?.addListener?.((tabId, changeInfo, tab) => {
  if (!changeInfo?.url && changeInfo?.status !== "complete") return;
  const tabUrl = String(changeInfo?.url || tab?.url || "");
  if (!tabUrl.startsWith("https://chatgpt.com/")) return;
  attachArmedResumeForTab(
    tabId,
    tabUrl,
    cleanTitleSeed(tab?.title || "")
  ).catch(() => {});
});
