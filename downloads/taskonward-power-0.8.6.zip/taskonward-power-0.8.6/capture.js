// TaskOnward Power one-shot ChatGPT capture routines.
// Each collector is self-contained because chrome.scripting.executeScript
// serializes the injected function without module closures. Normal ChatGPT use
// never calls these functions; they run only after an explicit Power click.

async function collectChatGPTConversationApiOnDemand(conversationId) {
  const id = String(conversationId || "").trim();
  if (!id) return { ok: false, reason: "conversation_id_missing" };

  const MAX_RECENT_MESSAGES = 14;
  const MAX_MESSAGE_BYTES = 8 * 1024;
  const MAX_TOTAL_BYTES = 56 * 1024;

  function clip(text, maxBytes) {
    const value = String(text || "").trim();
    if (!value) return { text: "", truncated: false };
    const encoder = new TextEncoder();
    if (encoder.encode(value).byteLength <= maxBytes) {
      return { text: value, truncated: false };
    }
    let low = 0;
    let high = value.length;
    while (low < high) {
      const mid = Math.ceil((low + high) / 2);
      if (encoder.encode(value.slice(0, mid)).byteLength <= maxBytes) {
        low = mid;
      } else {
        high = mid - 1;
      }
    }
    return { text: value.slice(0, low).trim(), truncated: true };
  }

  function contentText(value) {
    if (typeof value === "string") return value;
    if (Array.isArray(value)) {
      return value.map(contentText).filter(Boolean).join("\n");
    }
    if (!value || typeof value !== "object") return "";
    if (Array.isArray(value.parts)) {
      return value.parts.map(contentText).filter(Boolean).join("\n");
    }
    if (typeof value.text === "string") return value.text;
    if (typeof value.content === "string") return value.content;
    if (Array.isArray(value.content)) {
      return value.content.map(contentText).filter(Boolean).join("\n");
    }
    if (value.content && typeof value.content === "object") {
      return contentText(value.content);
    }
    if (typeof value.value === "string") return value.value;
    return "";
  }

  function messageText(message) {
    return contentText(message?.content).trim();
  }

  function assistantComplete(message) {
    if (!message || typeof message !== "object") return false;
    if (message.end_turn === false) return false;
    const status = String(message.status || "").toLowerCase();
    return !(
      status.includes("in_progress") ||
      status.includes("stream") ||
      status.includes("interrupted")
    );
  }

  function witness(item) {
    const normalized = String(item?.content || "")
      .replace(/[\u200B-\u200D\uFEFF]/g, "")
      .replace(/\s+/g, " ")
      .trim();
    return {
      id: String(item?.id || ""),
      role: String(item?.role || ""),
      length: normalized.length,
      head: normalized.slice(0, 256),
      tail: normalized.slice(-256),
    };
  }

  try {
    let accessToken = "";
    let sessionReason = "";
    try {
      const sessionResponse = await fetch("/api/auth/session", {
        method: "GET",
        credentials: "include",
        cache: "no-store",
      });
      if (sessionResponse.ok) {
        const session = await sessionResponse.json();
        accessToken = String(session?.accessToken || "");
        if (!accessToken) sessionReason = "session_token_missing";
      } else {
        sessionReason = "session_http_" + sessionResponse.status;
      }
    } catch (error) {
      sessionReason =
        "session_fetch_failed:" + String(error?.name || "unknown");
    }

    const requestConversation = async (withBearer) => {
      const headers =
        withBearer && accessToken
          ? { Authorization: "Bearer " + accessToken }
          : undefined;
      return fetch(
        "/backend-api/conversation/" + encodeURIComponent(id),
        {
          method: "GET",
          credentials: "include",
          cache: "no-store",
          ...(headers ? { headers } : {}),
        }
      );
    };

    let authMode = accessToken ? "bearer" : "cookie";
    let response = await requestConversation(Boolean(accessToken));
    if (
      accessToken &&
      (response.status === 401 || response.status === 403)
    ) {
      authMode = "cookie_fallback";
      response = await requestConversation(false);
    }
    if (!response.ok) {
      return {
        ok: false,
        reason: "conversation_http_" + response.status,
        session_reason: sessionReason,
      };
    }

    const data = await response.json();
    const mapping =
      data?.mapping && typeof data.mapping === "object"
        ? data.mapping
        : {};

    let currentNodeId =
      typeof data?.current_node === "string" && mapping[data.current_node]
        ? data.current_node
        : null;

    if (!currentNodeId) {
      const leaves = Object.entries(mapping).filter(
        ([, node]) =>
          !Array.isArray(node?.children) || node.children.length === 0
      );
      if (leaves.length === 1) {
        currentNodeId = leaves[0][0];
      } else {
        return {
          ok: false,
          reason:
            leaves.length > 1
              ? "current_branch_ambiguous"
              : "current_node_missing",
          session_reason: sessionReason,
        };
      }
    }

    const branchNodes = [];
    const seen = new Set();
    let cursor = currentNodeId;
    while (cursor && mapping[cursor] && !seen.has(cursor)) {
      seen.add(cursor);
      branchNodes.push(mapping[cursor]);
      cursor =
        typeof mapping[cursor]?.parent === "string"
          ? mapping[cursor].parent
          : null;
    }
    branchNodes.reverse();

    const branchMessages = [];
    for (const node of branchNodes) {
      const message = node?.message;
      const role = String(message?.author?.role || "");
      if (role !== "user" && role !== "assistant") continue;
      const content = messageText(message);
      if (!content) continue;
      branchMessages.push({
        role,
        id: String(message?.id || node?.id || ""),
        content,
        complete:
          role === "assistant" ? assistantComplete(message) : true,
      });
    }

    if (!branchMessages.length) {
      return {
        ok: false,
        reason: "current_branch_empty",
        session_reason: sessionReason,
      };
    }

    const recentMessages = [];
    let truncated = branchMessages.length > MAX_RECENT_MESSAGES;
    for (const item of branchMessages.slice(-MAX_RECENT_MESSAGES)) {
      const clipped = clip(item.content, MAX_MESSAGE_BYTES);
      if (!clipped.text) continue;
      truncated ||= clipped.truncated;
      recentMessages.push({
        role: item.role,
        id: item.id,
        content: clipped.text,
        complete:
          item.role === "assistant"
            ? item.complete !== false && !clipped.truncated
            : true,
      });
    }

    const encoder = new TextEncoder();
    while (
      recentMessages.length > 1 &&
      encoder.encode(JSON.stringify(recentMessages)).byteLength >
        MAX_TOTAL_BYTES
    ) {
      recentMessages.shift();
      truncated = true;
    }

    const last = recentMessages.at(-1);
    return {
      ok: recentMessages.length > 0,
      generationInProgress:
        last?.role === "assistant" && last?.complete === false,
      recentMessages,
      recentMessagesTruncated: truncated,
      tailWitness: witness(branchMessages.at(-1)),
      diagnostic: {
        source: "chatgpt_conversation_api",
        auth_mode: authMode,
        session_reason: sessionReason,
        current_node: currentNodeId,
        branch_messages: branchMessages.length,
        captured_messages: recentMessages.length,
      },
    };
  } catch (error) {
    return {
      ok: false,
      reason:
        "api_fetch_failed:" +
        String(error?.name || error?.message || "unknown"),
    };
  }
}

function collectCurrentConversationOnDemand() {
  const MAX_RECENT_MESSAGES = 14;
  const MAX_MESSAGE_BYTES = 8 * 1024;
  const MAX_TOTAL_BYTES = 56 * 1024;

  function clip(text, maxBytes) {
    const value = String(text || "").trim();
    if (!value) return { text: "", truncated: false };
    const encoder = new TextEncoder();
    if (encoder.encode(value).byteLength <= maxBytes) {
      return { text: value, truncated: false };
    }
    let low = 0;
    let high = value.length;
    while (low < high) {
      const mid = Math.ceil((low + high) / 2);
      if (encoder.encode(value.slice(0, mid)).byteLength <= maxBytes) {
        low = mid;
      } else {
        high = mid - 1;
      }
    }
    return { text: value.slice(0, low).trim(), truncated: true };
  }

  function textOf(node) {
    return String(node?.textContent || "").trim();
  }

  function canonicalTurn(node) {
    return (
      node?.closest?.("[data-testid^='conversation-turn-']") ||
      node ||
      null
    );
  }

  function stableTurnId(node, role, index, content) {
    const explicit = node?.matches?.("[data-message-author-role]")
      ? node
      : node?.querySelector?.("[data-message-author-role]");
    const direct =
      explicit?.getAttribute?.("data-message-id") ||
      node?.getAttribute?.("data-message-id") ||
      canonicalTurn(node)?.getAttribute?.("data-testid") ||
      "";
    if (direct) return String(direct).slice(0, 200);

    let hash = 2166136261;
    const value =
      role + "\n" + String(index) + "\n" + String(content || "");
    for (let i = 0; i < value.length; i += 1) {
      hash ^= value.charCodeAt(i);
      hash = Math.imul(hash, 16777619);
    }
    return (
      "local_" +
      role +
      "_" +
      index +
      "_" +
      (hash >>> 0).toString(36)
    ).slice(0, 200);
  }

  function witness(id, role, raw) {
    const normalized = String(raw || "")
      .replace(/[\u200B-\u200D\uFEFF]/g, "")
      .replace(/\s+/g, " ")
      .trim();
    return {
      id: String(id || ""),
      role: String(role || ""),
      length: normalized.length,
      head: normalized.slice(0, 256),
      tail: normalized.slice(-256),
    };
  }

  function generationInProgress() {
    return Boolean(
      document.querySelector(
        '[data-testid="stop-button"],button[aria-label*="Stop"],button[aria-label*="stop"],button[aria-label*="停止"],button[title*="Stop"],button[title*="stop"],button[title*="停止"]'
      )
    );
  }

  const isGenerating = generationInProgress();
  let turnContainers = Array.from(
    document.querySelectorAll("[data-testid^='conversation-turn-']")
  );
  const explicitUserTurns = Array.from(
    document.querySelectorAll('[data-message-author-role="user"]')
  );
  const explicitAssistantTurns = Array.from(
    document.querySelectorAll('[data-message-author-role="assistant"]')
  );

  if (!turnContainers.length) {
    const explicit = [
      ...explicitUserTurns,
      ...explicitAssistantTurns,
    ].filter((node, index, all) => all.indexOf(node) === index);
    explicit.sort((left, right) => {
      if (left === right) return 0;
      const position = left.compareDocumentPosition(right);
      return position & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1;
    });
    turnContainers = explicit;
  }

  const explicitUserByContainer = new Map(
    explicitUserTurns.map((node) => [canonicalTurn(node), node])
  );
  const explicitAssistantByContainer = new Map(
    explicitAssistantTurns.map((node) => [canonicalTurn(node), node])
  );

  const explicitRoles = turnContainers.map((turn) => {
    if (
      explicitUserByContainer.has(turn) ||
      turn.matches?.('[data-message-author-role="user"]') ||
      turn.querySelector?.('[data-message-author-role="user"]')
    ) {
      return "user";
    }
    if (
      explicitAssistantByContainer.has(turn) ||
      turn.matches?.('[data-message-author-role="assistant"]') ||
      turn.querySelector?.('[data-message-author-role="assistant"]')
    ) {
      return "assistant";
    }
    return "";
  });

  const inferredRoles = [...explicitRoles];
  let inferredRoleCount = 0;
  for (let index = 0; index < inferredRoles.length; index += 1) {
    if (inferredRoles[index]) continue;

    let anchor = -1;
    for (let distance = 1; distance < explicitRoles.length; distance += 1) {
      const left = index - distance;
      const right = index + distance;
      if (left >= 0 && explicitRoles[left]) {
        anchor = left;
        break;
      }
      if (right < explicitRoles.length && explicitRoles[right]) {
        anchor = right;
        break;
      }
    }

    if (anchor >= 0) {
      const sameParity = Math.abs(index - anchor) % 2 === 0;
      inferredRoles[index] = sameParity
        ? explicitRoles[anchor]
        : explicitRoles[anchor] === "user"
          ? "assistant"
          : "user";
    } else {
      const distanceFromEnd = inferredRoles.length - 1 - index;
      inferredRoles[index] =
        distanceFromEnd % 2 === 0 ? "assistant" : "user";
    }
    inferredRoleCount += 1;
  }

  const messages = [];
  let tailWitness = null;
  let truncated = false;
  for (let index = 0; index < turnContainers.length; index += 1) {
    const turn = turnContainers[index];
    const role = inferredRoles[index];
    if (role !== "user" && role !== "assistant") continue;

    const explicitContent =
      role === "user"
        ? explicitUserByContainer.get(turn) ||
          turn.querySelector?.('[data-message-author-role="user"]')
        : explicitAssistantByContainer.get(turn) ||
          turn.querySelector?.('[data-message-author-role="assistant"]');
    const assistantContent =
      role === "assistant"
        ? turn.querySelector?.(".markdown") ||
          turn.querySelector?.('[class*="prose"]')
        : null;
    const contentNode = explicitContent || assistantContent || turn;

    const raw = textOf(contentNode);
    if (!raw) continue;
    const clipped = clip(raw, MAX_MESSAGE_BYTES);
    if (!clipped.text) continue;
    truncated ||= clipped.truncated;
    const messageId = stableTurnId(
      contentNode,
      role,
      index,
      clipped.text,
    );
    messages.push({
      role,
      id: messageId,
      content: clipped.text,
      complete: role === "assistant" ? !clipped.truncated : true,
    });
    tailWitness = witness(messageId, role, raw);
  }

  if (isGenerating) {
    const lastAssistant = [...messages]
      .reverse()
      .find((item) => item.role === "assistant");
    if (lastAssistant) lastAssistant.complete = false;
  }

  let recentMessages = messages.slice(-MAX_RECENT_MESSAGES);
  truncated ||= messages.length > recentMessages.length;
  const encoder = new TextEncoder();
  while (
    recentMessages.length > 1 &&
    encoder.encode(JSON.stringify(recentMessages)).byteLength >
      MAX_TOTAL_BYTES
  ) {
    recentMessages.shift();
    truncated = true;
  }

  return {
    ok: recentMessages.length > 0,
    reason: recentMessages.length ? "" : "dom_empty",
    generationInProgress: isGenerating,
    recentMessages,
    recentMessagesTruncated: truncated,
    tailWitness,
    diagnostic: {
      source: "dom_visible_tail",
      turn_containers: turnContainers.length,
      explicit_user_turns: explicitUserTurns.length,
      explicit_assistant_turns: explicitAssistantTurns.length,
      inferred_roles: inferredRoleCount,
      captured_messages: recentMessages.length,
    },
  };
}

function verifyResumeTokenOnDemand(expectedToken) {
  const token = String(expectedToken || "").trim();
  if (!token) return false;

  const userNodes = Array.from(
    document.querySelectorAll('[data-message-author-role="user"]')
  );
  if (
    userNodes.some((node) =>
      String(node?.textContent || "").includes(token)
    )
  ) {
    return true;
  }

  const turns = Array.from(
    document.querySelectorAll("[data-testid^='conversation-turn-']")
  );
  for (const turn of turns) {
    const explicitUser = turn.querySelector?.(
      '[data-message-author-role="user"]'
    );
    if (explicitUser) {
      if (String(explicitUser.textContent || "").includes(token)) {
        return true;
      }
      continue;
    }
    if (String(turn?.textContent || "").includes(token)) return true;
  }
  return false;
}
