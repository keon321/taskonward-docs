importScripts("config.js");

const CONFIG = globalThis.MEMORY_V5_POWER_CONFIG;
const AUTH_KEY = "memory_v5_power_auth";
const BACKEND_HEALTH_KEY = "memory_v5_backend_health";
const BINDING_PREFIX = "memory_v5_binding:";
const ACTIVE_HANDOFF_PREFIX = "memory_v5_active_handoff:";
const RESUME_ARM_PREFIX = "taskonward_resume_arm:";
const RESUME_CLAIM_PREFIX = "taskonward_resume_claim:";
const RESUME_ARM_TTL_MS = 24 * 60 * 60_000;
const LOCAL_OUTBOX_MAX_ITEMS = 50;
const LOCAL_OUTBOX_MAX_BYTES = 20 * 1024;
const LOCAL_TURN_MAX_BYTES = 10 * 1024;
const LOCAL_EMERGENCY_RECENT_MAX_BYTES = 16 * 1024;
const LOCAL_EMERGENCY_MAX_BYTES = 64 * 1024;
const CONVERSATION_RE = /\/c\/([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})(?:\/|$)/i;
const TASKONWARD_RESUME_RE = /TaskOnward\s*续聊码\s*[:：]\s*([A-Za-z0-9_-]+)/i;
const V5_HANDOFF_RE = /\[memory-v5-handoff:([A-Za-z0-9_-]+)\]/;
const V5_LANE_RE = /\[memory-v5-lane:(lane_[A-Za-z0-9_-]+)\]/;
const V5_VERSION_RE = /\[memory-v5-version:(\d+)\]/;
const LEGACY_HANDOFF_RE = /\[memory-handoff:([A-Za-z0-9_-]+)\]/;
const LEGACY_LANE_RE = /\[memory-lane:(lane_[A-Za-z0-9_-]+)\]/;
const OFFSCREEN_PATH = "offscreen.html";
let offscreenCreating = null;
let clipboardCopyQueue = Promise.resolve();

function bytesToBase64Url(bytes) {
  let binary = "";
  for (const b of bytes) binary += String.fromCharCode(b);
  return btoa(binary)
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/g, "");
}

function randomUrlSafe(byteLength = 32) {
  const bytes = new Uint8Array(byteLength);
  crypto.getRandomValues(bytes);
  return bytesToBase64Url(bytes);
}

async function sha256UrlSafe(text) {
  const digest = await crypto.subtle.digest(
    "SHA-256",
    new TextEncoder().encode(text)
  );
  return bytesToBase64Url(new Uint8Array(digest));
}

function storageGet(keys) {
  return new Promise((resolve) => chrome.storage.local.get(keys, resolve));
}

function storageSet(values) {
  return new Promise((resolve) => chrome.storage.local.set(values, resolve));
}

function storageRemove(keys) {
  return new Promise((resolve) => chrome.storage.local.remove(keys, resolve));
}

function sessionStorageGet(keys) {
  return new Promise((resolve) => chrome.storage.session.get(keys, resolve));
}

function sessionStorageSet(values) {
  return new Promise((resolve) => chrome.storage.session.set(values, resolve));
}

function sessionStorageRemove(keys) {
  return new Promise((resolve) => chrome.storage.session.remove(keys, resolve));
}

async function fetchWithTimeout(url, options = {}, timeoutMs = 15000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, {
      ...options,
      signal: controller.signal,
    });
  } catch (error) {
    if (controller.signal.aborted) throw new Error("network_timeout");
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

function collectCurrentConversationOnDemand() {
  const LIMITS = {
    pendingUserTurns: 50,
    bootstrapRecentUserTurns: 6,
    bootstrapSeedUserTurns: 1,
    assistantTailMessages: 4,
    userTurnBytes: 10 * 1024,
    pendingTotalBytes: 20 * 1024,
    assistantTailBytes: 24 * 1024,
    latestAssistantBytes: 24 * 1024,
  };

  function utf8ClipLocal(text, maxBytes) {
    const value = String(text || "").trim();
    if (!value) return { text: "", truncated: false };
    const encoder = new TextEncoder();
    const bytes = encoder.encode(value).byteLength;
    if (bytes <= maxBytes) return { text: value, truncated: false };
    let low = 0;
    let high = value.length;
    while (low < high) {
      const mid = Math.ceil((low + high) / 2);
      if (encoder.encode(value.slice(0, mid)).byteLength <= maxBytes) low = mid;
      else high = mid - 1;
    }
    return { text: value.slice(0, low).trim(), truncated: true };
  }

  function textOf(node) {
    return String(node?.textContent || "").trim();
  }

  function canonicalTurn(node) {
    return node?.closest?.("[data-testid^='conversation-turn-']") || node || null;
  }

  function stableTurnId(node, role, index, content) {
    const explicit = node?.matches?.("[data-message-author-role]")
      ? node
      : node?.querySelector?.("[data-message-author-role]");
    const direct =
      explicit?.getAttribute?.("data-message-id") ||
      node?.getAttribute?.("data-message-id") ||
      canonicalTurn(node)?.getAttribute?.("data-testid") ||
      "";
    if (direct) return String(direct).slice(0, 200);

    let hash = 2166136261;
    const value = role + "\n" + String(index) + "\n" + String(content || "");
    for (let i = 0; i < value.length; i += 1) {
      hash ^= value.charCodeAt(i);
      hash = Math.imul(hash, 16777619);
    }
    return (
      "local_" +
      role +
      "_" +
      index +
      "_" +
      (hash >>> 0).toString(36)
    ).slice(0, 200);
  }

  function looksLikeLocalEmergency(value) {
    const text = String(value || "");
    if (/TaskOnward\s*临时恢复编号\s*[:：]\s*[A-Za-z0-9_-]+/i.test(text)) {
      return true;
    }
    return /\[memory-v5-local-emergency\]/.test(text) && (
      /\[memory-v5-emergency-id:[^\]]+\]/.test(text) ||
      /@EmergencyId\s+\S+/.test(text) ||
      /【本地未同步用户请求】/.test(text) ||
      /这是本地(?:应急续聊|续聊恢复)包/.test(text)
    );
  }

  function parseCanonicalMarker(value) {
    const text = String(value || "");
    const brandedToken =
      text.match(/TaskOnward\s*续聊码\s*[:：]\s*([A-Za-z0-9_-]+)/i)?.[1] || "";
    if (brandedToken) {
      return {
        token: brandedToken,
        laneId: null,
        savedVersion: null,
        format: "taskonward_resume",
      };
    }

    if (
      !/(?:只)?使用已连接的\s*(?:TaskOnward|Memory V5 Beta)/i.test(text) ||
      !/(?:精确恢复(?:并锁定)?原任务线|精确恢复此任务)/.test(text)
    ) {
      return null;
    }
    const token =
      text.match(/\[memory-v5-handoff:([A-Za-z0-9_-]+)\]/)?.[1] || "";
    const laneId =
      text.match(/\[memory-v5-lane:(lane_[A-Za-z0-9_-]+)\]/)?.[1] || "";
    const versionRaw =
      text.match(/\[memory-v5-version:(\d+)\]/)?.[1] || "";
    const savedVersion = Number(versionRaw);
    if (!token || !laneId || !Number.isSafeInteger(savedVersion) || savedVersion < 1) {
      return null;
    }
    return { token, laneId, savedVersion, format: "legacy_memory_v5" };
  }

  function generationInProgress() {
    return Boolean(
      document.querySelector(
        '[data-testid="stop-button"],button[aria-label*="Stop"],button[aria-label*="stop"],button[aria-label*="停止"],button[title*="Stop"],button[title*="stop"],button[title*="停止"]'
      )
    );
  }

  const isGenerating = generationInProgress();
  if (isGenerating) {
    return {
      generationInProgress: true,
      captureMode: "deferred_generation",
      boundary: { type: "none", found: false, scan_truncated: false },
      canonicalMarker: null,
      canonicalMarkerAmbiguous: false,
      pendingUser: {
        boundary: "none",
        items: [],
        overflowed: false,
        bootstrap_truncated: false,
        capture_mode: "deferred_generation",
      },
      assistantTail: null,
      emergencyRecentContext: null,
      latestDialogue: {
        user: "",
        assistant: "",
        assistant_complete: false,
        user_truncated: false,
        assistant_truncated: false,
      },
      diagnostic: {
        user_turns: 0,
        assistant_turns: 0,
        boundary_scan_start: 0,
        pending_user_items: 0,
        bootstrap_truncated: false,
        post_boundary_overflow: false,
        canonical_marker_ambiguous: false,
      },
    };
  }

  const turnContainers = Array.from(
    document.querySelectorAll("[data-testid^='conversation-turn-']")
  );
  const explicitUserTurns = Array.from(
    document.querySelectorAll('[data-message-author-role="user"]')
  );
  const explicitAssistantTurns = Array.from(
    document.querySelectorAll('[data-message-author-role="assistant"]')
  );

  // ChatGPT has changed role attributes more than once. Classify each mounted
  // conversation-turn conservatively so first-use Power does not become empty
  // merely because data-message-author-role disappeared from user turns.
  let userTurns = explicitUserTurns;
  let assistantTurns = explicitAssistantTurns;
  if (turnContainers.length) {
    const explicitUserByContainer = new Map(
      explicitUserTurns.map((node) => [canonicalTurn(node), node])
    );
    const explicitAssistantByContainer = new Map(
      explicitAssistantTurns.map((node) => [canonicalTurn(node), node])
    );
    const discoveredUsers = [];
    const discoveredAssistants = [];

    for (const turn of turnContainers) {
      const explicitUser =
        explicitUserByContainer.get(turn) ||
        turn.querySelector?.('[data-message-author-role="user"]') ||
        null;
      if (explicitUser) {
        discoveredUsers.push(explicitUser);
        continue;
      }

      const explicitAssistant =
        explicitAssistantByContainer.get(turn) ||
        turn.querySelector?.('[data-message-author-role="assistant"]') ||
        null;
      const assistantContent =
        explicitAssistant ||
        turn.querySelector?.('.markdown') ||
        turn.querySelector?.('[class*="prose"]') ||
        null;
      if (assistantContent && textOf(assistantContent)) {
        discoveredAssistants.push(assistantContent);
        continue;
      }

      // A non-empty conversation-turn with neither an explicit Assistant role
      // nor Assistant prose is the current ChatGPT user-turn fallback.
      if (textOf(turn)) discoveredUsers.push(turn);
    }

    if (discoveredUsers.length) userTurns = discoveredUsers;
    if (discoveredAssistants.length) assistantTurns = discoveredAssistants;
  }
  // Identity boundaries are scanned across every user turn currently
  // present in the DOM. This is one-shot work only after an explicit Power
  // action, so correctness is preferred over an arbitrary historical cap.
  const scanStart = 0;

  let boundaryIndex = -1;
  let boundaryType = "none";
  let boundaryNode = null;

  // Resume identity must not depend on role classification. ChatGPT may render
  // role-less user content with the same markdown/prose containers used by
  // Assistant messages. Scan every mounted conversation turn for the opaque
  // TaskOnward marker first; role classification is only for payload capture.
  const canonicalMarkers = [];
  const markerNodes = turnContainers.length ? turnContainers : userTurns;
  for (let index = markerNodes.length - 1; index >= 0; index -= 1) {
    const marker = parseCanonicalMarker(textOf(markerNodes[index]));
    if (marker) canonicalMarkers.push({ ...marker, index });
  }

  for (let index = userTurns.length - 1; index >= scanStart; index -= 1) {
    const text = textOf(userTurns[index]);
    const marker = parseCanonicalMarker(text);
    if (boundaryIndex >= 0) continue;

    if (marker) {
      boundaryIndex = index;
      boundaryType = marker.format === "taskonward_resume"
        ? "taskonward_resume"
        : "legacy_handoff";
      boundaryNode = userTurns[index];
    } else if (/\[memory-control:sync:[A-Za-z0-9_-]+\]/.test(text)) {
      boundaryIndex = index;
      boundaryType = "legacy_save";
      boundaryNode = userTurns[index];
    } else if (looksLikeLocalEmergency(text)) {
      boundaryIndex = index;
      boundaryType = "memory_v5_local_emergency";
      boundaryNode = userTurns[index];
    }
  }

  const markerKeys = new Set(
    canonicalMarkers.map((item) => item.token)
  );
  const canonicalMarker = markerKeys.size === 1 ? canonicalMarkers[0] : null;
  const canonicalMarkerAmbiguous = markerKeys.size > 1;
  if (canonicalMarkerAmbiguous) {
    boundaryIndex = -1;
    boundaryType = "ambiguous_resume";
    boundaryNode = null;
  }

  let captureMode = "post_boundary";
  let sourceUsers = [];
  let bootstrapTruncated = false;

  if (boundaryIndex >= 0) {
    sourceUsers = userTurns.slice(boundaryIndex + 1);
  } else {
    captureMode = "bootstrap_recent";
    const recentUsers = userTurns.slice(-LIMITS.bootstrapRecentUserTurns);
    const seedUsers = userTurns.slice(0, LIMITS.bootstrapSeedUserTurns);
    sourceUsers = [...seedUsers, ...recentUsers.filter((node) => !seedUsers.includes(node))];
    bootstrapTruncated = userTurns.length > sourceUsers.length;
  }

  const overflowedPostBoundary =
    captureMode === "post_boundary" &&
    sourceUsers.length > LIMITS.pendingUserTurns;
  const selectedUsers = overflowedPostBoundary
    ? sourceUsers.slice(-LIMITS.pendingUserTurns)
    : sourceUsers.slice(0, LIMITS.pendingUserTurns);

  const pendingItems = [];
  let pendingBudgetOverflow = false;
  let pendingTurnTruncated = false;
  for (let index = 0; index < selectedUsers.length; index += 1) {
    const node = selectedUsers[index];
    const raw = textOf(node);
    const clipped = utf8ClipLocal(raw, LIMITS.userTurnBytes);
    if (!clipped.text) continue;
    const absoluteIndex = userTurns.indexOf(node);
    pendingTurnTruncated ||= clipped.truncated;
    pendingItems.push({
      turnId: stableTurnId(node, "user", absoluteIndex, clipped.text),
      content: clipped.text,
      truncated: clipped.truncated,
      capturedAt: Date.now(),
    });
  }

  const encoder = new TextEncoder();
  while (
    pendingItems.length > 0 &&
    encoder.encode(JSON.stringify(pendingItems)).byteLength >
      LIMITS.pendingTotalBytes
  ) {
    pendingBudgetOverflow = true;
    pendingItems.shift();
  }

  let selectedAssistants = assistantTurns;
  if (boundaryNode) {
    selectedAssistants = assistantTurns.filter((node) =>
      Boolean(
        boundaryNode.compareDocumentPosition(node) &
          Node.DOCUMENT_POSITION_FOLLOWING
      )
    );
  }
  selectedAssistants = selectedAssistants.slice(
    -LIMITS.assistantTailMessages
  );

  const assistantMessages = [];
  for (const node of selectedAssistants) {
    const value = textOf(node);
    if (value) assistantMessages.push(value);
  }

  let assistantTail = null;
  if (assistantMessages.length) {
    const joined = assistantMessages
      .map(
        (text, index) =>
          "[assistant-turn-" + (index + 1) + "]\n" + text
      )
      .join("\n\n");
    const clipped = utf8ClipLocal(joined, LIMITS.assistantTailBytes);
    if (clipped.text) {
      assistantTail = {
        content: clipped.text,
        message_count: assistantMessages.length,
        generation_in_progress: generationInProgress(),
      };
    }
  }

  const latestUser =
    userTurns.length > 0 ? userTurns[userTurns.length - 1] : null;
  let latestAssistant = null;
  if (latestUser) {
    for (
      let index = assistantTurns.length - 1;
      index >= 0;
      index -= 1
    ) {
      if (
        latestUser.compareDocumentPosition(assistantTurns[index]) &
        Node.DOCUMENT_POSITION_FOLLOWING
      ) {
        latestAssistant = assistantTurns[index];
        break;
      }
    }
  }

  const latestUserClip = utf8ClipLocal(
    textOf(latestUser),
    LIMITS.userTurnBytes
  );
  const latestAssistantClip = utf8ClipLocal(
    textOf(latestAssistant),
    LIMITS.latestAssistantBytes
  );
  return {
    generationInProgress: false,
    captureMode,
    boundary: {
      type: boundaryType,
      found: boundaryIndex >= 0,
      scan_truncated: scanStart > 0 && boundaryIndex < 0,
    },
    canonicalMarker: canonicalMarker
      ? {
          token: canonicalMarker.token,
          laneId: canonicalMarker.laneId || null,
          savedVersion: Number.isSafeInteger(canonicalMarker.savedVersion)
            ? canonicalMarker.savedVersion
            : null,
        }
      : null,
    canonicalMarkerAmbiguous,
    pendingUser: {
      boundary: boundaryType,
      items: pendingItems,
      overflowed:
        overflowedPostBoundary ||
        bootstrapTruncated ||
        pendingBudgetOverflow ||
        pendingTurnTruncated,
      bootstrap_truncated: bootstrapTruncated,
      capture_mode: captureMode,
    },
    assistantTail,
    emergencyRecentContext: null,
    latestDialogue: {
      user: latestUserClip.text,
      assistant: latestAssistantClip.text,
      assistant_complete: Boolean(latestAssistant),
      user_truncated: latestUserClip.truncated,
      assistant_truncated: latestAssistantClip.truncated,
    },
    diagnostic: {
      user_turns: userTurns.length,
      assistant_turns: assistantTurns.length,
      boundary_scan_start: scanStart,
      pending_user_items: pendingItems.length,
      bootstrap_truncated: bootstrapTruncated,
      post_boundary_overflow:
        overflowedPostBoundary ||
        (captureMode === "post_boundary" &&
          (pendingBudgetOverflow || pendingTurnTruncated)),
      pending_budget_overflow: pendingBudgetOverflow,
      pending_turn_truncated: pendingTurnTruncated,
      canonical_marker_ambiguous: canonicalMarkerAmbiguous,
    },
  };
}

function verifyResumeTokenOnDemand(expectedToken) {
  const token = String(expectedToken || "").trim();
  if (!token) return false;
  const userNodes = Array.from(
    document.querySelectorAll('[data-message-author-role="user"]')
  );
  if (userNodes.some((node) =>
    String(node?.textContent || "").includes(token)
  )) {
    return true;
  }
  const turns = Array.from(
    document.querySelectorAll("[data-testid^='conversation-turn-']")
  );
  for (const turn of turns) {
    const explicitUser = turn.querySelector?.(
      '[data-message-author-role="user"]'
    );
    if (explicitUser) {
      if (String(explicitUser.textContent || "").includes(token)) return true;
      continue;
    }
    if (String(turn?.textContent || "").includes(token)) return true;
  }
  return false;
}

function collectEmergencyRecentContextOnDemand() {
  const MAX_TURNS = 16;
  const MAX_ROUNDS = 3;
  const MAX_TURN_BYTES = 24 * 1024;

  function clip(text, maxBytes) {
    const value = String(text || "").trim();
    if (!value) return { text: "", truncated: false };
    const encoder = new TextEncoder();
    if (encoder.encode(value).byteLength <= maxBytes) {
      return { text: value, truncated: false };
    }
    let low = 0;
    let high = value.length;
    while (low < high) {
      const mid = Math.ceil((low + high) / 2);
      if (encoder.encode(value.slice(0, mid)).byteLength <= maxBytes) low = mid;
      else high = mid - 1;
    }
    return { text: value.slice(0, low).trim(), truncated: true };
  }

  function stableId(node, role, index, content) {
    const direct =
      node?.getAttribute?.("data-message-id") ||
      node?.closest?.("[data-testid^='conversation-turn-']")?.getAttribute?.("data-testid") ||
      "";
    if (direct) return String(direct).slice(0, 200);
    let hash = 2166136261;
    const value = role + "\n" + index + "\n" + String(content || "");
    for (let i = 0; i < value.length; i += 1) {
      hash ^= value.charCodeAt(i);
      hash = Math.imul(hash, 16777619);
    }
    return ("local_" + role + "_" + index + "_" + (hash >>> 0).toString(36)).slice(0, 200);
  }

  const nodes = Array.from(
    document.querySelectorAll(
      '[data-message-author-role="user"],[data-message-author-role="assistant"]'
    )
  ).slice(-MAX_TURNS);
  const items = [];
  for (let index = 0; index < nodes.length; index += 1) {
    const node = nodes[index];
    const role = String(node?.getAttribute?.("data-message-author-role") || "");
    if (role !== "user" && role !== "assistant") continue;
    const clipped = clip(node.textContent, MAX_TURN_BYTES);
    if (!clipped.text) continue;
    items.push({
      role,
      turnId: stableId(node, role, index, clipped.text),
      content: clipped.text,
      truncated: clipped.truncated,
      completeness: clipped.truncated ? "false" : "true",
    });
  }

  const rounds = [];
  let pendingUser = null;
  for (const item of items) {
    if (item.role === "user") pendingUser = item;
    else if (item.role === "assistant" && pendingUser) {
      rounds.push({ user: pendingUser, assistant: item });
      pendingUser = null;
    }
  }
  const selected = rounds.slice(-MAX_ROUNDS);
  return {
    rounds: selected,
    capture_quality: nodes.length ? "structured" : "unavailable",
    overflowed: rounds.length > selected.length,
    captured_at: Date.now(),
  };
}

async function collectConversationSnapshot(tabId) {
  if (!Number.isInteger(tabId)) throw new Error("tab_id_missing");
  let lastError = null;
  for (let attempt = 0; attempt < 2; attempt += 1) {
    try {
      const results = await chrome.scripting.executeScript({
        target: { tabId },
        world: "ISOLATED",
        func: collectCurrentConversationOnDemand,
      });
      const snapshot = results?.[0]?.result;
      if (snapshot && typeof snapshot === "object") {
        return snapshot;
      }
      lastError = new Error("conversation_capture_unavailable");
    } catch (error) {
      lastError = error;
    }
    if (attempt === 0) {
      await new Promise((resolve) => setTimeout(resolve, 40));
    }
  }
  throw new Error(
    "conversation_capture_unavailable:" +
      String(lastError?.message || lastError || "unknown")
  );
}

async function verifyResumeTokenInTab(tabId, token) {
  if (!Number.isInteger(tabId) || !token) return false;
  const results = await chrome.scripting.executeScript({
    target: { tabId },
    world: "ISOLATED",
    func: verifyResumeTokenOnDemand,
    args: [String(token)],
  });
  return results?.[0]?.result === true;
}

async function collectEmergencyRecentContext(tabId) {
  if (!Number.isInteger(tabId)) throw new Error("tab_id_missing");
  const results = await chrome.scripting.executeScript({
    target: { tabId },
    world: "ISOLATED",
    func: collectEmergencyRecentContextOnDemand,
  });
  const value = results?.[0]?.result;
  return value && typeof value === "object"
    ? value
    : {
        rounds: [],
        capture_quality: "unavailable",
        overflowed: false,
        captured_at: Date.now(),
      };
}

function bindingKey(conversationId) {
  return BINDING_PREFIX + conversationId;
}

function activeHandoffKey(conversationId) {
  return ACTIVE_HANDOFF_PREFIX + conversationId;
}

function resumeArmKey(tabId) {
  return RESUME_ARM_PREFIX + String(tabId);
}

async function resumeArmGet(tabId) {
  if (!Number.isInteger(tabId)) return null;
  const key = resumeArmKey(tabId);
  const values = await sessionStorageGet(key);
  const value = values[key];
  if (!value || typeof value !== "object") return null;
  if (Number(value.expiresAt || 0) <= Date.now()) {
    await sessionStorageRemove(key);
    return null;
  }
  return value;
}

async function resumeArmSet(tabId, token) {
  if (!Number.isInteger(tabId) || !token) return null;
  const value = {
    token: String(token),
    armedAt: Date.now(),
    expiresAt: Date.now() + RESUME_ARM_TTL_MS,
  };
  await sessionStorageSet({ [resumeArmKey(tabId)]: value });
  return value;
}

async function resumeArmClear(tabId) {
  if (!Number.isInteger(tabId)) return;
  await sessionStorageRemove(resumeArmKey(tabId));
}

function resumeClaimKey(conversationId) {
  return RESUME_CLAIM_PREFIX + String(conversationId || "");
}

async function resumeClaimGet(conversationId) {
  if (!conversationId) return null;
  const key = resumeClaimKey(conversationId);
  const values = await storageGet(key);
  const value = values[key];
  if (!value || typeof value !== "object") return null;
  if (Number(value.expiresAt || 0) <= Date.now()) {
    await storageRemove(key);
    return null;
  }
  return value;
}

async function resumeClaimSet(conversationId, token) {
  if (!conversationId || !token) return null;
  const value = {
    token: String(token),
    claimedAt: Date.now(),
    expiresAt: Date.now() + RESUME_ARM_TTL_MS,
  };
  await storageSet({ [resumeClaimKey(conversationId)]: value });
  return value;
}

async function resumeClaimClear(conversationId) {
  if (!conversationId) return;
  await storageRemove(resumeClaimKey(conversationId));
}

async function activeHandoffGet(conversationId) {
  if (!conversationId) return null;
  const key = activeHandoffKey(conversationId);
  const values = await storageGet(key);
  const value = values[key];
  if (!value || typeof value !== "object") return null;
  if (
    value.expiresAt &&
    Date.parse(String(value.expiresAt)) <= Date.now()
  ) {
    await storageRemove(key);
    return null;
  }
  return value;
}

async function activeHandoffClear(conversationId) {
  if (!conversationId) return;
  await storageRemove(activeHandoffKey(conversationId));
}

async function activeHandoffSet(conversationId, value) {
  if (!conversationId || !value) return;
  await storageSet({
    [activeHandoffKey(conversationId)]: value,
  });
}

function conversationIdFromUrl(url) {
  return String(url || "").match(CONVERSATION_RE)?.[1] ?? null;
}

function isTransientServiceError(value) {
  const text = String(value || "");
  return /service_quota_unavailable|service_unavailable|network_timeout|automatic_request_budget_exhausted|oauth_metadata_unavailable|authorization_server_metadata_unavailable|daily request limit|limit exceeded|error code\s*1027|http[_ -]?429|http[_ -]?5\d\d|failed to fetch/i.test(text);
}

function publicFailureMessage(message) {
  const text = String(message || "");
  if (isTransientServiceError(text)) {
    return "TaskOnward 暂时无法连接，请稍后重试。";
  }
  if (/auth|oauth|unauthor|forbidden/i.test(text)) {
    return "TaskOnward 登录状态需要更新，请重新登录后再试。";
  }
  if (/provisional_bootstrap_context_missing/i.test(text)) {
    return "当前 Chat 没有可恢复的任务内容。请回到原任务 Chat，或重新发送最近一次有效的 TaskOnward 续聊内容后再试。";
  }
  if (/legacy_handoff_recovery_required|provisional_handoff_requires_bootstrap/i.test(text)) {
    return "检测到旧版 Power 留下的未完成续聊，请更新 Power 后重新点击。";
  }
  if (/handoff_in_progress|handoff_refresh_conflict/i.test(text)) {
    return "已有续聊正在等待确认。请先在新 Chat 完成恢复；如果刚才恢复失败，再回当前 Chat 重试 Power。";
  }
  if (/continuity_anchors_incomplete/i.test(text)) {
    return "当前任务状态还没有保存完整，暂不能安全换 Chat。请先完成本次任务校准后再试。";
  }
  if (/conversation|chat|binding|handoff|lane|checkpoint|canonical|collector|capture|token/i.test(text)) {
    return "当前对话暂时无法可靠接续，请刷新页面后重试。";
  }
  return "TaskOnward 暂时无法完成这次操作，请重试。";
}

function externalFailure(error) {
  const message = String(error?.message || error || "unknown_error");
  return {
    ok: false,
    error: publicFailureMessage(message),
    degraded: isTransientServiceError(message),
  };
}

function utf8Bytes(text) {
  return new TextEncoder().encode(String(text || "")).byteLength;
}

function clipUtf8(text, maxBytes) {
  const value = String(text || "");
  if (utf8Bytes(value) <= maxBytes) return value;
  let low = 0;
  let high = value.length;
  while (low < high) {
    const mid = Math.ceil((low + high) / 2);
    if (utf8Bytes(value.slice(0, mid)) <= maxBytes) low = mid;
    else high = mid - 1;
  }
  return value.slice(0, low);
}

function containsHighConfidenceSecretText(value) {
  const text = String(value || "");
  return [
    /-----BEGIN(?: [A-Z0-9]+)? PRIVATE KEY-----/i,
    /\bsk-[A-Za-z0-9_-]{16,}\b/,
    /\bgh[pousr]_[A-Za-z0-9]{20,}\b/,
    /\bAKIA[0-9A-Z]{16}\b/,
    /\bAIza[0-9A-Za-z_-]{30,}\b/,
    /\bxox[baprs]-[A-Za-z0-9-]{16,}\b/,
    /\bBearer\s+[A-Za-z0-9._~+\/-]{20,}\b/i,
  ].some((pattern) => pattern.test(text));
}

function pendingForHandoff(pageState) {
  const pageItems = Array.isArray(pageState?.items) ? pageState.items : [];
  const ordered = [];
  const seen = new Set();
  let bytes = 0;
  let overflowed = Boolean(pageState?.overflowed);
  let sensitiveOmitted = Number(
    pageState?.sensitiveOmitted ?? pageState?.sensitive_omitted ?? 0
  );

  for (const raw of pageItems) {
    const turnId = String(raw?.turnId || raw?.turn_id || "").trim();
    if (!turnId || seen.has(turnId)) continue;
    const rawContent = String(raw?.content || "").trim();
    if (!rawContent) continue;
    if (looksLikeInternalControlContent(rawContent)) continue;
    if (containsHighConfidenceSecretText(rawContent)) {
      sensitiveOmitted += 1;
      overflowed = true;
      continue;
    }
    const content = clipUtf8(rawContent, LOCAL_TURN_MAX_BYTES);
    const capturedAt = Number(raw?.capturedAt);
    const item = {
      turnId: turnId.slice(0, 200),
      content,
      capturedAt: Number.isFinite(capturedAt) ? capturedAt : null,
    };
    const itemBytes = utf8Bytes(JSON.stringify(item));
    if (
      ordered.length >= LOCAL_OUTBOX_MAX_ITEMS ||
      bytes + itemBytes > LOCAL_OUTBOX_MAX_BYTES
    ) {
      overflowed = true;
      break;
    }
    bytes += itemBytes;
    seen.add(turnId);
    ordered.push(item);
  }
  return { items: ordered, overflowed, sensitive_omitted: sensitiveOmitted };
}

async function backendHealthGet() {
  const value = (await storageGet(BACKEND_HEALTH_KEY))[BACKEND_HEALTH_KEY];
  return value && typeof value === "object" ? value : null;
}

async function backendHealthBlock(reason) {
  const now = Date.now();
  const quota = String(reason || "") === "service_quota_unavailable";
  const value = {
    reason: String(reason || "service_unavailable"),
    blockedUntil: quota ? Date.UTC(new Date(now).getUTCFullYear(), new Date(now).getUTCMonth(), new Date(now).getUTCDate() + 1) : now + 60_000,
    updatedAt: now,
  };
  await storageSet({ [BACKEND_HEALTH_KEY]: value });
  return value;
}

async function backendHealthClear() {
  await storageRemove(BACKEND_HEALTH_KEY);
}

async function assertBackendAvailable() {
  const health = await backendHealthGet();
  if (!health) return;
  if (Number(health.blockedUntil || 0) <= Date.now()) {
    await backendHealthClear();
    return;
  }
  throw new Error(String(health.reason || "service_unavailable"));
}

async function backendFetch(url, options = {}) {
  try {
    return await fetchWithTimeout(url, options);
  } catch (error) {
    const message = String(error?.message || error || "network_timeout");
    if (isTransientServiceError(message)) {
      await backendHealthBlock("service_unavailable");
    }
    throw error;
  }
}

async function injectCurrentArchitecture(tabId) {
  await chrome.scripting.executeScript({
    target: { tabId },
    world: "ISOLATED",
    files: ["page_agent.js"],
  });
}

async function cleanupLegacyMainAgent(tabId) {
  await chrome.scripting.executeScript({
    target: { tabId },
    world: "MAIN",
    func: () => {
      try {
        window.__memoryV5PowerPageAgent?.stop?.();
      } catch {}
      try {
        delete window.__memoryV5PowerPageAgent;
      } catch {}
      document.getElementById("memory-v5-power-root")?.remove();
      document.getElementById("memory-v5-power-toast")?.remove();
      return true;
    },
  });
}

async function rehydrateOpenChatgptTabs(reason = "extension_reload") {
  const tabs = await chrome.tabs.query({ url: ["https://chatgpt.com/*"] });
  const results = [];

  for (const tab of tabs) {
    if (!Number.isInteger(tab.id)) continue;
    const tabId = tab.id;
    try {
      await cleanupLegacyMainAgent(tabId).catch(() => {});
      await injectCurrentArchitecture(tabId);

      let identityRecovered = false;
      const tabUrl = String(tab.url || "");
      const conversationId = conversationIdFromUrl(tabUrl);
      if (conversationId) {
        const arm = await resumeArmGet(tabId);
        if (arm?.token) {
          const attached = await attachArmedResumeForTab(
            tabId,
            tabUrl,
            cleanTitleSeed(tab.title || "")
          );
          identityRecovered = attached.status === "bound";
        }
      }

      results.push({
        tabId,
        ok: true,
        reinjected: true,
        identityRecovered,
        legacyMainCleaned: true,
      });
    } catch (error) {
      results.push({
        tabId,
        ok: false,
        error: String(error?.message || error),
      });
    }
  }

  await storageSet({
    memory_v5_power_last_rehydrate: {
      reason,
      at: new Date().toISOString(),
      results,
    },
  });
  return results;
}

function canonicalReadySource(value) {
  return (
    value === "checkpoint_sync" ||
    value === "canonical_handoff" ||
    value === "remote_binding"
  );
}

async function getBinding(conversationId) {
  if (!conversationId) return null;
  const key = bindingKey(conversationId);
  const values = await storageGet(key);
  const stored = values[key] ?? null;
  if (!stored || typeof stored !== "object") return null;

  const legacyCheckpointProof =
    Number.isInteger(stored.savedVersion) &&
    stored.savedVersion >= 2 &&
    typeof stored.lastSyncKey === "string" &&
    stored.lastSyncKey.length > 0;
  const readinessSource =
    typeof stored.readinessSource === "string"
      ? stored.readinessSource
      : legacyCheckpointProof
        ? "checkpoint_sync"
        : "";
  const ready =
    Boolean(stored.ready) && canonicalReadySource(readinessSource);

  if (
    stored.ready !== ready ||
    stored.readinessSource !== readinessSource
  ) {
    const migrated = {
      ...stored,
      ready,
      readinessSource,
      updatedAt: new Date().toISOString(),
    };
    await storageSet({ [key]: migrated });
    return migrated;
  }
  return stored;
}

async function clearBinding(conversationId) {
  if (!conversationId) return;
  await storageRemove(bindingKey(conversationId));
}

async function setBinding(
  conversationId,
  laneId,
  titleSeed = "",
  {
    ready = undefined,
    savedVersion = undefined,
    lastSyncKey = undefined,
    readinessSource = undefined,
    lifecycleState = undefined,
    resumeConfirmationRequired = undefined,
  } = {}
) {
  if (!conversationId || !laneId) throw new Error("binding_missing_identity");
  const key = bindingKey(conversationId);
  const prior = await getBinding(conversationId);
  const sameLane = prior?.laneId === laneId;
  const nextReadinessSource =
    readinessSource !== undefined
      ? String(readinessSource || "")
      : sameLane
        ? String(prior?.readinessSource || "")
        : "";
  const nextReady =
    ready === undefined
      ? Boolean(sameLane && prior?.ready)
      : Boolean(ready);
  if (nextReady && !canonicalReadySource(nextReadinessSource)) {
    throw new Error("binding_ready_proof_required");
  }

  const value = {
    laneId,
    titleSeed:
      typeof titleSeed === "string" && titleSeed
        ? titleSeed
        : sameLane
          ? String(prior?.titleSeed || "")
          : "",
    ready: nextReady,
    readinessSource: nextReadinessSource,
    savedVersion:
      savedVersion !== undefined
        ? Number.isInteger(savedVersion)
          ? savedVersion
          : null
        : sameLane && Number.isInteger(prior?.savedVersion)
          ? prior.savedVersion
          : null,
    lastSyncKey:
      lastSyncKey !== undefined
        ? String(lastSyncKey || "")
        : sameLane
          ? String(prior?.lastSyncKey || "")
          : "",
    lifecycleState:
      lifecycleState !== undefined
        ? String(lifecycleState || "")
        : sameLane
          ? String(prior?.lifecycleState || "")
          : "",
    resumeConfirmationRequired:
      resumeConfirmationRequired !== undefined
        ? Boolean(resumeConfirmationRequired)
        : Boolean(sameLane && prior?.resumeConfirmationRequired),
    updatedAt: new Date().toISOString(),
  };
  await storageSet({ [key]: value });
  return value;
}

async function oauthMetadata() {
  const issuer = String(CONFIG.authIssuer || "").replace(/\/$/, "");
  if (!issuer) throw new Error("oauth_issuer_not_configured");
  return {
    issuer,
    authorization_endpoint: issuer + "/oauth2/authorize",
    token_endpoint: issuer + "/oauth2/token",
  };
}

function authConfigKey() {
  return [
    String(CONFIG.authIssuer || "").replace(/\/$/, ""),
    String(CONFIG.oauthClientId || ""),
    String(CONFIG.resource || ""),
  ].join("|");
}

function authMatchesCurrentConfig(auth) {
  return Boolean(auth && auth.configKey === authConfigKey());
}

async function storedAuthForCurrentConfig() {
  const auth = (await storageGet(AUTH_KEY))[AUTH_KEY] ?? null;
  if (!auth) return null;
  if (authMatchesCurrentConfig(auth)) return auth;
  await storageRemove(AUTH_KEY);
  return null;
}

async function storeTokens(payload) {
  if (!payload?.access_token) throw new Error("oauth_token_missing");
  const stored = (await storageGet(AUTH_KEY))[AUTH_KEY] ?? {};
  const prior = authMatchesCurrentConfig(stored) ? stored : {};
  const expiresIn = Number(payload.expires_in ?? 3600);
  const auth = {
    accessToken: payload.access_token,
    refreshToken: payload.refresh_token ?? prior.refreshToken ?? null,
    expiresAt: Date.now() + Math.max(60, expiresIn) * 1000,
    scope: payload.scope ?? prior.scope ?? null,
    tokenType: payload.token_type ?? "Bearer",
    configKey: authConfigKey(),
  };
  await storageSet({ [AUTH_KEY]: auth });
  return auth;
}

async function refreshAuth() {
  const stored = await storedAuthForCurrentConfig();
  if (!stored?.refreshToken) throw new Error("auth_required");
  if (!CONFIG.oauthClientId) throw new Error("oauth_client_not_configured");

  const metadata = await oauthMetadata();
  const body = new URLSearchParams({
    grant_type: "refresh_token",
    client_id: CONFIG.oauthClientId,
    refresh_token: stored.refreshToken,
    resource: CONFIG.resource,
  });

  const response = await fetchWithTimeout(metadata.token_endpoint, {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body,
  });
  if (!response.ok) {
    if (response.status === 400 || response.status === 401) {
      await storageRemove(AUTH_KEY);
      throw new Error("auth_required");
    }
    if (response.status === 429) {
      await backendHealthBlock("service_quota_unavailable");
      throw new Error("service_quota_unavailable");
    }
    if (response.status >= 500) {
      await backendHealthBlock("service_unavailable");
      throw new Error("service_unavailable");
    }
    throw new Error("oauth_token_refresh_failed");
  }
  return storeTokens(await response.json());
}

async function accessToken() {
  const stored = await storedAuthForCurrentConfig();
  if (!stored?.accessToken) throw new Error("auth_required");
  if (Number(stored.expiresAt ?? 0) > Date.now() + 60_000) {
    return stored.accessToken;
  }
  const refreshed = await refreshAuth();
  return refreshed.accessToken;
}

async function login() {
  if (!CONFIG.oauthClientId) throw new Error("oauth_client_not_configured");

  const metadata = await oauthMetadata();
  const redirectUri = chrome.identity.getRedirectURL("memory-v5");
  const verifier = randomUrlSafe(48);
  const challenge = await sha256UrlSafe(verifier);
  const state = randomUrlSafe(24);

  const authorize = new URL(metadata.authorization_endpoint);
  authorize.searchParams.set("client_id", CONFIG.oauthClientId);
  authorize.searchParams.set("redirect_uri", redirectUri);
  authorize.searchParams.set("response_type", "code");
  authorize.searchParams.set("scope", CONFIG.scopes.join(" "));
  authorize.searchParams.set("code_challenge", challenge);
  authorize.searchParams.set("code_challenge_method", "S256");
  authorize.searchParams.set("state", state);
  authorize.searchParams.set("resource", CONFIG.resource);

  const redirected = await chrome.identity.launchWebAuthFlow({
    url: authorize.href,
    interactive: true,
  });
  if (!redirected) throw new Error("oauth_redirect_missing");

  const callback = new URL(redirected);
  if (callback.searchParams.get("state") !== state) {
    throw new Error("oauth_state_mismatch");
  }
  const callbackError = callback.searchParams.get("error");
  if (callbackError) throw new Error("oauth_" + callbackError);

  const code = callback.searchParams.get("code");
  if (!code) throw new Error("oauth_code_missing");

  const body = new URLSearchParams({
    grant_type: "authorization_code",
    client_id: CONFIG.oauthClientId,
    code,
    code_verifier: verifier,
    redirect_uri: redirectUri,
    resource: CONFIG.resource,
  });

  const response = await fetchWithTimeout(metadata.token_endpoint, {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body,
  });
  if (!response.ok) throw new Error("oauth_token_exchange_failed");
  const auth = await storeTokens(await response.json());
  return {
    authenticated: true,
    expiresAt: auth.expiresAt,
    redirectUri,
  };
}

async function companionFetch(path, payload, token) {
  try {
    return await backendFetch(CONFIG.apiBase.replace(/\/$/, "") + path, {
      method: "POST",
      headers: {
        authorization: "Bearer " + token,
        "content-type": "application/json",
      },
      body: JSON.stringify({
        ...payload,
        client_version: chrome.runtime.getManifest().version,
      }),
    });
  } catch (error) {
    if (isTransientServiceError(error?.message || error)) {
      await backendHealthBlock("service_unavailable");
    }
    throw error;
  }
}

async function companionPost(path, payload) {
  await assertBackendAvailable();
  let token = await accessToken();
  let response = await companionFetch(path, payload, token);

  if (response.status === 401) {
    const refreshed = await refreshAuth();
    token = refreshed.accessToken;
    response = await companionFetch(path, payload, token);
  }

  const text = await response.text();
  let data = null;
  try {
    data = text ? JSON.parse(text) : {};
  } catch {
    data = null;
  }

  if (!response.ok) {
    if (
      response.status === 429 ||
      /daily request limit|limit exceeded|error code\s*1027/i.test(text)
    ) {
      await backendHealthBlock("service_quota_unavailable");
      throw new Error("service_quota_unavailable");
    }
    if (response.status >= 500) {
      await backendHealthBlock("service_unavailable");
      throw new Error("service_unavailable");
    }
    throw new Error(data?.error || ("companion_http_" + response.status));
  }
  if (!data || typeof data !== "object") throw new Error("invalid_json");
  await backendHealthClear();
  return data;
}

async function bindConversationFromHandoffProof({
  conversationId,
  token,
  laneId,
  savedVersion,
  titleSeed = "",
}) {
  if (!conversationId) throw new Error("conversation_id_missing");
  if (!token || !laneId || !Number.isSafeInteger(savedVersion)) {
    throw new Error("handoff_binding_proof_incomplete");
  }

  const result = await companionPost(
    "/companion/binding/from-handoff",
    {
      source_conversation_id: conversationId,
      token,
      lane_id: laneId,
      snapshot_version: savedVersion,
    }
  );
  if (
    result?.status !== "ok" ||
    result?.lane_id !== laneId ||
    Number(result?.snapshot_version) !== savedVersion ||
    result?.binding?.lane_id !== laneId
  ) {
    throw new Error("handoff_binding_proof_mismatch");
  }

  return setBinding(
    conversationId,
    laneId,
    titleSeed,
    {
      ready: Boolean(result.ready),
      savedVersion: Number.isSafeInteger(result.current_version)
        ? result.current_version
        : savedVersion,
      lastSyncKey: "",
      readinessSource: "remote_binding",
      lifecycleState: String(result.lifecycle_state || ""),
      resumeConfirmationRequired: Boolean(
        result.resume_confirmation_required ?? true
      ),
    }
  );
}

async function bindConversationFromResumeToken({
  conversationId,
  token,
  titleSeed = "",
}) {
  if (!conversationId || !token) throw new Error("resume_code_incomplete");
  const status = await companionPost("/companion/handoff/status", { token });
  if (
    !status?.lane_id ||
    !Number.isSafeInteger(Number(status?.snapshot_version))
  ) {
    throw new Error("resume_code_invalid");
  }
  return bindConversationFromHandoffProof({
    conversationId,
    token,
    laneId: status.lane_id,
    savedVersion: Number(status.snapshot_version),
    titleSeed,
  });
}

function terminalResumeAttachError(value) {
  return /handoff_(?:not_found|expired|invalid_status|target_conflict|target_same_as_source|binding_proof_mismatch)|binding_conflict|resume_code_invalid/i.test(
    String(value || "")
  );
}

async function attachArmedResumeForTab(tabId, tabUrl, titleSeed = "") {
  if (!Number.isInteger(tabId)) return { status: "none" };
  const arm = await resumeArmGet(tabId);
  if (!arm?.token) return { status: "none" };
  const conversationId = conversationIdFromUrl(tabUrl);
  if (!conversationId) return { status: "waiting_for_conversation" };

  // A tab id can be reused or the user can navigate elsewhere after a failed
  // send. Never turn a tab-scoped arm into a durable Conversation claim until
  // the exact opaque resume token is visible in a user message in this Chat.
  let tokenVisible = false;
  try {
    tokenVisible = await verifyResumeTokenInTab(tabId, arm.token);
  } catch {
    tokenVisible = false;
  }
  if (!tokenVisible) {
    return { status: "waiting_for_token_evidence", conversationId };
  }

  // Persist the exact token -> Conversation claim before any network/auth work.
  // This survives service-worker restarts and lets a later explicit Power click
  // finish binding even if auth/network was unavailable during the first send.
  await resumeClaimSet(conversationId, arm.token);

  const auth = await authStatus();
  if (!auth.configured || !auth.authenticated) {
    return { status: "waiting_for_auth", conversationId };
  }

  try {
    const binding = await bindConversationFromResumeToken({
      conversationId,
      token: arm.token,
      titleSeed,
    });
    await Promise.all([
      resumeArmClear(tabId),
      resumeClaimClear(conversationId),
    ]);
    return { status: "bound", binding };
  } catch (error) {
    const reason = String(error?.message || error);
    if (terminalResumeAttachError(reason)) {
      await Promise.all([
        resumeArmClear(tabId),
        resumeClaimClear(conversationId),
      ]);
      return { status: "terminal_error", reason };
    }
    return { status: "retryable_error", reason };
  }
}

async function authStatus() {
  const auth = await storedAuthForCurrentConfig();
  return {
    configured: Boolean(CONFIG.oauthClientId),
    authenticated: Boolean(auth?.accessToken || auth?.refreshToken),
    expiresAt: auth?.expiresAt ?? null,
    redirectUri: chrome.identity.getRedirectURL("memory-v5"),
    apiBase: CONFIG.apiBase,
  };
}

function looksLikeLocalEmergencyPackage(value) {
  const text = String(value || "");
  if (/TaskOnward\s*临时恢复编号\s*[:：]\s*[A-Za-z0-9_-]+/i.test(text)) {
    return true;
  }
  if (!/\[memory-v5-local-emergency\]/.test(text)) return false;
  return (
    /\[memory-v5-emergency-id:[^\]]+\]/.test(text) ||
    /@EmergencyId\s+\S+/.test(text) ||
    /【本地未同步用户请求】/.test(text) ||
    /这是本地(?:应急续聊|续聊恢复)包/.test(text)
  );
}

function cleanTitleSeed(value) {
  return String(value || "")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 120);
}

function isControlLikeSeed(value) {
  const text = String(value || "").trim();
  if (!text) return true;
  return /(?:memory-(?:v5-)?handoff|memory-(?:v5-)?lane|memory-control|devspace plain|先恢复并校准任务|恢复原对话上下文|确认任务目的.{0,20}当前主线|使用已连接的 (?:taskonward|memory v5)|待校准：power 自动建 lane|正式任务目的尚未)/i.test(text);
}

function conciseSeedPart(value, max = 42) {
  const text = cleanTitleSeed(value)
    .replace(/^[\s#>*\-–—:：]+/, "")
    .replace(/[。；;，,]+$/g, "")
    .trim();
  if (!text || isControlLikeSeed(text)) return "";
  return text.slice(0, max);
}

function continuationText(result) {
  const taskTitle = String(result?.task_title || "").trim();
  if (!taskTitle || /[\r\n]/.test(taskTitle)) {
    throw new Error("handoff_task_title_missing");
  }
  return [
    taskTitle + "|",
    "",
    "TaskOnward 续聊码：" + result.token,
    "",
    "请使用 TaskOnward 恢复这个任务。",
    "恢复摘要只使用 TaskOnward 返回的正式记录：任务目的、当前主线、关键已完成结论、已确认决定/约束和最后未完成节点；只有正式记录里确有已否决路线时才列出，空类别省略，禁止推断补全。",
    "摘要最后必须明确告诉我：如果恢复正确，请回复「确认」；如果不正确，直接指出需要修改的地方。",
    "我回复「确认」只表示确认这次恢复状态，不代表授权你立即继续执行原任务。确认后请只告诉我已接回任务和当前下一步，然后等待我的下一条指令。",
  ].join("\n");
}

function normalizedEmergencyContent(value) {
  return String(value || "")
    .replace(/^\s*(?:纯文本|复制代码|Copy code|已分析|Analyzed)\s*$/gim, "")
    .replace(/\s+/g, " ")
    .trim();
}

function emergencyDedupCanonical(value) {
  return normalizedEmergencyContent(value)
    .replace(/(?:\s|\u00a0)*(?:\.\.\.|…)+\s*$/u, "")
    .trim();
}

function emergencyContentEquivalent(a, b) {
  const left = emergencyDedupCanonical(a);
  const right = emergencyDedupCanonical(b);
  return Boolean(left && right && left === right);
}

function looksLikeInternalControlContent(value) {
  const text = String(value || "");
  if (looksLikeLocalEmergencyPackage(text)) return true;
  return [
    /\[memory-v5-(?:handoff|lane|version):[^\]]+\]/i,
    /\[memory-(?:handoff|lane):[^\]]+\]/i,
    /\[memory-control:sync:[^\]]+\]/i,
    /@(?:Lane|Version|EmergencyId)\s+\S+/i,
    /TaskOnward\s*续聊码\s*[:：]\s*[A-Za-z0-9_-]+/i,
    /(?:只)?使用已连接的\s*(?:TaskOnward|Memory V5 Beta)[\s\S]{0,240}(?:精确恢复|恢复并继续|handoff|Lane|checkpoint)/i,
  ].some((pattern) => pattern.test(text));
}

function publicEmergencyContent(value, maxBytes = 4 * 1024) {
  const text = String(value || "").trim();
  if (!text) return "（空）";
  if (containsHighConfidenceSecretText(text)) {
    return "（检测到敏感内容，正文已省略）";
  }
  if (looksLikeInternalControlContent(text)) {
    return "（这里是一条较早的 TaskOnward 接续指令，已省略。）";
  }
  return clipUtf8(text, maxBytes);
}

function emergencyPendingView(pending, hasCanonicalBaseline) {
  const items = Array.isArray(pending?.items) ? pending.items : [];
  if (hasCanonicalBaseline) {
    return {
      items,
      scope: "post_checkpoint_delta",
      omitted_before: 0,
    };
  }
  const selected = items.slice(-3);
  return {
    items: selected,
    scope: "recent_unanchored_tail",
    omitted_before: Math.max(0, items.length - selected.length),
  };
}

function publicEmergencyRecentText(
  recentContext,
  pending,
  assistantTail,
) {
  const rounds = Array.isArray(recentContext?.rounds)
    ? recentContext.rounds.slice(-3)
    : [];
  const pendingContents = new Set(
    (Array.isArray(pending?.items) ? pending.items : [])
      .map((item) => normalizedEmergencyContent(item?.content))
      .filter(Boolean)
  );
  let overflowed = Boolean(recentContext?.overflowed);
  let sensitiveOmitted = 0;
  const blocks = [];

  for (let index = 0; index < rounds.length; index += 1) {
    const round = rounds[index] || {};
    const rawUser = String(round?.user?.content || "").trim();
    const rawAssistant = String(round?.assistant?.content || "").trim();
    const normalizedUser = normalizedEmergencyContent(rawUser);
    const userDuplicate = normalizedUser && pendingContents.has(normalizedUser);
    const userText = userDuplicate
      ? "（同一请求已列在上方）"
      : publicEmergencyContent(rawUser, 2 * 1024);
    const assistantText = publicEmergencyContent(rawAssistant, 3 * 1024);
    if (rawUser && containsHighConfidenceSecretText(rawUser)) sensitiveOmitted += 1;
    if (rawAssistant && containsHighConfidenceSecretText(rawAssistant)) sensitiveOmitted += 1;
    if (rawUser && utf8Bytes(rawUser) > 2 * 1024) overflowed = true;
    if (rawAssistant && utf8Bytes(rawAssistant) > 3 * 1024) overflowed = true;
    blocks.push([
      "第 " + (index + 1) + " 轮",
      "用户：" + userText,
      "ChatGPT：" + assistantText,
    ].join("\n"));
  }

  const rawTail = String(assistantTail?.content || "").trim();
  if (rawTail && assistantTail?.generation_in_progress === true) {
    const alreadyIncluded = rounds.some((round) => {
      const value = normalizedEmergencyContent(round?.assistant?.content);
      const tail = normalizedEmergencyContent(rawTail);
      return Boolean(value && tail && (value === tail || value.includes(tail) || tail.includes(value)));
    });
    if (!alreadyIncluded) {
      if (containsHighConfidenceSecretText(rawTail)) sensitiveOmitted += 1;
      if (utf8Bytes(rawTail) > 3 * 1024) overflowed = true;
      blocks.push("ChatGPT（回答中）：" + publicEmergencyContent(rawTail, 3 * 1024));
    }
  }

  return {
    text: blocks.length ? blocks.join("\n\n") : "（没有读取到可用的最近对话）",
    overflowed,
    sensitive_omitted: sensitiveOmitted,
  };
}

function localEmergencyContinuationText({
  binding,
  pending,
  assistantTail,
  emergencyRecentContext,
  emergencyFingerprint,
}) {
  const hasCanonicalBaseline = Boolean(
    binding?.ready &&
    binding?.laneId &&
    Number.isInteger(binding?.savedVersion)
  );
  const pendingView = emergencyPendingView(pending, hasCanonicalBaseline);
  const pendingItems = pendingView.items;
  const pendingText = pendingItems.length
    ? pendingItems
        .map((item, index) =>
          (index + 1) + ". " + publicEmergencyContent(item?.content, 4 * 1024)
        )
        .join("\n\n")
    : "（没有读取到新的用户请求）";
  const recent = publicEmergencyRecentText(
    emergencyRecentContext,
    pending,
    assistantTail,
  );
  const warnings = [];
  if (pendingView.omitted_before > 0) {
    warnings.push("更早有部分内容未包含在这份临时恢复内容中。");
  }
  if (pending?.overflowed || recent.overflowed) {
    warnings.push("部分较长内容已缩短；无法确认的细节不要推断。");
  }
  const sensitiveOmitted =
    Number(pending?.sensitive_omitted || 0) + Number(recent.sensitive_omitted || 0);
  if (sensitiveOmitted > 0) {
    warnings.push("检测到敏感内容，相关正文没有复制。 ");
  }
  if (!hasCanonicalBaseline) {
    warnings.push("这份内容只代表最近读取到的对话，不代表完整历史。 ");
  }

  const text = [
    "TaskOnward 临时恢复",
    "",
    "TaskOnward 临时恢复编号：" + emergencyFingerprint,
    "",
    "TaskOnward 暂时无法连接。下面只带上这次接续真正需要的最近内容；服务恢复后，请重新使用 TaskOnward 继续。",
    "",
    "【最近请求】",
    pendingText,
    "",
    "【最近对话】",
    recent.text,
    warnings.length ? "" : "",
    warnings.length ? "注意：" + warnings.join(" ").trim() : "",
    "",
    "请先根据以上内容继续，并把无法确认的部分明确说出来。",
  ].filter(Boolean).join("\n");
  return clipUtf8(text, LOCAL_EMERGENCY_MAX_BYTES);
}

async function copyLocalEmergency({
  binding,
  pending,
  assistantTail,
  emergencyRecentContext,
  conversationId,
  reason,
  normalContinuation = false,
}) {
  const hasCanonicalBaseline = Boolean(
    binding?.ready &&
    binding?.laneId &&
    Number.isInteger(binding?.savedVersion)
  );
  const fingerprintPendingView = emergencyPendingView(
    pending,
    hasCanonicalBaseline
  );
  const emergencyFingerprint = (
    await sha256UrlSafe(JSON.stringify({
      laneId: hasCanonicalBaseline ? String(binding?.laneId || "") : "",
      savedVersion: hasCanonicalBaseline ? binding.savedVersion : null,
      sourceConversationId: String(conversationId || ""),
      saveBoundary: hasCanonicalBaseline
        ? String(binding?.lastSyncKey || "")
        : "",
      pendingScope: fingerprintPendingView.scope,
      pendingOmittedBefore: fingerprintPendingView.omitted_before,
      pendingOverflowed: Boolean(pending?.overflowed),
      pendingSensitiveOmitted: Number(pending?.sensitive_omitted || 0),
      pending: fingerprintPendingView.items.map((item) => ({
        turnId: String(item?.turnId || ""),
        content: emergencyDedupCanonical(item?.content),
      })),
      captureQuality: String(
        emergencyRecentContext?.capture_quality || "unavailable"
      ),
      recentOverflowed: Boolean(emergencyRecentContext?.overflowed),
      recent: Array.isArray(emergencyRecentContext?.rounds)
        ? emergencyRecentContext.rounds.slice(-3).map((round) => ({
            userId: String(round?.user?.turnId || ""),
            user: emergencyDedupCanonical(round?.user?.content),
            userTruncated: Boolean(round?.user?.truncated),
            userCompleteness: String(round?.user?.completeness || ""),
            assistantId: String(round?.assistant?.turnId || ""),
            assistant: emergencyDedupCanonical(round?.assistant?.content),
            assistantTruncated: Boolean(round?.assistant?.truncated),
            assistantCompleteness: String(
              round?.assistant?.completeness || ""
            ),
          }))
        : [],
      assistantTail: assistantTail?.generation_in_progress
        ? emergencyDedupCanonical(assistantTail?.content)
        : "",
    }))
  ).slice(0, 24);
  const text = localEmergencyContinuationText({
    binding,
    pending,
    assistantTail,
    emergencyRecentContext,
    emergencyFingerprint,
  });
  await copyWithOffscreen(text);
  return pageUi(
    normalContinuation ? "locked" : "degraded",
    normalContinuation
      ? "已复制续聊信息"
      : "正式续聊暂不可用 · 已复制应急续聊内容",
    normalContinuation
      ? "请打开新 Chat 后粘贴发送。这次只使用刚刚读取到的最近内容。"
      : "新建 Chat 后可以临时粘贴继续；服务恢复后请重新使用 TaskOnward 继续。",
    false,
    {
      emergencyLocal: !normalContinuation,
      localContinuationCopied: normalContinuation,
      emergencyFingerprint,
      reason: String(reason || ""),
    }
  );
}

async function ensureOffscreenDocument() {
  const offscreenUrl = chrome.runtime.getURL(OFFSCREEN_PATH);
  const contexts = await chrome.runtime.getContexts({
    contextTypes: ["OFFSCREEN_DOCUMENT"],
    documentUrls: [offscreenUrl],
  });
  if (contexts.length > 0) return;

  if (!offscreenCreating) {
    offscreenCreating = chrome.offscreen.createDocument({
      url: OFFSCREEN_PATH,
      reasons: ["CLIPBOARD"],
      justification: "Copy the one-time TaskOnward handoff command without exposing it to the ChatGPT page.",
    }).finally(() => {
      offscreenCreating = null;
    });
  }
  await offscreenCreating;
}

async function copyWithOffscreenOnce(text) {
  await ensureOffscreenDocument();
  try {
    const response = await chrome.runtime.sendMessage({
      target: "offscreen",
      type: "OFFSCREEN_COPY",
      text: String(text || ""),
    });
    if (!response?.ok) throw new Error(response?.error || "clipboard_copy_failed");
    return true;
  } finally {
    await chrome.offscreen.closeDocument().catch(() => {});
  }
}

function copyWithOffscreen(text) {
  const operation = clipboardCopyQueue.then(() => copyWithOffscreenOnce(text));
  clipboardCopyQueue = operation.catch(() => {});
  return operation;
}

async function detectUniqueCanonicalMarkerInTab(tabId) {
  if (!Number.isInteger(tabId)) return null;
  const results = await chrome.scripting.executeScript({
    target: { tabId },
    func: () => {
      const userTurns = document.querySelectorAll(
        '[data-message-author-role="user"]'
      );
      const markers = [];
      for (const node of userTurns) {
        const text = String(node.textContent || "");
        const brandedToken =
          text.match(/TaskOnward\s*续聊码\s*[:：]\s*([A-Za-z0-9_-]+)/i)?.[1] || "";
        if (brandedToken) {
          markers.push({ token: brandedToken, laneId: null, savedVersion: null });
          continue;
        }
        if (
          !/(?:只)?使用已连接的\s*(?:TaskOnward|Memory V5 Beta)/i.test(text) ||
          !/(?:精确恢复(?:并锁定)?原任务线|精确恢复此任务)/.test(text)
        ) {
          continue;
        }
        const token = text.match(
          /\[memory-v5-handoff:([A-Za-z0-9_-]+)\]/
        )?.[1];
        const laneId = text.match(
          /\[memory-v5-lane:(lane_[A-Za-z0-9_-]+)\]/
        )?.[1];
        const versionRaw = text.match(
          /\[memory-v5-version:(\d+)\]/
        )?.[1];
        if (!token || !laneId) continue;
        markers.push({
          token,
          laneId,
          savedVersion:
            versionRaw != null && Number.isSafeInteger(Number(versionRaw))
              ? Number(versionRaw)
              : null,
        });
      }
      const tokens = [...new Set(markers.map((item) => item.token))];
      if (tokens.length !== 1) return null;
      const lanes = [
        ...new Set(markers.map((item) => item.laneId).filter(Boolean)),
      ];
      const versions = [
        ...new Set(
          markers
            .map((item) => item.savedVersion)
            .filter((value) => Number.isSafeInteger(value))
        ),
      ];
      if (lanes.length > 1 || versions.length > 1) return null;
      return {
        token: tokens[0],
        laneId: lanes.length === 1 ? lanes[0] : null,
        savedVersion: versions.length === 1 ? versions[0] : null,
      };
    },
  }).catch(() => []);
  const marker = results?.[0]?.result;
  if (!marker || typeof marker.token !== "string" || !marker.token) {
    return null;
  }
  return {
    token: marker.token,
    laneId:
      typeof marker.laneId === "string" && marker.laneId.startsWith("lane_")
        ? marker.laneId
        : null,
    savedVersion: Number.isSafeInteger(marker.savedVersion)
      ? marker.savedVersion
      : null,
  };
}

async function resolveBindingForPage(
  conversationId,
  titleSeed = "",
  tabId = null,
  { scanPageMarker = true, markerHint = null } = {}
) {
  if (!conversationId) return null;
  const existing = await getBinding(conversationId);

  // A canonical handoff marker in the current Chat is stronger evidence than a
  // stale browser cache and may safely repair that cache without cloud traffic.
  const exactMarker = markerHint?.laneId
    ? markerHint
    : scanPageMarker && Number.isInteger(tabId)
      ? await detectUniqueCanonicalMarkerInTab(tabId)
      : null;
  if (exactMarker?.laneId) {
      if (
        !existing?.laneId ||
        existing.laneId !== exactMarker.laneId ||
        (
          Number.isSafeInteger(exactMarker.savedVersion) &&
          existing.savedVersion !== exactMarker.savedVersion
        ) ||
        existing.readinessSource !== "canonical_handoff"
      ) {
        return setBinding(
          conversationId,
          exactMarker.laneId,
          titleSeed,
          {
            ready: true,
            savedVersion: exactMarker.savedVersion,
            lastSyncKey: "",
            readinessSource: "canonical_handoff",
          }
        );
      }
      return existing;
  }

  return existing?.laneId ? existing : null;
}

async function reconcileRemoteBinding(
  conversationId,
  titleSeed = ""
) {
  if (!conversationId) return null;
  const result = await companionPost("/companion/binding/get", {
    source_conversation_id: conversationId,
  });
  if (!result?.binding?.lane_id || !result?.lane_id) {
    return null;
  }

  const ready = Boolean(result.ready);
  return setBinding(
    conversationId,
    result.lane_id,
    titleSeed,
    {
      ready,
      savedVersion: Number.isSafeInteger(result.current_version)
        ? result.current_version
        : null,
      lastSyncKey: "",
      readinessSource: "remote_binding",
      lifecycleState: String(result.lifecycle_state || ""),
      resumeConfirmationRequired: Boolean(
        result.resume_confirmation_required
      ),
    }
  );
}

async function pendingStateFingerprint(pending) {
  const items = Array.isArray(pending?.items) ? pending.items : [];
  return sha256UrlSafe(JSON.stringify({
    items: items.map((item) => ({
      turnId: String(item?.turnId || item?.turn_id || ""),
      content: String(item?.content || ""),
    })),
    overflowed: Boolean(pending?.overflowed),
    sensitiveOmitted: Number(
      pending?.sensitiveOmitted ?? pending?.sensitive_omitted ?? 0
    ),
  }));
}

async function reconcileActiveSourceHandoff(
  conversationId,
  currentPending = null
) {
  const active = await activeHandoffGet(conversationId);
  if (!active?.token) return { state: "none" };

  let status;
  try {
    status = await companionPost("/companion/handoff/status", {
      token: active.token,
    });
  } catch (error) {
    const reason = String(error?.message || error);
    if (reason === "handoff_not_found") {
      await activeHandoffClear(conversationId);
      return { state: "missing" };
    }
    throw error;
  }

  if (status?.confirmed) {
    let diverged = true;
    if (active.pendingFingerprint && currentPending) {
      const currentFingerprint = await pendingStateFingerprint(currentPending);
      diverged = currentFingerprint !== active.pendingFingerprint;
    }
    // A handoff created by an older resident version has no reliable on-demand
    // fingerprint. Fail safe instead of trusting stale local capture state.
    await activeHandoffClear(conversationId);
    return {
      state: diverged ? "retired_diverged" : "retired",
      laneId: status.lane_id || active.laneId || null,
      confirmedVersion:
        Number.isInteger(status.confirmed_version)
          ? status.confirmed_version
          : null,
    };
  }

  if (status?.handoff_status === "expired") {
    await activeHandoffClear(conversationId);
    return { state: "expired" };
  }

  const currentFingerprint =
    active.pendingFingerprint && currentPending
      ? await pendingStateFingerprint(currentPending)
      : "";
  const samePending =
    Boolean(active.pendingFingerprint) &&
    Boolean(currentFingerprint) &&
    currentFingerprint === active.pendingFingerprint;

  if (status?.handoff_status === "consumed") {
    return {
      state: "target_in_progress",
      laneId: status.lane_id || active.laneId || null,
      token: active.token,
      copyText: String(active.copyText || ""),
      samePending,
    };
  }

  if (
    status?.handoff_status === "pending" &&
    status?.target_bound
  ) {
    return {
      state: "target_in_progress",
      laneId: status.lane_id || active.laneId || null,
      token: active.token,
      copyText: String(active.copyText || ""),
      samePending,
    };
  }

  if (
    status?.handoff_status === "pending" &&
    samePending &&
    active.copyText
  ) {
    return {
      state: "reusable_pending",
      laneId: status.lane_id || active.laneId || null,
      token: active.token,
      copyText: String(active.copyText),
    };
  }

  return {
    state: "refreshable_pending",
    laneId: status?.lane_id || active.laneId || null,
    token: active.token,
  };
}

async function ensureRemoteConversationLane(
  conversationId,
  titleSeed = ""
) {
  if (!conversationId) throw new Error("conversation_id_missing");
  const result = await companionPost("/companion/binding/ensure", {
    source_conversation_id: conversationId,
    title_seed: String(titleSeed || "").slice(0, 120),
  });
  if (!result?.lane_id || !result?.binding?.lane_id) {
    throw new Error("binding_ensure_failed");
  }
  if (result.lane_id !== result.binding.lane_id) {
    throw new Error("binding_ensure_mismatch");
  }
  return setBinding(
    conversationId,
    result.lane_id,
    titleSeed,
    {
      ready: Boolean(result.ready),
      savedVersion: Number.isSafeInteger(result.current_version)
        ? result.current_version
        : null,
      lastSyncKey: "",
      readinessSource: "remote_binding",
      lifecycleState: String(result.lifecycle_state || ""),
      resumeConfirmationRequired: Boolean(
        result.resume_confirmation_required
      ),
    }
  );
}

function pageUi(state, title = "", toast = "", toastError = false, extra = {}) {
  return { state, title, toast, toastError, ...extra };
}

function exactResumePendingUi(reason = "service_unavailable") {
  return pageUi(
    "degraded",
    "续聊身份已保存",
    "TaskOnward 暂时无法完成精确恢复；续聊身份已保留。网络或登录恢复后重新点击 Power 即可继续，不会改成新任务。",
    false,
    {
      exactResumePending: true,
      retryReason: String(reason || "service_unavailable"),
    }
  );
}

async function prebindClaimedResumeBeforeCapture({
  conversationId,
  titleSeed = "",
}) {
  const claimedResume = await resumeClaimGet(conversationId);
  if (!claimedResume?.token) return { status: "none" };

  let auth = await authStatus();
  if (!auth.configured || !auth.authenticated) {
    try {
      await login();
      auth = await authStatus();
    } catch {
      return {
        status: "pending",
        ui: exactResumePendingUi("auth_unavailable"),
      };
    }
  }

  try {
    const binding = await bindConversationFromResumeToken({
      conversationId,
      token: claimedResume.token,
      titleSeed,
    });
    await resumeClaimClear(conversationId);
    return { status: "bound", binding };
  } catch (error) {
    const reason = String(error?.message || error);
    if (isTransientServiceError(reason)) {
      return { status: "pending", ui: exactResumePendingUi(reason) };
    }
    if (terminalResumeAttachError(reason)) {
      await resumeClaimClear(conversationId);
      throw error;
    }
    return { status: "pending", ui: exactResumePendingUi(reason) };
  }
}

async function handlePowerActivate(message, sender = {}) {
  const tabId = sender?.tab?.id;
  const tabUrl = String(sender?.tab?.url || "");
  if (!Number.isInteger(tabId) || !tabUrl.startsWith("https://chatgpt.com/")) {
    throw new Error("power_activation_requires_chatgpt_tab");
  }

  const runtimeVersion = chrome.runtime.getManifest().version;
  if (String(message?.pageVersion || "") !== runtimeVersion) {
    await injectCurrentArchitecture(tabId);
    return pageUi(
      "idle",
      "TaskOnward 已更新",
      "页面按钮已更新到 " + runtimeVersion + "，请再点一次 Power。"
    );
  }

  const conversationId = conversationIdFromUrl(tabUrl);
  if (!conversationId) {
    return pageUi(
      "idle",
      "当前还没有可接续的 Chat",
      "先在 ChatGPT 中发送至少一条消息，等当前 Chat 获得正式地址后再点 Power。"
    );
  }

  // Exact recovery identity is more important than transcript capture. A
  // durable Conversation claim was written when the continuation code was
  // pasted. Bind that exact task first, before any DOM collection, so a
  // transient/virtualized ChatGPT page cannot strand the recovery identity.
  const preboundResume = await prebindClaimedResumeBeforeCapture({
    conversationId,
    titleSeed: cleanTitleSeed(sender?.tab?.title || ""),
  });
  if (preboundResume.status === "pending") {
    return preboundResume.ui;
  }

  const snapshot = await collectConversationSnapshot(tabId);

  if (snapshot.generationInProgress) {
    return pageUi(
      "busy",
      "ChatGPT 还在生成",
      "等当前回答完整结束后再点 Power；生成期间 TaskOnward 不读取对话。"
    );
  }

  if (
    snapshot?.latestDialogue?.user &&
    snapshot?.latestDialogue?.assistant_complete !== true
  ) {
    return pageUi(
      "error",
      "没有可靠读取到最后一条回复",
      "TaskOnward 已停止本次接续，不会在缺少最后回复的情况下复制续聊内容。请确认当前回答已经结束后再试。",
      true
    );
  }


  const pathname = (() => {
    try {
      return new URL(tabUrl).pathname;
    } catch {
      return "";
    }
  })();

  const trustedMessage = {
    type: "POWER_PAGE_CLICK",
    pageVersion: runtimeVersion,
    context: {
      conversationId,
      titleSeed: cleanTitleSeed(sender?.tab?.title || ""),
      pathname,
    },
    pendingUser: snapshot.pendingUser,
    assistantTail: snapshot.assistantTail,
    emergencyRecentContext: null,
    assistantCaptureDiagnostic: {
      ...(snapshot.diagnostic || {}),
      capture_mode: snapshot.captureMode,
      boundary_strategy: snapshot?.boundary?.type || "none",
      latest_dialogue_complete:
        snapshot?.latestDialogue?.assistant_complete === true,
    },
    canonicalMarker: snapshot.canonicalMarker,
    canonicalMarkerAmbiguous: Boolean(snapshot.canonicalMarkerAmbiguous),
    captureMode: snapshot.captureMode,
    bootstrapTruncated:
      snapshot?.pendingUser?.bootstrap_truncated === true,
    latestDialogue: snapshot.latestDialogue,
  };

  let result = await pageClick(trustedMessage, sender);
  if (result?.needsEmergencyContext) {
    const emergencyRecentContext = await collectEmergencyRecentContext(tabId);
    result = await pageClick(
      {
        ...trustedMessage,
        emergencyRecentContext,
        emergencyOnlyReason: String(
          result.emergencyReason || "service_unavailable"
        ),
      },
      sender,
    );
  }
  if (
    result?.state === "locked" &&
    snapshot.captureMode === "bootstrap_recent" &&
    snapshot?.pendingUser?.bootstrap_truncated
  ) {
    return {
      ...result,
      detail:
        String(result.detail || "") +
        " 首次接入会带上最初请求和最近对话；中间较早内容不会被自动猜测。",
      warning: true,
    };
  }
  return result;
}

function localEmergencyOrRequest({
  binding,
  pending,
  assistantTail,
  emergencyRecentContext,
  conversationId,
  titleSeed,
  reason,
}) {
  if (!emergencyRecentContext) {
    return pageUi(
      "busy",
      "正在准备本地应急续聊…",
      "",
      false,
      {
        needsEmergencyContext: true,
        emergencyReason: String(reason || "service_unavailable"),
      }
    );
  }
  return copyLocalEmergency({
    binding,
    pending,
    assistantTail,
    emergencyRecentContext,
    conversationId,
    reason,
  });
}

async function pageClick(message, sender = {}) {
  const context = message.context || {};
  const conversationId = context.conversationId || null;
  if (!conversationId) {
    return pageUi("idle", "当前还没有可绑定的 Chat");
  }

  const pending = pendingForHandoff(
    message.pendingUser || message.pendingUserSnapshot
  );
  const assistantTail =
    message.assistantTail && typeof message.assistantTail === "object"
      ? message.assistantTail
      : null;
  const emergencyRecentContext =
    message.emergencyRecentContext &&
    typeof message.emergencyRecentContext === "object"
      ? message.emergencyRecentContext
      : null;
  const emergencyOnlyReason = String(message.emergencyOnlyReason || "").trim();

  // The second leg of a local Emergency must stay local-only: do not repeat
  // marker DOM scans, auth, health, or network work after context capture.
  if (emergencyOnlyReason && emergencyRecentContext) {
    const localBinding = await getBinding(conversationId);
    return copyLocalEmergency({
      binding: localBinding,
      pending,
      assistantTail,
      emergencyRecentContext,
      conversationId,
      titleSeed: context.titleSeed || localBinding?.titleSeed || "",
      reason: emergencyOnlyReason,
    });
  }

  let binding = await resolveBindingForPage(
    conversationId,
    context.titleSeed || "",
    sender?.tab?.id,
    {
      scanPageMarker: false,
      markerHint: message.canonicalMarker || null,
    }
  );
  const localActiveHandoff = await activeHandoffGet(conversationId);
  const claimedResume = await resumeClaimGet(conversationId);
  const armedResume = Number.isInteger(sender?.tab?.id)
    ? await resumeArmGet(sender.tab.id)
    : null;
  let explicitResumeToken = String(
    message?.canonicalMarker?.token ||
    claimedResume?.token ||
    ""
  ).trim();

  // If a resume send was armed but the asynchronous witness has not yet
  // promoted it to a durable Conversation claim, an explicit Power click gets
  // one more exact-token check. Never fall through to first-use bootstrap while
  // a resume identity is still unresolved.
  if (
    !explicitResumeToken &&
    armedResume?.token &&
    Number.isInteger(sender?.tab?.id)
  ) {
    let witnessed = false;
    try {
      witnessed = await verifyResumeTokenInTab(
        sender.tab.id,
        armedResume.token,
      );
    } catch {
      witnessed = false;
    }
    if (witnessed) {
      await resumeClaimSet(conversationId, armedResume.token);
      await resumeArmClear(sender.tab.id);
      explicitResumeToken = armedResume.token;
    } else if (!binding?.laneId || !binding.ready) {
      return pageUi(
        "degraded",
        "正在确认续聊身份",
        "TaskOnward 还没在当前 Chat 中确认到刚发送的续聊码。请等待消息发送完成后再点 Power；不会新建另一条任务。",
        false,
        {
          exactResumePending: true,
          resumeWitnessPending: true,
        }
      );
    } else {
      // An exact canonical binding is stronger evidence than a stale tab arm.
      await resumeArmClear(sender.tab.id);
    }
  }

  const health = await backendHealthGet();
  if (
    health &&
    Number(health.blockedUntil || 0) > Date.now()
  ) {
    if (explicitResumeToken) {
      return exactResumePendingUi(String(health.reason || "service_unavailable"));
    }
    if (localActiveHandoff?.token) {
      return pageUi(
        "degraded",
        "已有续聊正在交接",
        "TaskOnward 暂时无法确认交接状态；已保存的续聊不会被覆盖，请稍后重试。",
        false,
        { handoffStateUnknown: true }
      );
    }
    return localEmergencyOrRequest({
      binding,
      pending,
      assistantTail,
      emergencyRecentContext,
      conversationId,
      titleSeed: context.titleSeed || binding?.titleSeed || "",
      reason: String(health.reason || "service_unavailable"),
    });
  }

  let auth = await authStatus();
  if (!auth.configured || !auth.authenticated) {
    try {
      await login();
      auth = await authStatus();
    } catch (error) {
      if (explicitResumeToken) {
        return exactResumePendingUi("auth_unavailable");
      }
      if (localActiveHandoff?.token) {
        return pageUi(
          "degraded",
          "已有续聊正在交接",
          "TaskOnward 暂时无法确认交接状态；已保存的续聊不会被覆盖，请稍后重试。",
          false,
          { handoffStateUnknown: true }
        );
      }
      return localEmergencyOrRequest({
        binding,
        pending,
        assistantTail,
        emergencyRecentContext,
        conversationId,
        titleSeed: context.titleSeed || binding?.titleSeed || "",
        reason: "auth_unavailable:" + String(error?.message || error),
      });
    }
  }

  const resumeToken = explicitResumeToken;
  if (resumeToken) {
    // At this point the token came from either a durable claim, an armed token
    // that just passed an exact page witness, or the one-shot Power collector's
    // exact marker in this Conversation. Persist that exact identity before any
    // network work so a transient outage cannot make the resumed task anonymous.
    await resumeClaimSet(conversationId, resumeToken);
    try {
      binding = await bindConversationFromResumeToken({
        conversationId,
        token: resumeToken,
        titleSeed: context.titleSeed || binding?.titleSeed || "",
      });
      await resumeClaimClear(conversationId);
      if (Number.isInteger(sender?.tab?.id)) {
        await resumeArmClear(sender.tab.id);
      }
    } catch (resumeBindError) {
      const reason = String(resumeBindError?.message || resumeBindError);
      if (isTransientServiceError(reason)) {
        return exactResumePendingUi(reason);
      }
      // Preserve exact local identity evidence for non-terminal conflicts so a
      // later repaired backend/binding can retry without falling through to a
      // new provisional task. Only proofs that can never be valid for this
      // Conversation are discarded.
      if (terminalResumeAttachError(reason)) {
        await resumeClaimClear(conversationId);
        if (Number.isInteger(sender?.tab?.id)) {
          await resumeArmClear(sender.tab.id);
        }
        throw resumeBindError;
      }
      return exactResumePendingUi(reason);
    }
  }

  // User contract: every explicit Power click creates the newest handoff.
  // Any older unconfirmed handoff from this exact source Conversation is
  // superseded server-side, even if it was never pasted or was already opened
  // in another Chat but not confirmed. The latest click is authoritative.
  if (!binding?.laneId || !binding.ready) {
    try {
      const reconciled = await reconcileRemoteBinding(
        conversationId,
        context.titleSeed || binding?.titleSeed || ""
      );
      if (reconciled?.laneId) {
        binding = reconciled;
      } else if (binding?.laneId) {
        await clearBinding(conversationId);
        binding = null;
      }

      if (!binding?.laneId && message.canonicalMarkerAmbiguous) {
        return pageUi(
          "error",
          "当前 Chat 里有多份不同的续聊码",
          "TaskOnward 没有找到这个 Chat 的正式绑定。请重新发送本任务最近一次 TaskOnward 续聊内容后再点 Power。",
          true,
          {
            continuationUnavailable: true,
            reason: "ambiguous_resume_without_binding",
          }
        );
      }

      if (!binding?.laneId) {
        binding = await ensureRemoteConversationLane(
          conversationId,
          context.titleSeed || ""
        );
      }
    } catch (error) {
      if (isTransientServiceError(error?.message || error)) {
        return localEmergencyOrRequest({
          binding,
          pending,
          assistantTail,
          emergencyRecentContext,
          conversationId,
          titleSeed: context.titleSeed || binding?.titleSeed || "",
          reason: String(error?.message || error),
        });
      }
      throw error;
    }
  }

  if (
    binding?.resumeConfirmationRequired &&
    binding?.lifecycleState === "provisional"
  ) {
    return pageUi(
      "idle",
      "请先确认当前恢复摘要",
      "首次恢复还没有完成确认。确认后再点 Power。",
      false,
      {
        resumeConfirmationRequired: true,
        laneId: binding.laneId || null,
        savedVersion: Number.isInteger(binding.savedVersion)
          ? binding.savedVersion
          : null,
      }
    );
  }

  if (
    !binding?.laneId ||
    (
      !binding.ready &&
      binding.lifecycleState !== "provisional" &&
      !(
        binding.resumeConfirmationRequired &&
        binding.lifecycleState === "canonical"
      )
    )
  ) {
    throw new Error("binding_not_ready");
  }

  if (
    binding?.readinessSource === "canonical_handoff" &&
    Number.isInteger(sender?.tab?.id)
  ) {
    const marker =
      message.canonicalMarker ||
      await detectUniqueCanonicalMarkerInTab(sender.tab.id);
    if (
      marker?.token &&
      marker.laneId === binding.laneId &&
      Number.isSafeInteger(marker.savedVersion)
    ) {
      try {
        binding = await bindConversationFromHandoffProof({
          conversationId,
          token: marker.token,
          laneId: marker.laneId,
          savedVersion: marker.savedVersion,
          titleSeed: context.titleSeed || binding?.titleSeed || "",
        });
      } catch (proofError) {
        if (isTransientServiceError(proofError?.message || proofError)) {
          return localEmergencyOrRequest({
            binding,
            pending,
            assistantTail,
            emergencyRecentContext,
            conversationId,
            titleSeed: context.titleSeed || binding?.titleSeed || "",
            reason: String(proofError?.message || proofError),
          });
        }
        try {
          const reconciled = await reconcileRemoteBinding(
            conversationId,
            context.titleSeed || binding?.titleSeed || ""
          );
          if (reconciled?.laneId && reconciled.ready) {
            binding = reconciled;
          } else {
            await clearBinding(conversationId);
            binding = null;
          }
        } catch (reconcileError) {
          if (isTransientServiceError(reconcileError?.message || reconcileError)) {
            return localEmergencyOrRequest({
              binding,
              pending,
              assistantTail,
              emergencyRecentContext,
              conversationId,
              titleSeed: context.titleSeed || binding?.titleSeed || "",
              reason: String(reconcileError?.message || reconcileError),
            });
          }
          throw reconcileError;
        }
      }
    }
  }

  if (
    binding?.resumeConfirmationRequired &&
    binding?.lifecycleState === "provisional"
  ) {
    return pageUi(
      "idle",
      "请先确认当前恢复摘要",
      "首次恢复还没有完成确认。确认后再点 Power。",
      false,
      {
        resumeConfirmationRequired: true,
        laneId: binding.laneId || null,
        savedVersion: Number.isInteger(binding.savedVersion)
          ? binding.savedVersion
          : null,
      }
    );
  }

  if (
    !binding?.laneId ||
    (
      !binding.ready &&
      binding.lifecycleState !== "provisional" &&
      !(
        binding.resumeConfirmationRequired &&
        binding.lifecycleState === "canonical"
      )
    )
  ) {
    throw new Error("binding_not_ready_after_handoff_proof");
  }

  const canonicalRecentFallback =
    Boolean(binding?.ready) &&
    (
      message.captureMode === "bootstrap_recent" ||
      Boolean(message?.assistantCaptureDiagnostic?.post_boundary_overflow) ||
      Boolean(message.canonicalMarkerAmbiguous)
    );

  // A provisional V1 is only an identity anchor. Never mint a formal
  // continuation from an empty provisional state: that produces a token which
  // is exact about identity but contains no task to recover. A genuine first
  // bootstrap must carry at least one bounded user turn from the source Chat.
  if (
    binding?.lifecycleState === "provisional" &&
    !binding?.resumeConfirmationRequired &&
    (!Array.isArray(pending?.items) || pending.items.length === 0)
  ) {
    return pageUi(
      "error",
      "当前 Chat 没有可恢复的任务内容",
      "TaskOnward 没有生成续聊信息。这个 Chat 的任务身份没有正确接上；请回到原任务 Chat，或重新发送最近一次有效的 TaskOnward 续聊内容后再试。",
      true,
      {
        continuationUnavailable: true,
        reason: "provisional_bootstrap_context_missing",
      }
    );
  }

  if (
    message?.assistantCaptureDiagnostic?.post_boundary_overflow &&
    !binding?.ready
  ) {
    return pageUi(
      "error",
      "当前任务状态还没有完成绑定",
      "TaskOnward 已读取到较长的新内容，但当前 Chat 还没有可靠绑定到正式任务。请重新粘贴本任务的 TaskOnward 续聊内容后再试。",
      true,
      {
        continuationUnavailable: true,
        reason: "long_delta_without_canonical_binding",
      }
    );
  }

  const prepareHandoff = (activeBinding) =>
    companionPost("/companion/handoff/prepare", {
      lane_id: activeBinding.laneId,
      source_conversation_id: conversationId,
      local_pending_user: pending,
      assistant_tail: assistantTail,
      allow_provisional_bootstrap:
        activeBinding?.lifecycleState === "provisional" &&
        !activeBinding?.resumeConfirmationRequired,
      recent_context_fallback: canonicalRecentFallback,
      existing_token: null,
      supersede_open_handoff: true,
    });

  let prepared;
  try {
    prepared = await prepareHandoff(binding);
  } catch (error) {
    const messageText = String(error?.message || error);
    if (
      messageText === "binding_conflict" ||
      messageText === "binding_missing" ||
      messageText === "lane_not_found"
    ) {
      try {
        const reconciled = await reconcileRemoteBinding(
          conversationId,
          context.titleSeed || binding?.titleSeed || ""
        );
        if (reconciled?.laneId) {
          binding = reconciled;
        } else {
          await clearBinding(conversationId);
          binding = await ensureRemoteConversationLane(
            conversationId,
            context.titleSeed || ""
          );
        }

        if (
          binding?.resumeConfirmationRequired &&
          binding?.lifecycleState === "provisional"
        ) {
          return pageUi(
            "idle",
            "请先确认当前恢复摘要",
            "首次恢复还没有完成确认。确认后再点 Power。",
            false,
            {
              resumeConfirmationRequired: true,
              laneId: binding.laneId || null,
            }
          );
        }
        if (
          !binding?.laneId ||
          (
            !binding.ready &&
            binding.lifecycleState !== "provisional" &&
            !(
              binding.resumeConfirmationRequired &&
              binding.lifecycleState === "canonical"
            )
          )
        ) {
          throw new Error("binding_not_ready_after_reconcile");
        }
        prepared = await prepareHandoff(binding);
      } catch (reconcileError) {
        if (
          isTransientServiceError(
            reconcileError?.message || reconcileError
          )
        ) {
          return localEmergencyOrRequest({
            binding,
            pending,
            assistantTail,
            emergencyRecentContext,
            conversationId,
            titleSeed: context.titleSeed || binding?.titleSeed || "",
            reason: String(
              reconcileError?.message || reconcileError
            ),
          });
        }
        throw reconcileError;
      }
    } else if (messageText === "source_conversation_retired") {
      return pageUi(
        "idle",
        "此窗口已完成交接",
        "请继续使用已确认的新 Chat。旧窗口不会重新成为任务主线。",
        false,
        {
          sourceConversationRetired: true,
          laneId: binding?.laneId || null,
        }
      );
    } else if (isTransientServiceError(messageText)) {
      return localEmergencyOrRequest({
        binding,
        pending,
        assistantTail,
        emergencyRecentContext,
        conversationId,
        titleSeed: context.titleSeed || binding?.titleSeed || "",
        reason: messageText,
      });
    } else {
      throw error;
    }
  }

  if (Number(prepared?.coverage?.pending_user_sensitive_omitted || 0) > 0) {
    return pageUi(
      "error",
      "检测到敏感的未保存内容 · 已停止续聊",
      "为避免泄露或丢失，Power 没有复制正式续聊内容。请处理该敏感内容后重新点击 Power。",
      true,
      {
        continuationUnavailable: true,
        handoffCopied: false,
        reason: "sensitive_pending_not_uploaded",
      }
    );
  }

  const text = continuationText(prepared);
  await activeHandoffSet(conversationId, {
    token: prepared.token,
    laneId: prepared.lane_id,
    snapshotVersion: prepared.snapshot_version,
    pendingFingerprint: await pendingStateFingerprint(pending),
    copyText: text,
    expiresAt: prepared.expires_at || null,
  });
  await copyWithOffscreen(text);

  const pendingCount = Number(prepared.pending_turn_count || 0);
  const assistantTailCaptured = Boolean(prepared.assistant_tail_captured);
  const assistantTailStatus = String(prepared.assistant_tail_status || "");
  const tailWarning =
    pendingCount > 0 && !assistantTailCaptured
      ? assistantTailStatus === "omitted_sensitive"
        ? "；检测到敏感内容，最近回复未随续聊保存。"
        : assistantTailStatus === "omitted_too_large"
          ? "；最近回复过长，未随续聊保存。"
          : "；最近回复未能可靠随续聊保存。"
      : "";
  return pageUi(
    "locked",
    "已保存，续聊内容已复制",
    pendingCount > 0
      ? "续聊内容已复制；已带上 " + pendingCount + " 条最新请求" +
        (assistantTailCaptured ? "和最近回复。" : tailWarning)
      : "续聊内容已复制。请打开新 Chat 后粘贴发送。",
    pendingCount > 0 && !assistantTailCaptured,
    { handoffCopied: true }
  );
}

async function handle(message, sender = {}) {
  if (!message || typeof message.type !== "string") {
    throw new Error("invalid_message");
  }

  if (message.type === "POWER_ACTIVATE") {
    return handlePowerActivate(message, sender);
  }
  if (message.type === "POWER_POPUP_ACTIVATE") {
    const [activeTab] = await chrome.tabs.query({
      active: true,
      currentWindow: true,
    });
    if (
      !activeTab?.id ||
      !String(activeTab.url || "").startsWith("https://chatgpt.com/")
    ) {
      return pageUi(
        "idle",
        "当前不是 ChatGPT",
        "请先切到需要续聊的 ChatGPT 对话，再点击这里。"
      );
    }
    return handlePowerActivate(
      {
        type: "POWER_ACTIVATE",
        pageVersion: chrome.runtime.getManifest().version,
      },
      { tab: activeTab }
    );
  }
  if (message.type === "POWER_RESUME_ARM") {
    const tabId = sender?.tab?.id;
    const token = String(message?.token || "").trim();
    if (!Number.isInteger(tabId) || !/^(?:to|mh)_[A-Za-z0-9_-]+$/.test(token)) {
      throw new Error("resume_arm_invalid");
    }
    // Record the exact opaque token locally only; never touch the network on
    // paste. If ChatGPT has already assigned this tab a Conversation URL, the
    // paste itself is enough to durably associate the token with that exact
    // Conversation so extension reloads / DOM virtualization cannot erase the
    // recovery identity before the next explicit Power click. Root/new-chat
    // pages still use the short-lived tab arm until a Conversation URL exists.
    await resumeArmSet(tabId, token);
    const pastedConversationId = conversationIdFromUrl(sender?.tab?.url || "");
    if (pastedConversationId) {
      await resumeClaimSet(pastedConversationId, token);
    }
    return {
      state: "idle",
      resumeArmed: true,
      resumeClaimed: Boolean(pastedConversationId),
    };
  }
  if (message.type === "POWER_AUTH_STATUS") return authStatus();
  if (message.type === "POWER_AUTH_LOGIN") return login();
  if (message.type === "POWER_AUTH_LOGOUT") {
    await storageRemove(AUTH_KEY);
    return { authenticated: false };
  }

  throw new Error("unknown_message_type");
}

chrome.runtime.onInstalled.addListener((details) => {
  chrome.offscreen.closeDocument().catch(() => {}).finally(() => {
    rehydrateOpenChatgptTabs(details?.reason || "onInstalled").catch(() => {});
  });
});

chrome.runtime.onStartup?.addListener?.(() => {
  chrome.offscreen.closeDocument().catch(() => {}).finally(() => {
    rehydrateOpenChatgptTabs("onStartup").catch(() => {});
  });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.target === "offscreen") return false;

  handle(message, sender)
    .then((data) => sendResponse({ ok: true, data }))
    .catch((error) => sendResponse(externalFailure(error)));
  return true;
});

// Identity-only route hook. It does nothing unless this tab was explicitly
// armed by pasting a TaskOnward continuation code. URL assignment and the
// eventual "complete" event each provide a one-shot chance to verify that the
// exact token is now visible in the target Conversation and bind it durably.
// No page-side polling/timer is needed.
chrome.tabs?.onUpdated?.addListener?.((tabId, changeInfo, tab) => {
  if (!changeInfo?.url && changeInfo?.status !== "complete") return;
  const tabUrl = String(changeInfo?.url || tab?.url || "");
  if (!tabUrl.startsWith("https://chatgpt.com/")) return;
  attachArmedResumeForTab(
    tabId,
    tabUrl,
    cleanTitleSeed(tab?.title || "")
  ).catch(() => {});
});
