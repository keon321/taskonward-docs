(() => {
  const AGENT_KEY = "__taskOnwardPowerPageAgent";
  const ROOT_ID = "memory-v5-power-root";
  const VERSION = "0.8.3";
  const RESUME_RE = /TaskOnward\s*续聊码\s*[:：]\s*((?:to|mh)_[A-Za-z0-9_-]+)/i;

  // Dormant stub: normal ChatGPT use must stay out of TaskOnward logic.
  // Persistent behavior is limited to:
  // 1) the Power button click;
  // 2) one paste hook that only recognizes an exact TaskOnward continuation code.
  // There is no page-side witness loop, polling, route watcher, or chat DOM scan.
  try { globalThis[AGENT_KEY]?.stop?.(); } catch {}
  const abort = new AbortController();
  document.getElementById(ROOT_ID)?.remove();

  const root = document.createElement("div");
  root.id = ROOT_ID;
  Object.assign(root.style, {
    position: "fixed",
    right: "18px",
    top: "52%",
    zIndex: "2147483646",
    pointerEvents: "auto",
  });

  const shadow = root.attachShadow({ mode: "closed" });
  const style = document.createElement("style");
  style.textContent = `
    :host { all: initial; }
    button {
      width: 30px; height: 30px; border: 0; border-radius: 10px;
      box-shadow: 0 6px 18px rgba(15,23,42,.22); cursor: pointer;
      font: 700 15px/30px system-ui,-apple-system,"Segoe UI",sans-serif;
      text-align: center; user-select: none;
    }
    button[data-state="idle"] { background:#22c55e; color:#fff; }
    button[data-state="busy"] {
      background:#2563eb; color:#fff; cursor:wait;
      animation:taskonward-busy-pulse 1s ease-in-out infinite;
    }
    @keyframes taskonward-busy-pulse {
      0%,100% { transform:scale(1); opacity:1; }
      50% { transform:scale(1.08); opacity:.72; }
    }
    button[data-state="locked"] { background:#15803d; color:#fff; }
    button[data-state="degraded"] { background:#d97706; color:#fff; }
    button[data-state="error"] { background:#dc2626; color:#fff; }
    .status {
      position:absolute; right:38px; top:-3px; width:max-content; max-width:280px;
      padding:7px 9px; border-radius:8px; background:#0f172a; color:#fff;
      font:500 12px/1.35 system-ui,-apple-system,"Segoe UI",sans-serif;
      box-shadow:0 6px 18px rgba(15,23,42,.22); display:none;
    }
    .status[data-show="1"] { display:block; }
  `;

  const button = document.createElement("button");
  button.type = "button";
  button.dataset.state = "idle";
  button.textContent = "P";
  button.title = "TaskOnward · 点击复制续聊信息";
  button.setAttribute("aria-label", "TaskOnward · 点击复制续聊信息");

  const status = document.createElement("div");
  status.className = "status";
  status.setAttribute("role", "status");
  status.setAttribute("aria-live", "polite");

  shadow.append(style, button, status);
  (document.documentElement || document.body).appendChild(root);

  let hideTimer = null;
  let busyTimer = null;
  let busyStartedAt = 0;

  function stopBusyIndicator() {
    if (busyTimer) clearTimeout(busyTimer);
    busyTimer = null;
    busyStartedAt = 0;
  }

  function startBusyIndicator() {
    stopBusyIndicator();
    busyStartedAt = Date.now();
    button.dataset.state = "busy";
    button.textContent = "0";
    status.dataset.show = "1";

    const tick = () => {
      if (button.dataset.state !== "busy" || !busyStartedAt) {
        stopBusyIndicator();
        return;
      }
      const seconds = Math.max(
        0,
        Math.floor((Date.now() - busyStartedAt) / 1000)
      );
      button.textContent = seconds < 100 ? String(seconds) : "…";
      status.textContent =
        seconds >= 8
          ? "TaskOnward 仍在处理中… " + seconds + "s · 请勿刷新页面"
          : "TaskOnward 正在读取当前对话… " + seconds + "s";
      busyTimer = setTimeout(tick, 1000);
    };
    tick();
  }

  function runtimeSend(message, callback) {
    try {
      if (!chrome?.runtime?.id) return false;
      chrome.runtime.sendMessage(message, (response) => {
        let lastError = null;
        try {
          lastError = chrome.runtime.lastError || null;
        } catch {
          return;
        }
        try {
          callback?.(response, lastError);
        } catch {}
      });
      return true;
    } catch {
      // Extension reload/update invalidates old content-script contexts.
      // Fail silently here; the newly injected/current stub will take over.
      return false;
    }
  }

  function showStatus(ui) {
    stopBusyIndicator();
    const state = String(ui?.state || "idle");
    const label = String(ui?.label || ui?.title || "TaskOnward");
    const detail = String(ui?.detail || ui?.toast || "").trim();
    button.dataset.state = state;
    button.textContent = state === "busy" ? "…" : state === "error" ? "!" : state === "locked" ? "✓" : "P";
    button.title = detail ? label + " · " + detail : label;
    status.textContent = detail ? label + " · " + detail : label;
    status.dataset.show = "1";
    if (hideTimer) clearTimeout(hideTimer);
    hideTimer = setTimeout(() => {
      status.dataset.show = "0";
      if (button.dataset.state !== "busy") {
        button.dataset.state = "idle";
        button.textContent = "P";
      }
    }, 4200);
  }

  function armResumeFromPastedText(text) {
    const token = String(text || "").match(RESUME_RE)?.[1] || "";
    if (!token) return false;
    runtimeSend({
      type: "POWER_RESUME_ARM",
      token,
      pageVersion: VERSION,
    });
    return true;
  }

  document.addEventListener("paste", (event) => {
    const pasted = String(
      event.clipboardData?.getData?.("text/plain") || ""
    );
    armResumeFromPastedText(pasted);
  }, { capture: true, signal: abort.signal });

  button.addEventListener("click", () => {
    if (button.dataset.state === "busy") return;
    startBusyIndicator();

    const sent = runtimeSend(
      { type: "POWER_ACTIVATE", pageVersion: VERSION },
      (response, lastError) => {
        if (lastError) {
          showStatus({
            state: "error",
            label: "TaskOnward 暂不可用",
            detail: "扩展通信失败，请刷新 ChatGPT 页面后重试。",
          });
          return;
        }
        if (!response?.ok) {
          const publicDetail =
            typeof response?.error === "string" && response.error.trim()
              ? response.error.trim()
              : "请稍后重试。";
          showStatus({
            state: response?.degraded ? "degraded" : "error",
            label: "TaskOnward 暂不可用",
            detail: publicDetail,
          });
          return;
        }
        showStatus(response.data || { state: "idle", label: "TaskOnward" });
      }
    );

    if (!sent) {
      showStatus({
        state: "error",
        label: "TaskOnward 已更新",
        detail: "请刷新 ChatGPT 页面后再试。",
      });
    }
  }, { signal: abort.signal });

  globalThis[AGENT_KEY] = {
    version: VERSION,
    stop() {
      abort.abort();
      if (hideTimer) clearTimeout(hideTimer);
      stopBusyIndicator();
      document.getElementById(ROOT_ID)?.remove();
    },
  };
})();
