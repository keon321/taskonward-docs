// Bridge to the existing Power 0.8.8 MCP endpoint. The extension itself
// calls resume_handoff over HTTPS; the target AI does not install MCP.
// This is intentionally opt-in: resume_handoff marks a handoff consumed.
(function () {
  function resumePath(resource) {
    const parsed=new URL(String(resource||""));
    if(parsed.protocol!=="https:") throw new Error("shared_mcp_url_invalid");
    return parsed.href;
  }
  async function resume(token, {resource,accessToken,fetcher=fetch}={}) {
    if(!/^to_[a-zA-Z0-9_-]+$/.test(String(token||""))) throw new Error("shared_resume_token_invalid");
    if(!/^[A-Za-z0-9._~+/-]+$/.test(String(accessToken||""))) throw new Error("shared_auth_required");
    const url=resumePath(resource);
    const rpc={
      jsonrpc:"2.0",id:1,method:"tools/call",
      params:{
        name:"resume_handoff",arguments:{token},
        _meta:{
          "io.modelcontextprotocol/protocolVersion":"2026-07-28",
          "io.modelcontextprotocol/clientCapabilities":{},
          "io.modelcontextprotocol/clientInfo":{
            name:"taskonward-power-trial-browser",version:"0.1.0"
          }
        }
      }
    };
    const controller=new AbortController();
    const timer=setTimeout(()=>controller.abort(),12000);
    try{
      const response=await fetcher(url,{
        method:"POST",signal:controller.signal,
        headers:{
          "content-type":"application/json",
          "accept":"application/json, text/event-stream",
          "mcp-protocol-version":"2026-07-28",
          "mcp-method":"tools/call",
          "mcp-name":"resume_handoff",
          authorization:"Bearer "+accessToken
        },
        body:JSON.stringify(rpc)
      });
      if(!response.ok) throw new Error("shared_mcp_http_"+response.status);
      const ct=response.headers?.get?.("content-type")||"";
      if(!ct.toLowerCase().includes("application/json")) {
        // No silent parse of ambiguous streaming responses: fail closed.
        throw new Error("shared_mcp_unexpected_content_type");
      }
      const outer=await response.json();
      if(outer?.error) throw new Error("shared_mcp_rpc_error");
      const result=outer?.result;
      if(result?.isError){
        const text=String(result.content?.[0]?.text||"");
        let reason="";
        try{reason=JSON.parse(text).error||"";}catch{}
        throw new Error(reason||"shared_mcp_resume_error");
      }
      const data=result?.structuredContent;
      if(data?.status!=="ok"||data?.mode!=="continuity_lite"||
         !Array.isArray(data.handoff_context?.messages) ||
         data.handoff_context.messages.length>14 ||
         typeof data.task_id!=="string" || !data.task_id.startsWith("task_")) {
        throw new Error("shared_mcp_payload_invalid");
      }
      return {
        status:data.status,task_id:data.task_id,task_title:data.task_title,
        source_platform:["chatgpt","claude","gemini"].includes(data.source_platform)
          ? data.source_platform : "unknown",
        handoff_context:data.handoff_context
      };
    }finally{clearTimeout(timer);}
  }
  globalThis.taskOnwardLabMcpBridge={resume};
})();
