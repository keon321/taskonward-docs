TaskOnward Power 0.4.8
支持 ChatGPT / Claude / Gemini。
解压 ZIP，在 chrome://extensions/ 打开开发者模式，加载含 manifest.json 的完整目录。
点击工具栏 Power 登录 TaskOnward，刷新聊天网页。旧 Chat 点击 P 复制短码，新 Chat 输入框粘贴，检查后手动发送；同一码可以接到多个目标。
请保留解压后的扩展目录，不要更改其中的文件。
如首次登录失败，请到 TaskOnward 官网反馈；不需要自行配置 MCP 或 WorkOS。
扩展面板顶部可在中文与 English 之间切换，设置会保留。
扩展不会自动发送消息；交接摘录不是完整聊天备份。
