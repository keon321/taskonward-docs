importScripts("config.js","auth_client.js","mcp_bridge.js","capture.js","cross_platform_capture.js","task_brief.js","handoff.js");

const LAB_API_BASE = "http://127.0.0.1:8788";
const rawLabConfig=()=>globalThis.TASKONWARD_POWER_LAB_CONFIG||{};
const isShared088=()=>rawLabConfig().mode==="shared088";
const labConfig=()=>{
  const c=rawLabConfig();
  return isShared088() ? {
    ...c,cloudApiBase:c.shared088?.apiBase,
    cloudResource:c.shared088?.resource
  }:c;
};
const isCloud=()=>rawLabConfig().mode==="cloud"||isShared088();
function serverConversationId(identity){
  if(isShared088() && identity.platform==="chatgpt"){
    // Power 0.8.8 uses the unprefixed ChatGPT UUID in its binding.
    return identity.id.slice("chatgpt:".length);
  }
  return identity.id;
}
const TEST_USER = "power-lab-isolated-user";
const TEST_HOST = "power-lab-client";
const BINDING_PREFIX = "taskonward_power_lab_binding:";
const RESUME_RE = /TaskOnward\s*续聊码\s*[:：]\s*(to_[A-Za-z0-9_-]+)/i;
const RESUME_ARM_PREFIX = "taskonward_power_lab_resume_arm:";
const RESUME_ARM_TTL_MS = 2 * 60 * 60 * 1000;
let activePromise = null;

function platformFromUrl(value) {
  try {
    const url = new URL(value);
    if (url.protocol !== "https:") return null;
    if (url.hostname === "chatgpt.com") {
      // Match the proven Power 0.8.8 conversation pattern anywhere in the
      // pathname: project chats and custom GPT chats live under /g/.../c/ID.
      const match = url.pathname.match(/\/c\/([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})(?:\/|$)/i);
      return match ? {id:"chatgpt:"+match[1],platform:"chatgpt",label:"ChatGPT"} : null;
    }
    if (url.hostname === "claude.ai") {
      const match = url.pathname.match(/^\/chat\/([0-9a-f-]{12,})(?:\/|$)/i);
      return match ? {id:"claude:"+match[1],platform:"claude",label:"Claude"} : null;
    }
    if (url.hostname === "gemini.google.com") {
      const match = url.pathname.match(/^\/app\/([A-Za-z0-9_-]{6,})(?:\/|$)/i);
      return match ? {id:"gemini:"+match[1],platform:"gemini",label:"Gemini"} : null;
    }
  } catch {}
  return null;
}

function captureOk(value) {
  return value?.ok === true && Array.isArray(value.recentMessages) &&
    value.recentMessages.some((m) => m?.role === "user" && String(m.content || "").trim());
}
function normalized(text) {
  return String(text || "").replace(/[\u200B-\u200D\uFEFF]/g, "").replace(/\s+/g, " ").trim();
}
function matchesDomTail(api, dom) {
  if (!captureOk(dom)) return true;
  const domTail = dom.recentMessages.at(-1);
  const apiMessages = api.recentMessages;
  const domText = normalized(domTail.content);
  for (let index = apiMessages.length - 1; index >= 0; index--) {
    const item = apiMessages[index];
    if (item.role !== domTail.role) continue;
    const apiText = normalized(item.content);
    const sameId = Boolean(item.id && domTail.id && item.id === domTail.id);
    const sameText = apiText === domText;
    const overlapping = apiText.length >= 16 && domText.length >= 16 &&
      (apiText.includes(domText) || domText.includes(apiText));
    if (!(sameId || sameText || overlapping)) continue;
    if (index < apiMessages.length - 1) return true;
    if (sameText) return true;
    return apiText.length >= domText.length;
  }
  return false;
}
async function inject(tabId, world, func, args = []) {
  try {
    const result = await chrome.scripting.executeScript({target:{tabId},world,func,args});
    return result?.[0]?.result || {ok:false,reason:"empty_capture"};
  } catch {
    return {ok:false,reason:"injection_failed"};
  }
}
async function collectOnce(tabId, conversationId, platform = "chatgpt") {
  if (platform !== "chatgpt") {
    const captured = await inject(tabId,"ISOLATED",collectCrossPlatformConversationOnDemand,[platform]);
    if (!captureOk(captured)) throw new Error("当前平台未能可靠读取用户消息，未复制。");
    return captured;
  }
  const [dom,firstApi] = await Promise.all([
    inject(tabId,"ISOLATED",collectCurrentConversationOnDemand),
    inject(tabId,"MAIN",collectChatGPTConversationApiOnDemand,[conversationId.split(":").at(-1)])
  ]);
  let api=firstApi;
  for(let attempt=0;attempt<3;attempt++) {
    if(attempt) {
      await new Promise((resolve)=>setTimeout(resolve,attempt===1?90:240));
      api=await inject(tabId,"MAIN",collectChatGPTConversationApiOnDemand,[conversationId.split(":").at(-1)]);
    }
    if(captureOk(api) && matchesDomTail(api,dom)) return api;
    const reason=String(api?.reason || "");
    if(/conversation_http_(?:401|403|404|429)\b/.test(reason)) break;
    if(captureOk(api) && !captureOk(dom)) return api;
  }
  if(captureOk(dom)) return dom;
  throw new Error("无法可靠读取当前对话；未复制任何内容。");
}
async function copyText(text) {
  const path=chrome.runtime.getURL("offscreen.html");
  const contexts=await chrome.runtime.getContexts({contextTypes:["OFFSCREEN_DOCUMENT"],documentUrls:[path]});
  if(!contexts.length) await chrome.offscreen.createDocument({
    url:"offscreen.html",reasons:["CLIPBOARD"],justification:"用户点击时复制隔离续聊内容"
  });
  try {
    const response=await chrome.runtime.sendMessage({type:"OFFSCREEN_COPY",target:"offscreen",text});
    if(!response?.ok) throw new Error("复制失败，未完成交接。");
  } finally {
    await chrome.offscreen.closeDocument().catch(()=>{});
  }
}
async function localPost(path,payload,{interactive=false}={}) {
  if(isShared088() && path==="/companion/continuity/handoff/preview"){
    const token=await globalThis.taskOnwardLabAuth.accessToken({interactive});
    return globalThis.taskOnwardLabMcpBridge.resume(payload.token,{
      resource:labConfig().cloudResource,accessToken:token
    });
  }
  const controller=new AbortController();
  const timer=setTimeout(()=>controller.abort(),12000);
  let response;
  try {
    const cloud=isCloud();
    const token=cloud
      ? await globalThis.taskOnwardLabAuth.accessToken({interactive})
      : null;
    const address=cloud
      ? String(labConfig().cloudApiBase).replace(/\/$/,"")
      : LAB_API_BASE;
    response=await fetch(address+path,{
      method:"POST",signal:controller.signal,
      headers:cloud
        ? {"content-type":"application/json","authorization":"Bearer "+token}
        : {"content-type":"application/json",
           "x-memory-test-user":TEST_USER,
           "x-memory-test-host":TEST_HOST},
      body:JSON.stringify(payload)
    });
  } catch(error) {
    if(isCloud()) {
      if(String(error?.message||"")==="cloud_auth_required") {
        throw new Error("尚未登录 TaskOnward。请点击浏览器工具栏中的 Power → 登录 TaskOnward。");
      }
      if(String(error?.message||"").startsWith("cloud_")) throw error;
      throw new Error("独立云端暂不可用，未保存任务身份。");
    }
    throw new Error("隔离后端不可用；正式任务未写入，也没有复制交接。");
  } finally {
    clearTimeout(timer);
  }
  let data;
  try {data=await response.json();} catch {throw new Error("隔离后端返回的数据无法解析。");}
  if(!response.ok) {
    const code=String(data?.error||response.status);
    const detail=({
      handoff_prior_context_unavailable:
        "此前交接内容已被清理，无法无损继承。请从仍保留完整任务材料的对话重新交接。",
      handoff_prior_context_invalid:
        "此前交接内容校验失败，已停止交接以防串线。",
      source_conversation_retired:
        "该对话已交接到其他对话，不能再从旧对话覆盖任务主线。",
      handoff_target_conflict:
        "这份交接已被其他目标对话接续，不能重复接到新对话。",
      handoff_expired: "续聊码已过期，请重新生成交接。",
      handoff_invalid_status: "这份交接已失效，请从当前有效对话重新生成。"
    })[code];
    throw new Error(detail || "隔离后端拒绝请求："+code);
  }
  return data;
}
async function bindingStorageKey(conversationId) {
  if (!isCloud()) return BINDING_PREFIX+conversationId;
  const account=await globalThis.taskOnwardLabAuth.accountScope();
  const mode=isShared088()?"shared088":"cloud";
  return BINDING_PREFIX+mode+":"+account+":"+conversationId;
}
async function getBinding(conversationId) {
  const key=await bindingStorageKey(conversationId);
  const storage=await chrome.storage.local.get(key);
  return storage[key] || null;
}
async function setBinding(conversationId,taskId,fromToken="") {
  if(!/^task_[a-zA-Z0-9_-]+$/.test(String(taskId))) throw new Error("任务身份不合法");
  const key=await bindingStorageKey(conversationId);
  await chrome.storage.local.set({[key]:{taskId,fromToken}});
}
function visibleHandoffToken(snapshot) {
  const tokens=(snapshot.recentMessages||[])
    .filter((m)=>m.role==="user")
    .map((m)=>String(m.content||"").match(RESUME_RE)?.[1])
    .filter(Boolean);
  if(new Set(tokens).size > 1) throw new Error("检测到多个不同的续聊凭证；无法确定原任务。");
  return tokens.at(-1) || "";
}
async function prepareWithLocalBackend(snapshot,identity,title,tabId) {
  if(labConfig().fanoutRequired===true) {
    // Feature negotiation BEFORE any task-binding or handoff mutation:
    // old production servers must never be mistaken for fanout capable.
    let capability;
    try {capability=await localPost("/companion/continuity/capabilities",{});}
    catch {throw new Error("当前后端尚未启用一份交接多目标接续；未创建或替换交接。");}
    const features=capability?.features;
    if(!features?.fanout || !features?.independent_branches ||
       !features?.replaces_previous || !features?.reuse_until_replaced) {
      throw new Error("当前后端不支持多目标交接；未创建或替换交接。");
    }
  }
  const witnessedToken=visibleHandoffToken(snapshot);
  const armed=Number.isInteger(tabId) ? (await chrome.storage.local.get(RESUME_ARM_PREFIX+tabId))[RESUME_ARM_PREFIX+tabId] : null;
  const freshArm=armed && Date.now()-Number(armed.at)>=0 &&
    Date.now()-Number(armed.at)<RESUME_ARM_TTL_MS &&
    armed.platform===identity.platform;
  // An unsaved new chat has no conversation ID at paste time. NEVER
  // claim a later unrelated chat by tab ID alone. Demand that the actual
  // sent user turn still witnesses the exact pasted token.
  const exactArm=Boolean(freshArm && armed.conversationId &&
    armed.conversationId===identity.id);
  if(witnessedToken && exactArm && witnessedToken!==armed.token) {
    throw new Error("当前对话出现两个不同的续聊凭证，拒绝串线。");
  }
  // A saved URL matching an armed paste is still not proof the user
  // actually sent the recovered material. Only an actual captured user turn
  // may claim the token; otherwise a premature Power click could hijack an
  // unrelated existing chat.
  const token=witnessedToken;
  let binding=await getBinding(identity.id);
  if(!binding && !token && freshArm) {
    throw new Error("当前对话尚未出现已发送的续聊材料；请先检查输入框并手动发送，再点击 Power。");
  }
  if(binding && token && binding.fromToken && token!==binding.fromToken) {
    throw new Error("当前对话出现与原任务不同的凭证，拒绝串线。");
  }
  if(!binding && token) {
    const bound=await localPost("/companion/continuity/binding/from-handoff",{
      source_conversation_id:serverConversationId(identity),token
    },{interactive:false});
    await setBinding(identity.id,bound.task_id,token);
    if(freshArm && armed.token===token) await chrome.storage.local.remove(RESUME_ARM_PREFIX+tabId);
    binding={taskId:bound.task_id,fromToken:token};
  }
  if(!binding) {
    // Same as stable Power: first click creates an exact identity anchor;
    // resumed chats attach through an actually observed token first.
    const ensured=await localPost("/companion/continuity/binding/ensure",{
      source_conversation_id:serverConversationId(identity),title_seed:title
    },{interactive:false});
    await setBinding(identity.id,ensured.task_id);
    binding={taskId:ensured.task_id};
  }
  const prepared=await localPost("/companion/continuity/handoff/prepare",{
    task_id:binding.taskId,source_conversation_id:serverConversationId(identity),
    title_seed:title,carry_forward_context:true,
    fanout_enabled:labConfig().fanoutRequired===true,
    recent_messages:snapshot.recentMessages
  },{interactive:false});
  if(labConfig().fanoutRequired===true && prepared?.fanout_enabled!==true) {
    throw new Error("后端未确认多目标交接；本次续聊码未复制。");
  }
  return taskOnwardLabHandoff.buildShortHandoff(prepared);
}
async function copyCurrentChat(sourceTab=null) {
  const [activeTab]=sourceTab ? [] : await chrome.tabs.query({active:true,currentWindow:true});
  const tab=sourceTab || activeTab;
  const identity=platformFromUrl(tab?.url);
  if(!tab?.id || !identity) throw new Error("请打开已保存的 ChatGPT、Claude 或 Gemini 对话。");
  const snapshot=await collectOnce(tab.id,identity.id,identity.platform);
  const title=String(tab.title||"").replace(/\s*[-|]\s*(ChatGPT|Claude|Gemini)\s*$/i,"");
  let result;
  let mode="connected";
  try {
    result=await prepareWithLocalBackend(snapshot,identity,title,tab.id);
  } catch(error) {
    // The old Power uses a local emergency copy when the backend is down.
    // Never disguise other errors such as wrong task identity as success.
    if(!/隔离后端不可用/.test(String(error?.message||error)) || isCloud()) throw error;
    result=taskOnwardLabHandoff.buildStandaloneHandoff(snapshot,title,identity.label);
    mode="emergency";
  }
  await copyText(result.text);
  return {ok:true,mode,count:result.count,truncated:result.truncated,
    sensitiveOmitted:result.sensitiveOmitted,missingSource:result.missingSource===true};
}
chrome.runtime.onMessage.addListener((message,sender,sendResponse)=>{
  if(message?.type==="POWER_LAB_AUTH_STATUS") {
    (async()=>{
      const cloud=isCloud();
      if(!cloud) return {
        configured:true,authenticated:false,mode:"local",
        detail:"本机隔离测试服务；无需登录。"
      };
      try {
        globalThis.taskOnwardLabAuth.assertConfigured();
      } catch {
        return {
          configured:false,authenticated:false,mode:isShared088()?"shared088":"cloud",
          detail:"独立云端尚未配置 OAuth 客户端。"
        };
      }
      try {
        await globalThis.taskOnwardLabAuth.accessToken({interactive:false});
        return {configured:true,authenticated:true,mode:isShared088()?"shared088":"cloud"};
      } catch {
        return {configured:true,authenticated:false,mode:isShared088()?"shared088":"cloud"};
      }
    })().then(data=>sendResponse({ok:true,data}))
      .catch(()=>sendResponse({ok:false,error:"登录状态读取失败。"}));
    return true;
  }
  if(message?.type==="POWER_LAB_AUTH_LOGIN") {
    (async()=>{
      if(!isCloud()) throw new Error("本机隔离测试不需要登录。");
      await globalThis.taskOnwardLabAuth.accessToken({interactive:true});
      return {authenticated:true};
    })().then(data=>sendResponse({ok:true,data}))
      .catch(error=>sendResponse({ok:false,error:String(error?.message||"登录失败")}));
    return true;
  }
  if(message?.type==="POWER_LAB_AUTH_LOGOUT") {
    globalThis.taskOnwardLabAuth.logout()
      .then(()=>sendResponse({ok:true,data:{authenticated:false}}))
      .catch(()=>sendResponse({ok:false,error:"退出登录失败。"}));
    return true;
  }
  if(message?.type==="POWER_LAB_RESUME_PREVIEW") {
    const token=String(message?.token||"");
    const source=sender?.tab;
    const sourceUrl=String(source?.url||"");
    let platform="";
    try {
      const host=new URL(sourceUrl).hostname;
      platform=({
        "chatgpt.com":"ChatGPT", "claude.ai":"Claude",
        "gemini.google.com":"Gemini"
      })[host] || "";
    } catch {}
    // Never service requests from popup, external extensions, or arbitrary sites.
    if(!Number.isInteger(source?.id) || !platform ||
        !/^to_[A-Za-z0-9_-]+$/.test(token)) {
      sendResponse({ok:false,error:"交接码或目标平台不合法。"});
      return false;
    }
    localPost("/companion/continuity/handoff/preview",{token})
      .then((data)=>{
        const rendered=taskOnwardLabHandoff.buildPreviewContext(data,token,platform);
        sendResponse({ok:true,text:rendered.text,count:rendered.count,
          truncated:rendered.truncated});
      })
      .catch((error)=>sendResponse({ok:false,error:String(error?.message||"读取交接失败")}));
    return true;
  }
  if(message?.type==="POWER_LAB_RESUME_ARM") {
    const tabId=sender?.tab?.id;
    const token=String(message?.token||"");
    const pageUrl=String(sender?.tab?.url||"");
    const identity=platformFromUrl(pageUrl);
    let pagePlatform=identity?.platform || "";
    try {
      const host=new URL(pageUrl).hostname;
      if(!pagePlatform) pagePlatform=({
        "chatgpt.com":"chatgpt", "claude.ai":"claude",
        "gemini.google.com":"gemini"
      })[host] || "";
    } catch {}
    if(!Number.isInteger(tabId) || !pagePlatform || !/^to_[A-Za-z0-9_-]+$/.test(token)) return false;
    chrome.storage.local.set({[RESUME_ARM_PREFIX+tabId]:{
      token,platform:pagePlatform,conversationId:identity?.id||"",at:Date.now()
    }}).then(()=>sendResponse({ok:true})).catch(()=>sendResponse({ok:false}));
    return true;
  }
  if(message?.type!=="POWER_LAB_COPY") return false;
  if(activePromise) {
    sendResponse({ok:false,error:"正在准备上一份交接，请勿重复点击。"});
    return false;
  }
  activePromise=copyCurrentChat(sender?.tab || null);
  activePromise.then(
    (result)=>sendResponse(result),
    (error)=>sendResponse({ok:false,error:String(error?.message||"交接失败。")})
  ).finally(()=>{activePromise=null;});
  return true;
});
