// Safe portable formatter. Full local mode uses only server-normalized messages.
(function () {
  const MAX_MESSAGES = 14;
  const MAX_MESSAGE_BYTES = 8 * 1024;
  const MAX_TOTAL_BYTES = 56 * 1024;
  const SECRET_PATTERNS = [
    /-----BEGIN(?: [A-Z0-9]+)? PRIVATE KEY-----/i,
    /\bsk-[A-Za-z0-9_-]{16,}\b/,
    /\bgh[pousr]_[A-Za-z0-9]{20,}\b/,
    /\bAKIA[0-9A-Z]{16}\b/,
    /\bAIza[0-9A-Za-z_-]{30,}\b/,
    /\bxox[baprs]-[A-Za-z0-9-]{16,}\b/,
    /\bBearer\s+[A-Za-z0-9._~+\/-]{20,}\b/i
  ];
  function utf8Bytes(value) {
    return new TextEncoder().encode(String(value)).byteLength;
  }
  function clipUtf8(value, maxBytes) {
    const text = String(value || "").trim();
    if (utf8Bytes(text) <= maxBytes) return { text, clipped: false };
    let low = 0, high = text.length;
    while (low < high) {
      const mid = Math.ceil((low + high) / 2);
      if (utf8Bytes(text.slice(0, mid)) <= maxBytes) low = mid;
      else high = mid - 1;
    }
    return { text: text.slice(0, low).trim(), clipped: true };
  }
  function filteredMessages(recentMessages) {
    const raw = Array.isArray(recentMessages) ? recentMessages : [];
    const messages = [];
    let truncated = raw.length > MAX_MESSAGES;
    let sensitiveOmitted = 0;
    for (const item of raw.slice(-MAX_MESSAGES)) {
      const role = String(item?.role || "");
      if (role !== "user" && role !== "assistant") continue;
      const content = String(item?.content || "").trim();
      if (!content) continue;
      if (role === "user" && (/TaskOnward\s*续聊码\s*[:：]\s*[A-Za-z0-9_-]+/i.test(content) ||
          /\[memory-(?:v5-)?handoff:[^\]]+\]/i.test(content))) continue;
      if (SECRET_PATTERNS.some((pattern) => pattern.test(content))) {
        sensitiveOmitted += 1; continue;
      }
      const clipped = clipUtf8(content, MAX_MESSAGE_BYTES);
      if (!clipped.text) continue;
      truncated ||= clipped.clipped;
      messages.push({ role, content: clipped.text,
        complete: role === "assistant" ? item.complete !== false && !clipped.clipped : true });
    }
    while (messages.length > 1 && utf8Bytes(JSON.stringify(messages)) > MAX_TOTAL_BYTES) {
      messages.shift(); truncated = true;
    }
    if (messages.length && utf8Bytes(JSON.stringify(messages)) > MAX_TOTAL_BYTES) {
      const last = messages[0];
      last.content = clipUtf8(last.content, Math.floor(MAX_TOTAL_BYTES * .8)).text;
      last.complete = last.role === "assistant" ? false : true;
      truncated = true;
    }
    return { messages, truncated, sensitiveOmitted };
  }

  function render(view, title, platform, token = "") {
    if (!Array.isArray(view.messages) || !view.messages.length ||
        !view.messages.some((m) => m.role === "user")) {
      throw new Error("没有可安全交接的用户对话；本次未复制。");
    }
    const name = String(title || "当前任务").replace(/\s+/g, " ").trim().slice(0, 90);
    // Never silently summarize or excerpt task evidence just to shorten
    // the pasted message. Any compact handoff must be separately validated.
    const transcript = view.messages.map((item) => {
      const label = item.role === "user" ? "用户" : item.complete ? "助手" : "助手（回答可能中断）";
      return label + "：\n" + item.content;
    }).join("\n\n");
    const missingSource = view.messages.some((m) => m.role === "user" &&
      /(?:帮我|请|替我)?(?:改写|润色|总结|翻译|分析)(?:一下)?(?:下文|以下内容|这篇文章)\s*[:：]?\s*$/u.test(m.content.trim()));
    const notes = [
      view.truncated ? "部分较早内容或较长回答已截断。" : "",
      view.sensitiveOmitted ? "检测到敏感内容，已省略 " + view.sensitiveOmitted + " 条。" : "",
      missingSource ? "存在仅提到“下文”但未实际包含原文的用户请求；相关原文或附件可能缺失，不能宣称已完整恢复。" : "",
      "只根据这份材料恢复现场，不得补写没有依据的历史。"
    ].filter(Boolean).join(" ");
    const text = [
      "TaskOnward｜独立试验版交接",
      "任务：" + name,
      "来源：" + platform,
      token ? "TaskOnward 续聊码：" + token : "本地应急纯文本交接｜无后端任务绑定",
      "",
      "【最近对话】",
      transcript,
      "",
      "【重要提示】",
      notes,
      token
        ? "正文可直接阅读；任务身份待目标对话下一次点击 Power 时验证，粘贴不等于已绑定。"
        : "仅支持语义恢复，不包含跨平台身份绑定。",
      "",
      "【接续要求】",
      "仅依以上记录简述当前任务、已完成、下一步；缺少事实或回答中断须明示，不得猜测。",
      "等待用户核对；回复「确认」不代表授权继续执行任务。"
    ].join("\n");
    if (utf8Bytes(text) > 72 * 1024) throw new Error("交接文本超过试验版容量限制。");
    return { text, count: view.messages.length, truncated: view.truncated,
      sensitiveOmitted: view.sensitiveOmitted, missingSource };
  }

  function buildShortHandoff(prepared) {
    const token = String(prepared?.token || "");
    if (!/^to_[A-Za-z0-9_-]+$/.test(token)) {
      throw new Error("后端未返回有效续聊码；未复制。");
    }
    const title = String(prepared?.display_title || "当前任务")
      .replace(/\s+/g, " ").trim().slice(0, 90);
    return {
      text: [
        "TaskOnward｜跨平台续聊",
        "任务：" + title,
        "TaskOnward 续聊码：" + token,
        "",
        "请在目标 AI 输入框粘贴此内容。TaskOnward Power 将自动取回交接现场并填入输入框，不会自动发送。"
      ].join("\n"),
      count: Number(prepared?.message_count || 0),
      truncated: prepared?.context_truncated === true,
      sensitiveOmitted: Number(prepared?.sensitive_omitted || 0),
      missingSource: false
    };
  }

  function buildPreviewContext(preview, token) {
    const context = preview?.handoff_context;
    // The origin is authenticated server payload metadata. Never label the
    // *destination* as the original source (ChatGPT → Claude used to print
    // “来源：Claude”, misleading model reasoning and human verification).
    const platform = ({
      chatgpt: "ChatGPT", claude: "Claude", gemini: "Gemini"
    })[preview?.source_platform] || "来源待核验";
    const validated=buildServerHandoff({
      token, display_title: preview?.task_title,
      portable_context: context && {
        messages: context.messages,
        context_truncated: context.context_truncated,
        sensitive_omitted: context.sensitive_omitted
      }
    }, platform);
    // Compact task-state evidence by default, not a second full chat dump.
    // Full context is still protected in the server handoff; target AI only
    // receives verbatim extracted evidence, not a fictitious lossless summary.
    return globalThis.taskOnwardLabBrief?.compact
      ? globalThis.taskOnwardLabBrief.compact(preview,token)
      : validated;
  }

  function buildStandaloneHandoff(snapshot, title, platform = "ChatGPT") {
    const view = filteredMessages(snapshot?.recentMessages);
    view.truncated ||= snapshot?.recentMessagesTruncated === true;
    return render(view, title, platform);
  }

  function buildServerHandoff(prepared, platform = "ChatGPT") {
    const context = prepared?.portable_context;
    const token = String(prepared?.token || "");
    if (!/^to_[a-zA-Z0-9_-]+$/.test(token) || !context ||
        !Array.isArray(context.messages) || context.messages.length > MAX_MESSAGES) {
      throw new Error("后端未返回可信的完整交接数据；未复制。");
    }
    const safe = context.messages.map((item) => ({
      role: item?.role,
      content: String(item?.content || ""),
      complete: item?.complete !== false
    }));
    if (safe.some((item) => (item.role !== "user" && item.role !== "assistant") ||
        !item.content.trim() || SECRET_PATTERNS.some((p) => p.test(item.content)))) {
      throw new Error("后端交接数据存在不安全内容；未复制。");
    }
    return render({
      messages: safe,
      truncated: context.context_truncated === true,
      sensitiveOmitted: Number(context.sensitive_omitted || 0)
    }, prepared?.display_title || "当前任务", platform, token);
  }

  globalThis.taskOnwardLabHandoff = {
    buildStandaloneHandoff, buildServerHandoff, buildShortHandoff,
    buildPreviewContext, filteredMessages
  };
})();
