// Strictly user-initiated target-editor insertion; never clicks Send/Enter.
(function () {
  const HEADER = "TaskOnward｜跨平台续聊";
  const TOKEN_RE = /TaskOnward\s*续聊码\s*[:：]\s*(to_[A-Za-z0-9_-]+)/i;
  function parseShortHandoff(text) {
    const value = String(text || "").replace(/\r\n?/g,"\n").trim();
    if (value.length > 1500) return null;
    const isNew=value.startsWith(HEADER+"\n");
    const lines=value.split("\n");
    // Power 0.8.8 emitted "任务标题|" plus the exact instruction below.
    // Requiring both avoids interpreting arbitrary user text as control.
    const isStable088=Boolean(
      lines[0]?.endsWith("|") &&
      value.includes("\n请使用 TaskOnward 恢复这次任务交接。") &&
      lines.some((line)=>/^TaskOnward 续聊码\s*[:：]/.test(line))
    );
    if(!isNew && !isStable088) return null;
    const tokens=[...value.matchAll(new RegExp(TOKEN_RE.source,"gi"))];
    if(tokens.length!==1) return null;
    return {token:tokens[0][1], raw:value};
  }
  function editableForPaste(node) {
    const element = node?.nodeType===1 ? node : node?.parentElement;
    if(!element?.closest) return null;
    const editor = element.closest('textarea,input,[contenteditable="true"],[contenteditable="plaintext-only"]');
    if(!editor || editor.disabled || editor.readOnly) return null;
    const tag=editor.tagName;
    if(tag==="INPUT" && !["text","search"].includes(String(editor.type||"text"))) return null;
    if(!["TEXTAREA","INPUT"].includes(tag) && !editor.isContentEditable) return null;
    return editor;
  }
  function editorText(editor) {
    if(!editor) return "";
    return String(["TEXTAREA","INPUT"].includes(editor.tagName)
      ? editor.value : editor.textContent || "");
  }
  function fillEditor(editor,text) {
    const value=String(text||"");
    if(!editor?.isConnected || !value || !["TEXTAREA","INPUT"].includes(editor.tagName) && !editor.isContentEditable) {
      return false;
    }
    if(["TEXTAREA","INPUT"].includes(editor.tagName)) {
      const proto=editor.tagName==="TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const setter=Object.getOwnPropertyDescriptor(proto,"value")?.set;
      if(!setter)return false;
      setter.call(editor,value);
      editor.dispatchEvent(new InputEvent("input",{
        bubbles:true,inputType:"insertFromPaste",data:value
      }));
      return editor.value===value;
    }
    editor.focus();
    // insertText honors rich-text editor input pipelines and undo history.
    // A direct innerHTML/textContent replacement can desynchronize editors.
    const selection=document.getSelection();
    if(!selection)return false;
    const range=document.createRange();
    range.selectNodeContents(editor);
    range.collapse(false);
    selection.removeAllRanges();
    selection.addRange(range);
    try {
      const inserted=document.execCommand("insertText",false,value);
      if (!inserted) return false;
      // Real rich-text editors can silently drop part of a large paste.
      // Verify ALL non-whitespace characters, not merely a nonempty editor.
      // innerText preserves the visible paragraph boundaries that textContent
      // often loses when execCommand creates multiple block elements.
      const normalize=(s)=>String(s||"").replace(/\s+/g,"");
      const visible=editor.innerText || editor.textContent || "";
      return normalize(visible)===normalize(value);
    } catch {return false;}
  }
  globalThis.taskOnwardLabTargetFill = {
    parseShortHandoff,editableForPaste,editorText,fillEditor
  };
})();
