// On-demand capture from already loaded Claude/Gemini pages.
// Only proven user and assistant semantic wrappers are accepted.
// No polling, network requests, role guessing, or chat-state mutations.
function collectCrossPlatformConversationOnDemand(platform) {
  const MAX_MESSAGES = 14;
  const MAX_MESSAGE_BYTES = 8 * 1024;
  const MAX_TOTAL_BYTES = 56 * 1024;
  const selectors = {
    claude: [
      { selector: '[data-testid="user-message"]', role: "user" },
      { selector: '[data-testid="assistant-message"]', role: "assistant" },
      { selector: '.font-user-message', role: "user" },
      { selector: '.font-claude-response', role: "assistant" }
    ],
    gemini: [
      { selector: 'user-query', role: "user" },
      { selector: 'model-response', role: "assistant" }
    ]
  }[platform];
  if (!selectors) return { ok: false, reason: "unsupported_platform" };

  function bytes(value) { return new TextEncoder().encode(String(value)).byteLength; }
  function clip(value, limit) {
    const text = String(value || "").trim();
    if (bytes(text) <= limit) return { text, clipped: false };
    let low = 0, high = text.length;
    while (low < high) {
      const mid = Math.ceil((low + high) / 2);
      if (bytes(text.slice(0, mid)) <= limit) low = mid;
      else high = mid - 1;
    }
    return { text: text.slice(0, low).trim(), clipped: true };
  }
  function normalized(value) {
    return String(value || "").replace(/\s+/g, " ").trim();
  }
  function cleanText(raw, role) {
    let text = String(raw || "").replace(/\r\n?/g, "\n").trim();
    // Claude's copied answer wrapper can include private-font toolbar icons.
    // Never strip a user's own symbols or Gemini content speculatively.
    if (platform === "claude" && role === "assistant") {
      text = text.replace(/[\uE000-\uF8FF]/g, "").trim();
    }

    if (platform === "gemini") {
      if (role === "assistant") {
        text = text.replace(/^Gemini\s*(?:说|says?)\s*[:：]?\s*/i, "").trim();
      } else {
        // Some Gemini query wrappers contain "你说 X\n\nX".
        // Strip a wrapper only when the repeated user content can be proven.
        const wrapper = text.match(/^(?:你说|You said)\s*[:：]?\s*([\s\S]+)$/i);
        if (wrapper) {
          const body = wrapper[1].trim();
          const sections = body.split(/\n\s*\n|[ \t]{2,}/).map((v) => v.trim()).filter(Boolean);
          if (sections.length === 2 && normalized(sections[0]) === normalized(sections[1])) {
            text = sections[0];
          }
        }
      }
    }
    if (platform === "claude" && role === "assistant") {
      text = text.replace(/^Claude\s+responded\s*[:：]\s*/i, "").trim();
      // Only drop unambiguous terminal interface metadata, never middle text.
      const lines = text.split("\n");
      while (lines.length) {
        const tail = lines[lines.length - 1].trim();
        if (!tail || /^(?:\d+\s+(?:seconds?|minutes?|hours?|days?|weeks?|months?)\s+ago|just now)$/i.test(tail)) {
          lines.pop();
          continue;
        }
        break;
      }
      text = lines.join("\n").trim()
        .replace(/(?:\n+|[ \t]{2,})(?:\d+\s+(?:seconds?|minutes?|hours?|days?|weeks?|months?)\s+ago|just now)\s*$/i, "").trim();
    }
    return text;
  }

  const selected = [];
  for (const item of selectors) {
    for (const element of document.querySelectorAll(item.selector)) {
      const text = String(element.innerText || "").trim();
      if (text) selected.push({ element, role: item.role, text });
    }
  }
  selected.sort((a, b) => {
    if (a.element === b.element) return 0;
    const flags = a.element.compareDocumentPosition(b.element);
    return flags & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1;
  });

  const unique = [];
  for (const item of selected) {
    const index = unique.findIndex((prior) =>
      prior.element === item.element ||
      prior.element.contains(item.element) || item.element.contains(prior.element)
    );
    if (index >= 0) {
      const prior = unique[index];
      if (prior.role !== item.role) return { ok: false, reason: "nested_role_ambiguous" };
      if (item.element.contains(prior.element)) unique[index] = item;
      continue;
    }
    unique.push(item);
  }
  if (!unique.some((item) => item.role === "user")) {
    return { ok: false, reason: "no_proven_user_turn" };
  }

  const isGenerating = Boolean(document.querySelector(
    'button[aria-label*="Stop generating"],button[aria-label*="Stop response"],button[aria-label*="停止生成"]'
  ));
  let truncated = unique.length > MAX_MESSAGES;
  const messages = [];
  for (const item of unique.slice(-MAX_MESSAGES)) {
    const cleaned = cleanText(item.text, item.role);
    const result = clip(cleaned, MAX_MESSAGE_BYTES);
    if (!result.text) continue;
    truncated ||= result.clipped;
    messages.push({
      role: item.role, content: result.text,
      complete: item.role === "assistant"
        ? !(result.clipped || (isGenerating && item === unique.at(-1))) : true
    });
  }
  while (messages.length > 1 && bytes(JSON.stringify(messages)) > MAX_TOTAL_BYTES) {
    messages.shift();
    truncated = true;
  }
  if (messages.length && bytes(JSON.stringify(messages)) > MAX_TOTAL_BYTES) {
    const last = messages[0];
    last.content = clip(last.content, Math.floor(MAX_TOTAL_BYTES * 0.8)).text;
    if (last.role === "assistant") last.complete = false;
    truncated = true;
  }
  return {
    ok: messages.some((m) => m.role === "user"),
    recentMessages: messages,
    recentMessagesTruncated: truncated,
    generationInProgress: isGenerating,
    diagnostic: { source: platform + "_semantic_dom", captured_messages: messages.length }
  };
}
