// WorkOS public-client authorization code + PKCE; independent trial extension
// credentials, no access to existing Power storage or production auth.
(function () {
  const KEY="taskonward_power_lab_cloud_tokens";
  const config=()=>{
    const raw=globalThis.TASKONWARD_POWER_LAB_CONFIG||{};
    return raw.mode==="shared088" ? {
      ...raw,
      cloudIssuer:raw.shared088?.issuer,
      cloudResource:raw.shared088?.resource,
      cloudApiBase:raw.shared088?.apiBase,
      oauthClientId:raw.shared088?.clientId,
      oauthRedirectSuffix:raw.shared088?.oauthRedirectSuffix
    }:raw;
  };
  let loginPromise=null;
  function assertConfigured() {
    const c=config();
    if(c.mode!=="cloud" && c.mode!=="shared088") throw new Error("cloud_mode_disabled");
    if(!/^client_[A-Za-z0-9_-]+$/.test(String(c.oauthClientId||""))) {
      throw new Error("cloud_oauth_client_not_configured");
    }
    for(const name of ["cloudIssuer","cloudResource","cloudApiBase"]) {
      if(!String(c[name]||"").startsWith("https://")) throw new Error("cloud_config_invalid");
    }
    return c;
  }
  const bytesToBase64Url=(data)=> {
    let binary="";
    for(const byte of new Uint8Array(data)) binary+=String.fromCharCode(byte);
    return btoa(binary).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/g,"");
  };
  function randomUrlSafe(n) {
    const data=new Uint8Array(n);
    crypto.getRandomValues(data);
    return bytesToBase64Url(data);
  }
  async function challengeFor(verifier) {
    return bytesToBase64Url(await crypto.subtle.digest("SHA-256",new TextEncoder().encode(verifier)));
  }
  function cfgIdentity(c) {
    return [c.cloudIssuer,c.cloudResource,c.oauthClientId].join("|");
  }
  async function stored() {
    const obj=(await chrome.storage.local.get(KEY))[KEY];
    if(!obj)return null;
    const c=assertConfigured();
    if(obj.identity!==cfgIdentity(c)) {
      await chrome.storage.local.remove(KEY);
      return null;
    }
    return obj;
  }
  async function save(payload,older={}) {
    if(!payload?.access_token) throw new Error("cloud_auth_response_invalid");
    const c=assertConfigured();
    const expire=Math.max(60,Number(payload.expires_in||3600));
    const record={
      identity:cfgIdentity(c),
      accessToken:payload.access_token,
      refreshToken:payload.refresh_token||older.refreshToken||null,
      expiresAt:Date.now()+expire*1000
    };
    await chrome.storage.local.set({[KEY]:record});
    return record;
  }
  async function tokenExchange(form) {
    const c=assertConfigured();
    const controller=new AbortController();
    const timer=setTimeout(()=>controller.abort(),12000);
    try {
      const resp=await fetch(c.cloudIssuer.replace(/\/$/,"")+"/oauth2/token",{
        method:"POST",headers:{"content-type":"application/x-www-form-urlencoded"},
        body:new URLSearchParams(form),signal:controller.signal
      });
      if(!resp.ok) throw new Error("cloud_oauth_token_exchange_"+resp.status);
      return resp.json();
    } finally {
      clearTimeout(timer);
    }
  }
  async function interactiveLogin() {
    const c=assertConfigured();
    const verifier=randomUrlSafe(48);
    const challenge=await challengeFor(verifier);
    const state=randomUrlSafe(24);
    const redirect=chrome.identity.getRedirectURL(c.oauthRedirectSuffix);
    const url=new URL(c.cloudIssuer.replace(/\/$/,"")+"/oauth2/authorize");
    const params={
      client_id:c.oauthClientId,redirect_uri:redirect,
      response_type:"code",scope:c.oauthScopes.join(" "),
      code_challenge:challenge,code_challenge_method:"S256",
      state,resource:c.cloudResource
    };
    for(const [key,value] of Object.entries(params))url.searchParams.set(key,value);
    const outcome=await chrome.identity.launchWebAuthFlow({
      url:url.toString(),interactive:true
    });
    if(!outcome) throw new Error("cloud_oauth_redirect_missing");
    const target=new URL(outcome);
    if(target.origin!==new URL(redirect).origin || target.pathname!==new URL(redirect).pathname ||
       target.searchParams.get("state")!==state) {
      throw new Error("cloud_oauth_state_or_redirect_mismatch");
    }
    if(target.searchParams.has("error")) throw new Error("cloud_oauth_"+target.searchParams.get("error"));
    const code=target.searchParams.get("code");
    if(!code) throw new Error("cloud_oauth_code_missing");
    return save(await tokenExchange({
      grant_type:"authorization_code",client_id:c.oauthClientId,
      code,code_verifier:verifier,redirect_uri:redirect,resource:c.cloudResource
    }));
  }
  async function refresh(record) {
    const c=assertConfigured();
    if(!record?.refreshToken) throw new Error("cloud_auth_required");
    try {
      return await save(await tokenExchange({
        grant_type:"refresh_token",client_id:c.oauthClientId,
        refresh_token:record.refreshToken,resource:c.cloudResource
      }),record);
    } catch(error) {
      if(/cloud_oauth_token_exchange_(?:400|401)/.test(String(error?.message||error))) {
        await chrome.storage.local.remove(KEY);
        throw new Error("cloud_auth_required");
      }
      throw error;
    }
  }
  async function accessToken({interactive=false}={}) {
    assertConfigured();
    let record=await stored();
    if(record?.accessToken && Number(record.expiresAt)>Date.now()+60000) return record.accessToken;
    if(record?.refreshToken) {
      try {return (await refresh(record)).accessToken;}
      catch(error) {
        if(error?.message!=="cloud_auth_required")throw error;
      }
    }
    if(!interactive) throw new Error("cloud_auth_required");
    if(!loginPromise)loginPromise=interactiveLogin().finally(()=>{loginPromise=null;});
    return (await loginPromise).accessToken;
  }
  // Bind local task associations to the actual signed-in account, not only
  // a conversation URL. Decoding is ONLY for cache partitioning; the
  // production server remains responsible for signature and authorization.
  async function accountScope() {
    const jwt=await accessToken({interactive:false});
    const part=String(jwt).split(".")[1];
    if(!part) throw new Error("cloud_auth_identity_unavailable");
    let claims;
    try {
      const normalized=part.replace(/-/g,"+").replace(/_/g,"/");
      claims=JSON.parse(atob(normalized+"=".repeat((4-normalized.length%4)%4)));
    } catch {throw new Error("cloud_auth_identity_unavailable");}
    const c=assertConfigured();
    const issuer=String(c.cloudIssuer||"").replace(/\/$/,"");
    if(!claims || typeof claims.sub!=="string" || !claims.sub.trim() ||
       claims.iss!==issuer) {
      throw new Error("cloud_auth_identity_unavailable");
    }
    const hash=await crypto.subtle.digest("SHA-256",
      new TextEncoder().encode(claims.iss+"|"+claims.sub));
    return [...new Uint8Array(hash)]
      .map(byte=>byte.toString(16).padStart(2,"0")).join("");
  }
  async function logout() {await chrome.storage.local.remove(KEY);}
  globalThis.taskOnwardLabAuth={accessToken,logout,assertConfigured,accountScope};
})();
