// Extractive task handoff: selects verbatim relevant evidence rather than
// dumping raw role-by-role messages. Never invents a fact or silently labels
// the result a complete reconstruction.
(function () {
  const META=/^思考了\s*\d+(?:\s*[hms]|\s*(?:小时|分钟|秒))(?:\s*\d+\s*[hms]){0,2}\s*$/i;
  const TRIVIAL=/^(?:继续|继续下一步|继续任务|继续未完成任务|确认|好的|可以|是|对|好)[。.!！]?$/;
  const NEXT=/(?:下一步|接下来|唯一优先|待办|后续|继续阶段|继续执行|优先事项)/;
  const RISK=/(?:不能|不得|风险|缺失|尚未|亏损|负单|未完成|对抗性审查|否决|不合格|限制)/;
  const PROGRESS=/(?:完成|已确认|已验证|结果|结论|测试|收益|数据|进展|阶段|通过|核验)/;
  function normalizeText(value){
    return String(value||"").replace(/\r\n?/g,"\n")
      .split("\n").filter((line)=>!META.test(line.trim())).join("\n").trim();
  }
  function uniquePush(list, value, max=16) {
    const cleaned=String(value||"").trim();
    if(cleaned && !list.includes(cleaned) && list.length<max)list.push(cleaned);
  }
  function blocksOf(text){
    const lines=normalizeText(text).split("\n");
    const blocks=[];
    let current=[];
    const push=()=>{if(current.length){blocks.push(current.join("\n").trim());current=[];}};
    for(const line of lines){
      if(!line.trim()){push();continue;}
      if(/^#{1,5}\s/.test(line) && current.length){push();}
      current.push(line);
    }
    push();
    return blocks;
  }
  function compact(preview,token) {
    const context=preview?.handoff_context||{};
    const messages=Array.isArray(context.messages)?context.messages:[];
    if(!/^to_[A-Za-z0-9_-]+$/.test(String(token||"")) ||
       !messages.length || messages.length>14 ||
       !messages.some(m=>m.role==="user")) {
      throw Error("缺少可确认的任务原始内容，不能生成任务交接。");
    }
    // Server handoff validation has already checked roles, source text
    // and secrets. Presentation cleanup must not impose a stricter
    // non-empty-per-turn rule: an assistant turn can consist entirely of
    // UI metadata such as “思考了 11m 54s”. Ignore only those emptied turns;
    // do not reject the authenticated task or invent missing evidence.
    const normalized=messages.map((m)=>({
      role:m?.role,content:normalizeText(m?.content),complete:m?.complete!==false
    }));
    if(normalized.some(m=>!["user","assistant"].includes(m.role))) {
      throw Error("交接记录存在无效角色。");
    }
    const safe=normalized.filter(m=>m.content);
    if(!safe.some(m=>m.role==="user")) {
      throw Error("缺少可确认的任务原始内容，不能生成任务交接。");
    }
    const title=String(preview.task_title||"当前任务").replace(/\s+/g," ").trim().slice(0,90);
    const source=({chatgpt:"ChatGPT",claude:"Claude",gemini:"Gemini"})[preview.source_platform];
    const users=safe.filter(m=>m.role==="user");
    const assistants=safe.filter(m=>m.role==="assistant");
    const request=users.at(-1)?.content||"";
    const substantive=users.filter(m=>!TRIVIAL.test(m.content));
    const goals=substantive.slice(-2).map(m=>m.content);
    const chosenProgress=[],chosenRisk=[],chosenNext=[];
    // Walk latest first so the newest decision outranks older observations.
    for(const m of [...assistants].reverse()){
      for(const block of blocksOf(m.content)){
        if(NEXT.test(block))uniquePush(chosenNext,block,3);
        else if(RISK.test(block))uniquePush(chosenRisk,block,5);
        else if(PROGRESS.test(block))uniquePush(chosenProgress,block,5);
      }
    }
    const lines=[
      "TaskOnward｜任务接续",
      "任务："+title,
      ...(source?["来源："+source]:[]),
      "TaskOnward 续聊码："+token,
      "",
      "【当前请求】",
      request,
      "",
      "【任务目标与约束（用户原话）】",
      ...(goals.length?goals:["近期记录未明确提供，请保留原任务目标，不要猜测。"]),
      "",
      "【近期完成与结论（原文证据摘录）】",
      ...(chosenProgress.length?chosenProgress:["近期记录中未发现明确的完成结论。"]),
      "",
      "【风险与未解决问题（原文证据摘录）】",
      ...(chosenRisk.length?chosenRisk:["未能从近期记录中准确提取；不要视为不存在风险。"]),
      "",
      "【下一步（原文证据摘录）】",
      ...(chosenNext.length?chosenNext:["未能从近期记录中明确提取；等待用户确认下一步。"]),
      "",
      "【接续规则】",
      "以上是从最近记录中选择的原文证据，不是完整聊天记录，也不是模型推断的完整任务状态。",
      context.context_truncated
        ? "原始交接窗口已截断；不得推断缺失的历史。"
        : "如需摘录外的具体历史、代码或数字，应向用户索取或通过已授权的任务工具核验。",
      "先核对当前目标、已完成、否决项与下一步；仅在用户明确要求时继续任务。"
    ];
    return {
      text:lines.join("\n"),count:messages.length,
      truncated:Boolean(context.context_truncated),
      sensitiveOmitted:Number(context.sensitive_omitted||0),
      extractive:true
    };
  }
  globalThis.taskOnwardLabBrief={compact,normalizeText};
})();
