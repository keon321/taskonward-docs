// UI-only language setting. Never translate task content, handoff tokens or protocol fields.
(() => {
  const KEY = "taskonward_ui_language";
  const strings = {
    zh: {
      language:"界面语言", serviceCheck:"检查服务状态…", serviceProduction:"TaskOnward 正式服务",
      step1:"正常使用 ChatGPT、Claude 或 Gemini。",
      step2:"需要换对话时，点击页面 P 或下面的“续聊当前对话”。",
      step3:"Power 生成并复制续聊码，不会自动发送消息。",
      step4:"打开新对话并粘贴续聊码，检查自动填入的交接内容后手动发送。",
      step5:"遇到服务故障时，才使用明确标记的本地应急交接。",
      continue:"续聊当前对话", login:"登录 TaskOnward", logout:"退出登录",
      commFail:"扩展通信失败，请刷新页面后重试。", unavailable:"TaskOnward 暂不可用。",
      extensionUpdated:"扩展已更新，请重新打开工具栏面板。",
      statusReadFail:"服务状态读取失败。", localMode:"独立本机测试模式",
      localDetail:"不使用正式生产账号和数据。", cloudUnconfigured:"独立云端尚未配置",
      oauthMissing:"OAuth 客户端尚未开通。", connected:"已连接 TaskOnward",
      signedOut:"尚未登录", connectedProd:"已连接 TaskOnward 正式服务。",
      signInDetail:"使用 TaskOnward 账号登录。",
      connectedCloud:"可以正常使用云端交接。", firstLogin:"首次使用请先登录一次。",
      reading:"正在读取当前对话…", emergencyCopy:"已复制本地应急交接，未保存任务身份。",
      copiedCount:"已保存并复制最近 {count} 条对话的续聊码。",
      copyFailed:"续聊失败，请重试。", openingLogin:"正在打开登录…",
      loginDone:"登录完成。", loginFailed:"登录失败。",
      loggedOut:"已退出。", logoutFailed:"退出失败。",
      statusUnavailable:"无法读取当前服务状态。",
      buttonTitle:"TaskOnward · 点击准备续聊", busyReading:"TaskOnward 正在读取当前对话",
      stillBusy:"TaskOnward 仍在处理中… {seconds}秒 · 请勿刷新页面",
      elapsed:"{label}… {seconds}秒",
      extensionRefresh:"扩展已更新，请刷新页面。",
      copyAndRefresh:"续聊失败，请刷新页面后重试。",
      sourceMissing:"原文或附件可能缺失。",
      truncated:"部分内容已截断。",
      emergencyCopied:"已复制最近 {count} 条对话\n测试服务未启动，未保存任务身份。",
      copiedGo:"已保存并复制最近 {count} 条对话，前往新对话粘贴即可。",
      draftUntouched:"已有输入内容未改动。请在空白聊天输入框粘贴续聊码。",
      busyRetrieve:"TaskOnward 正在取回交接材料",
      incompleteFill:"未能完整填入交接内容。{detail}{recovery}",
      restoredToken:"\n短码已保留在输入框。请勿直接发送短码。",
      partialMaterial:"\n输入框可能已有不完整材料。请清空后重新粘贴原续聊码，不要发送部分内容。",
      backendCheck:"请检查服务连接。",
      changedEditor:"输入框或目标对话已发生变化；为防止覆盖，没有自动填入。",
      editorMismatch:"目标输入框未能通过完整性校验。",
      previewNotArmed:"已填入交接内容，检查后发送即可；续聊凭证暂未记下，后续再次交接可能需要校验。",
      filled:"已填入 {count} 条交接记录（{ms}毫秒），检查后发送即可。"
    },
    en: {
      language:"Interface language", serviceCheck:"Checking service status…", serviceProduction:"TaskOnward production service",
      step1:"Use ChatGPT, Claude, or Gemini as usual.",
      step2:"When switching chats, click the P button on the page or Continue current chat below.",
      step3:"Power creates and copies a handoff code; it never sends messages automatically.",
      step4:"Paste the code into a new chat. Review the filled handoff before sending it yourself.",
      step5:"Use the clearly labeled local emergency handoff only if the service is unavailable.",
      continue:"Continue current chat", login:"Sign in to TaskOnward", logout:"Sign out",
      commFail:"Extension communication failed. Refresh the page and try again.", unavailable:"TaskOnward is unavailable.",
      extensionUpdated:"The extension was updated. Reopen the toolbar popup.",
      statusReadFail:"Could not retrieve service status.", localMode:"Isolated local test mode",
      localDetail:"Production accounts and data are not used.", cloudUnconfigured:"Cloud service not configured",
      oauthMissing:"OAuth client is not configured.", connected:"Connected to TaskOnward",
      signedOut:"Not signed in", connectedProd:"Connected to TaskOnward production.",
      signInDetail:"Sign in with your TaskOnward account.",
      connectedCloud:"Cloud handoffs are available.", firstLogin:"Sign in before using Power.",
      reading:"Reading current chat…", emergencyCopy:"Emergency handoff copied; task identity was not saved.",
      copiedCount:"Handoff code copied for the latest {count} messages.",
      copyFailed:"Could not create the handoff. Try again.", openingLogin:"Opening sign-in…",
      loginDone:"Signed in.", loginFailed:"Sign-in failed.",
      loggedOut:"Signed out.", logoutFailed:"Sign-out failed.",
      statusUnavailable:"Cannot read the current service status.",
      buttonTitle:"TaskOnward · Prepare handoff",
      busyReading:"TaskOnward is reading this chat",
      stillBusy:"TaskOnward is still working… {seconds}s · Do not refresh",
      elapsed:"{label}… {seconds}s",
      extensionRefresh:"The extension was updated. Refresh this page.",
      copyAndRefresh:"Could not prepare the handoff. Refresh and try again.",
      sourceMissing:"Original text or attachments may be missing.",
      truncated:"Some content was truncated.",
      emergencyCopied:"Copied {count} recent messages\nTest service is offline; task identity was not saved.",
      copiedGo:"Copied a handoff from {count} messages. Paste it in a new chat.",
      draftUntouched:"Your draft is unchanged. Paste the code into an empty chat input.",
      busyRetrieve:"TaskOnward is retrieving the handoff",
      incompleteFill:"Could not fully insert the handoff. {detail}{recovery}",
      restoredToken:"\nCode restored in the input. Do not send the code itself.",
      partialMaterial:"\nThe input may contain incomplete content. Clear it and paste the original code again. Do not send partial content.",
      backendCheck:"Check the service connection.",
      changedEditor:"The input or destination chat changed; no content was inserted.",
      editorMismatch:"Could not verify the inserted content.",
      previewNotArmed:"Handoff inserted; review and send it. The continuation reference was not saved, so a later handoff may require verification.",
      filled:"Inserted {count} handoff entries ({ms}ms). Review and send."
    }
  };
  const errors = {
    "尚未登录 TaskOnward。请点击浏览器工具栏中的 Power → 登录 TaskOnward。":"Not signed in. Open the TaskOnward toolbar popup and sign in.",
    "当前平台未能可靠读取用户消息，未复制。":"Could not safely read messages on this platform. Nothing was copied.",
    "无法可靠读取当前对话；未复制任何内容。":"Could not safely read this chat. Nothing was copied.",
    "复制失败，未完成交接。":"Copy failed. The handoff did not complete.",
    "续聊码已过期，请重新生成交接。":"Handoff code expired. Create a new handoff.",
    "这份交接已失效，请从当前有效对话重新生成。":"This handoff is no longer valid. Create a new one in the active chat.",
    "检测到多个不同的续聊凭证；无法确定原任务。":"Multiple handoff references were found. Task identity is ambiguous.",
    "当前对话出现两个不同的续聊凭证，拒绝串线。":"Conflicting handoff references found. Stopped to prevent mixing tasks.",
    "当前对话尚未出现已发送的续聊材料；请先检查输入框并手动发送，再点击 Power。":"Send the reviewed handoff before creating another one.",
    "当前对话出现与原任务不同的凭证，拒绝串线。":"The handoff reference does not match this task. Stopped to prevent mixing tasks.",
    "后端未确认多目标交接；本次续聊码未复制。":"Multi-destination handoff was not confirmed. No code was copied.",
    "登录状态读取失败。":"Could not read sign-in status.",
    "交接码或目标平台不合法。":"Invalid handoff code or destination.",
    "退出登录失败。":"Could not sign out.",
    "正在准备上一份交接，请勿重复点击。":"A handoff is already being prepared. Do not click again.",
    "此前交接内容已被清理，无法无损继承。请从仍保留完整任务材料的对话重新交接。":"Earlier handoff data was removed. Start from a chat that still contains the task information.",
    "此前交接内容校验失败，已停止交接以防串线。":"Handoff verification failed. Stopped to prevent mixing tasks.",
    "该对话已交接到其他对话，不能再从旧对话覆盖任务主线。":"This chat has already handed off to another chat. Do not overwrite its task state.",
    "这份交接已被其他目标对话接续，不能重复接到新对话。":"This handoff was already claimed by another chat.",
    "请打开已保存的 ChatGPT、Claude 或 Gemini 对话。":"Open a saved ChatGPT, Claude or Gemini conversation.",
    "任务身份不合法":"Invalid task identity.",
    "独立云端暂不可用，未保存任务身份。":"The cloud service is unavailable. Task identity was not saved.",
    "隔离后端不可用；正式任务未写入，也没有复制交接。":"The service is unavailable; the task was not saved and no handoff was copied.",
    "隔离后端返回的数据无法解析。":"Could not parse the service response.",
    "当前后端尚未启用一份交接多目标接续；未创建或替换交接。":"This service does not support multi-destination handoffs yet. Nothing was changed.",
    "当前后端不支持多目标交接；未创建或替换交接。":"This service does not support multi-destination handoffs. Nothing was changed.",
    "本机隔离测试不需要登录。":"Local test mode does not require sign-in.",
    "读取交接失败":"Could not retrieve the handoff.",
    "交接失败。":"Handoff failed.",
    "登录失败":"Sign-in failed."
  };
  let lang = "zh";
  const listeners = new Set();
  function t(key, vars = {}) {
    const text = (strings[lang]?.[key] ?? strings.zh[key] ?? String(key));
    return text.replace(/\{([A-Za-z]+)\}/g, (_, name) => String(vars[name] ?? ""));
  }
  function notify() { for (const cb of listeners) { try { cb(lang); } catch {} } }
  function setActive(next) { const normalized = next === "en" ? "en" : "zh"; if (lang !== normalized) { lang = normalized; notify(); } }
  async function initialize() {
    try { const data = await chrome.storage.local.get(KEY); setActive(data?.[KEY]); }
    catch { setActive("zh"); }
    return lang;
  }
  async function setLanguage(next) {
    const normalized = next === "en" ? "en" : "zh";
    await chrome.storage.local.set({ [KEY]: normalized });
    setActive(normalized);
  }
  chrome.storage?.onChanged?.addListener?.((changes, area) => {
    if (area === "local" && changes[KEY]) setActive(changes[KEY].newValue);
  });
  function error(value) {
    const text = String(value || "");
    if (lang !== "en") return text;
    if (errors[text]) return errors[text];
    if (text.startsWith("隔离后端拒绝请求：")) return "The service rejected the request: "+text.slice("隔离后端拒绝请求：".length);
    return text;
  }
  globalThis.taskOnwardLabUI = { t, error, initialize, setLanguage,
    language: () => lang, onChange: (cb) => { listeners.add(cb); return () => listeners.delete(cb); } };
})();
