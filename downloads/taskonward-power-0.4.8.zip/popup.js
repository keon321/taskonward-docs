const ui=globalThis.taskOnwardLabUI;
const t=(key,vars)=>ui.t(key,vars);
const auth=document.getElementById("auth");
const detail=document.getElementById("detail");
const message=document.getElementById("message");
const continueCurrent=document.getElementById("continue");
const login=document.getElementById("login");
const logout=document.getElementById("logout");
const languageSelect=document.getElementById("ui-language");
document.getElementById("version").textContent="v"+chrome.runtime.getManifest().version;
let currentMessage=null;
function renderText() {
  document.documentElement.lang=ui.language()==="en"?"en":"zh-CN";
  languageSelect.value=ui.language();
  document.querySelectorAll("[data-i18n]").forEach(el => {el.textContent=t(el.dataset.i18n);});
  if (currentMessage) renderMessage();
}
function renderMessage() {
  if (!currentMessage) return;
  message.textContent=currentMessage.error!=null
    ? ui.error(currentMessage.error)
    : t(currentMessage.key,currentMessage.vars);
}
function setStatus(key,vars={}) {
  currentMessage={key,vars};
  renderMessage();
}
function setError(error,fallback) {
  currentMessage={error: error || t(fallback)};
  renderMessage();
}
function send(type) {
  return new Promise((resolve) => {
    try {
      chrome.runtime.sendMessage({type},(response)=>{
        const error=chrome.runtime.lastError;
        resolve(error ? {ok:false,error:t("commFail")} :
          response ?? {ok:false,error:t("unavailable")});
      });
    } catch {
      resolve({ok:false,error:t("extensionUpdated")});
    }
  });
}
async function refresh(){
  const response=await send("POWER_LAB_AUTH_STATUS");
  if(!response?.ok){
    auth.textContent=t("unavailable");
    detail.textContent=t("statusReadFail");
    continueCurrent.disabled=true;
    login.disabled=true;
    logout.disabled=true;
    return;
  }
  const data=response.data||{};
  if(data.mode==="local"){
    auth.textContent=t("localMode");
    detail.textContent=t("localDetail");
    continueCurrent.disabled=false;
    login.disabled=true;
    logout.disabled=true;
    return;
  }
  if(!data.configured){
    auth.textContent=t("cloudUnconfigured");
    detail.textContent=t("oauthMissing");
    continueCurrent.disabled=true;
    login.disabled=true;
    logout.disabled=true;
    return;
  }
  auth.textContent=t(data.authenticated?"connected":"signedOut");
  detail.textContent=data.mode==="shared088"
    ? t(data.authenticated?"connectedProd":"signInDetail")
    : t(data.authenticated?"connectedCloud":"firstLogin");
  continueCurrent.disabled=!data.authenticated;
  login.disabled=Boolean(data.authenticated);
  logout.disabled=!data.authenticated;
}
continueCurrent.addEventListener("click",async()=>{
  continueCurrent.disabled=true;
  setStatus("reading");
  const response=await send("POWER_LAB_COPY");
  if(response?.ok) setStatus(response.mode==="emergency"?"emergencyCopy":"copiedCount",{count:response.count});
  else setError(response?.error,"copyFailed");
  await refresh();
});
login.addEventListener("click",async()=>{
  login.disabled=true;
  setStatus("openingLogin");
  const response=await send("POWER_LAB_AUTH_LOGIN");
  if(response?.ok) setStatus("loginDone");
  else setError(response?.error,"loginFailed");
  await refresh();
});
logout.addEventListener("click",async()=>{
  logout.disabled=true;
  const response=await send("POWER_LAB_AUTH_LOGOUT");
  if(response?.ok) setStatus("loggedOut");
  else setError(response?.error,"logoutFailed");
  await refresh();
});
languageSelect.addEventListener("change",async()=>{
  languageSelect.disabled=true;
  try { await ui.setLanguage(languageSelect.value); }
  finally { languageSelect.disabled=false; }
});
ui.onChange(()=>{renderText();refresh().catch(()=>{});});
ui.initialize().then(()=>{
  renderText();
  return refresh();
}).catch(()=>{
  renderText();
  auth.textContent=t("unavailable");
  detail.textContent=t("statusUnavailable");
  continueCurrent.disabled=true;
  login.disabled=true;
  logout.disabled=true;
});
