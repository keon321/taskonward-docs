// TaskOnward Power production only; never silently fall back to local.
globalThis.TASKONWARD_POWER_LAB_CONFIG={
  mode:"shared088",
  fanoutRequired:true,
  oauthScopes:["openid","profile","email","offline_access"],
  shared088:{
    apiBase:"https://memory.5188688.xyz",
    resource:"https://memory-v5-beta.8084867.workers.dev/mcp",
    issuer:"https://select-venue-33.authkit.app",
    clientId:"client_01M3RRDPBAYXZT1N8X9JX2JNKW",
    oauthRedirectSuffix:"memory-v5"
  }
};
