(() => {
  const ROOT_ID = "taskonward-power-lab-root";
  const AGENT_KEY = "__taskOnwardPowerLabPageAgent";
  const RESUME_RE = /TaskOnward\s*续聊码\s*[:：]\s*(to_[A-Za-z0-9_-]+)/i;
  try { globalThis[AGENT_KEY]?.stop?.(); } catch {}
  document.getElementById(ROOT_ID)?.remove();

  const abort = new AbortController();
  const root = document.createElement("div");
  root.id = ROOT_ID;
  Object.assign(root.style, {
    position: "fixed",
    right: "18px",
    top: "38%",
    zIndex: "2147483645",
    pointerEvents: "auto",
  });
  const shadow = root.attachShadow({ mode: "closed" });
  const style = document.createElement("style");
  style.textContent = `
    :host { all: initial; }
    button {
      width: 30px; height: 30px; padding: 0; border: 0; border-radius: 10px;
      background: #22c55e; color: #fff;
      font: 700 15px/30px system-ui,-apple-system,"Segoe UI",sans-serif;
      box-shadow: 0 6px 18px rgba(15,23,42,.22); cursor: pointer;
      user-select: none; touch-action: none;
    }
    button:focus-visible { outline: 2px solid #38bdf8; outline-offset: 2px; }
    button[data-state="idle"] { background: #22c55e; }
    button[data-state="busy"] {
      background: #2563eb; cursor: wait;
      animation:taskonward-lab-busy-pulse 1s ease-in-out infinite;
    }
    @keyframes taskonward-lab-busy-pulse {
      0%,100% { transform:scale(1); opacity:1; }
      50% { transform:scale(1.08); opacity:.72; }
    }
    button[data-state="locked"] { background: #15803d; }
    button[data-state="degraded"] { background: #d97706; }
    button[data-state="error"] { background: #dc2626; }
    .status {
      position: absolute; right: 45px; top: 0; width: max-content; max-width: 280px;
      padding: 7px 9px; border-radius: 8px; background: #0f172a; color: #fff;
      font: 12px/1.4 system-ui,-apple-system,sans-serif;
      box-shadow: 0 6px 18px rgba(15,23,42,.2); white-space: pre-wrap;
    }
    .status[hidden] { display: none; }
  `;

  const button = document.createElement("button");
  button.type = "button";
  button.dataset.state = "idle";
  const buttonLabel = document.createElement("span");
  buttonLabel.textContent = "P";
  button.append(buttonLabel);
  button.title = "TaskOnward · 点击准备续聊";
  button.setAttribute("aria-label", "TaskOnward · 点击准备续聊");

  const status = document.createElement("div");
  status.className = "status";
  status.hidden = true;
  status.setAttribute("role", "status");
  status.setAttribute("aria-live", "polite");
  shadow.append(style, button, status);

  let busy = false;
  let hideTimer = null;
  let busyTimer = null;
  let busyStartedAt = 0;
  let drag = null;
  let suppressClick = false;

  // 0.8.8 Power: elapsed seconds 0,1,2… (not a fabricated countdown).
  // Only runs while the user-initiated operation is pending.
  function stopBusyIndicator() {
    if (busyTimer !== null) clearTimeout(busyTimer);
    busyTimer = null;
    busyStartedAt = 0;
  }
  function startBusyIndicator(label = "TaskOnward 正在读取当前对话") {
    clearTimeout(hideTimer);
    stopBusyIndicator();
    busy = true;
    busyStartedAt = Date.now();
    button.dataset.state = "busy";
    buttonLabel.textContent = "0";
    status.hidden = false;
    const tick = () => {
      if (!busy || !busyStartedAt) return;
      const seconds = Math.max(0,Math.floor((Date.now()-busyStartedAt)/1000));
      buttonLabel.textContent = seconds < 100 ? String(seconds) : "…";
      status.textContent = seconds >= 8
        ? "TaskOnward 仍在处理中… " + seconds + "s · 请勿刷新页面"
        : label + "… " + seconds + "s";
      busyTimer = setTimeout(tick,1000);
    };
    tick();
  }
  function show(message, state = "locked") {
    busy = false;
    stopBusyIndicator();
    button.dataset.state = state;
    buttonLabel.textContent = state === "locked" ? "✓"
      : state === "error" || state === "degraded" ? "!" : "P";
    status.textContent = String(message || "");
    status.hidden = false;
    clearTimeout(hideTimer);
    hideTimer = setTimeout(() => {
      status.hidden = true;
      if (!busy) {
        button.dataset.state = "idle";
        buttonLabel.textContent = "P";
      }
    }, 4200);
  }

  button.addEventListener("click", () => {
    if (suppressClick) { suppressClick = false; return; }
    if (busy) return;
    startBusyIndicator();
    try {
      if (!chrome.runtime?.id) throw new Error("扩展已更新，请刷新页面。");
      chrome.runtime.sendMessage({ type: "POWER_LAB_COPY" }, (response) => {
        const lastError = chrome.runtime.lastError;
        if (lastError || !response?.ok) {
          show(response?.error || "续聊失败，请刷新页面后重试。", "error");
          return;
        }
        const warning=(response.missingSource ? "\n原文或附件可能缺失。" : "") +
          (response.truncated ? "\n部分内容已截断。" : "");
        show((response.mode === "emergency"
          ? "已复制最近 " + response.count + " 条对话\n测试服务未启动，未保存任务身份。"
          : "已保存并复制最近 " + response.count + " 条对话，前往新 Chat 粘贴即可。") + warning,
          response.mode === "emergency" ? "degraded" : "locked");
      });
    } catch {
      show("扩展已更新，请刷新页面后重试。", "error");
    }
  }, { signal: abort.signal });

  // The user authorizes recovery by pasting the short TaskOnward code into
  // an EMPTY chat composer. We fetch through the extension, fill the input,
  // and NEVER click/send/submit. Unknown pastes retain normal browser behavior.
  let pendingPaste = false;
  document.addEventListener("paste", (event) => {
    // Ignore synthetic webpage-created paste events. Only an actual user
    // clipboard gesture authorizes fetching their private handoff content.
    if (!event.isTrusted) return;
    const pasted = String(event.clipboardData?.getData?.("text/plain") || "");
    const helper = globalThis.taskOnwardLabTargetFill;
    const parsed = helper?.parseShortHandoff(pasted);
    if (!parsed) {
      // Backward compatibility for full handoffs already pasted previously.
      const token = pasted.match(RESUME_RE)?.[1];
      if (token) {
        try { chrome.runtime.sendMessage({ type: "POWER_LAB_RESUME_ARM", token }); }
        catch {}
      }
      return;
    }
    const editor = helper.editableForPaste(event.target);
    if (!editor) return;
    if (helper.editorText(editor).trim()) {
      // Never paste control material over a draft, even through the native
      // browser default action after we decline the automatic recovery.
      event.preventDefault();
      event.stopImmediatePropagation();
      show("已有输入内容未改动。请在空白聊天输入框粘贴续聊码。", "error");
      return;
    }
    event.preventDefault();
    event.stopImmediatePropagation();
    if (pendingPaste) {
      // Keep the original request and elapsed timer alive; a second paste
      // must not reset busy state or accidentally enable another click.
      return;
    }
    pendingPaste = true;
    const originalUrl = location.href;
    startBusyIndicator("TaskOnward 正在取回交接材料");
    const unchanged = () =>
      editor.isConnected && location.href === originalUrl &&
      helper.editorText(editor).trim() === "";
    const restoreOnError = (detail) => {
      const untouched=unchanged();
      const restored=untouched && helper.fillEditor(editor,parsed.raw);
      show("未能完整填入交接内容。" + detail +
        (restored
          ? "\n短码已保留在输入框。请勿直接发送短码。"
          : "\n输入框可能已有不完整材料。请清空后重新粘贴原续聊码，不要发送部分内容。"), "error");
    };
    chrome.runtime.sendMessage({
      type: "POWER_LAB_RESUME_PREVIEW", token: parsed.token
    }, (response) => {
      const lastError = chrome.runtime.lastError;
      pendingPaste = false;
      if (lastError || !response?.ok) {
        restoreOnError(response?.error || "请检查测试后端。");
        return;
      }
      if (!unchanged()) {
        show("输入框或目标对话已发生变化；为防止覆盖，没有自动填入。", "error");
        return;
      }
      const fillStarted=performance.now();
      if (!helper.fillEditor(editor, response.text)) {
        restoreOnError("目标输入框未能通过完整性校验。");
        return;
      }
      const fillMs=Math.round(performance.now()-fillStarted);
      chrome.runtime.sendMessage({
        type: "POWER_LAB_RESUME_ARM", token: parsed.token
      }, (armed) => {
        const armError = chrome.runtime.lastError;
        show(armError || !armed?.ok
          ? "已填入交接内容，检查后发送即可；续聊凭证暂未记下，后续再次交接可能需要校验。"
          : "已填入 " + response.count + " 条交接记录（" + fillMs + "ms），检查后发送即可。",
          armError || !armed?.ok ? "degraded" : "locked");
      });
    });
  }, { capture: true, signal: abort.signal });

  // Reposition vertically; clicking and dragging are distinct actions.
  button.addEventListener("pointerdown", (event) => {
    if (busy || event.button !== 0) return;
    drag = { y: event.clientY, top: root.getBoundingClientRect().top, moved: false };
    try { button.setPointerCapture(event.pointerId); } catch {}
  }, { signal: abort.signal });
  button.addEventListener("pointermove", (event) => {
    if (!drag) return;
    const delta = event.clientY - drag.y;
    if (Math.abs(delta) < 6 && !drag.moved) return;
    drag.moved = true;
    const maxTop = Math.max(10, window.innerHeight - 56);
    root.style.top = Math.max(10, Math.min(maxTop, drag.top + delta)) + "px";
  }, { signal: abort.signal });
  button.addEventListener("pointerup", (event) => {
    if (drag?.moved) suppressClick = true;
    drag = null;
    try { button.releasePointerCapture(event.pointerId); } catch {}
  }, { signal: abort.signal });
  button.addEventListener("pointercancel", () => { drag = null; },
    { signal: abort.signal });

  // Register the handler before showing the button.
  (document.documentElement || document.body).append(root);
  globalThis[AGENT_KEY] = {
    stop() {
      abort.abort();
      clearTimeout(hideTimer);
      stopBusyIndicator();
      document.getElementById(ROOT_ID)?.remove();
    }
  };
})();
