const auth=document.getElementById("auth");
const detail=document.getElementById("detail");
const message=document.getElementById("message");
const continueCurrent=document.getElementById("continue");
const login=document.getElementById("login");
const logout=document.getElementById("logout");
document.getElementById("version").textContent="v"+chrome.runtime.getManifest().version;

function send(type) {
  return new Promise((resolve) => {
    try {
      chrome.runtime.sendMessage({type},(response)=>{
        const error=chrome.runtime.lastError;
        resolve(error ? {ok:false,error:"扩展通信失败，请刷新页面后重试。"} :
          response ?? {ok:false,error:"TaskOnward 暂不可用。"});
      });
    } catch {
      resolve({ok:false,error:"扩展已更新，请重新打开工具栏面板。"});
    }
  });
}
async function refresh(){
  const response=await send("POWER_LAB_AUTH_STATUS");
  if(!response?.ok){
    auth.textContent="TaskOnward 暂不可用";
    detail.textContent="服务状态读取失败。";
    continueCurrent.disabled=true;
    login.disabled=true;
    logout.disabled=true;
    return;
  }
  const data=response.data||{};
  if(data.mode==="local"){
    auth.textContent="独立本机测试模式";
    detail.textContent=data.detail||"不使用正式生产账号和数据。";
    continueCurrent.disabled=false;
    login.disabled=true;
    logout.disabled=true;
    return;
  }
  if(!data.configured){
    auth.textContent="独立云端尚未配置";
    detail.textContent=data.detail||"OAuth 客户端尚未开通。";
    continueCurrent.disabled=true;
    login.disabled=true;
    logout.disabled=true;
    return;
  }
  auth.textContent=data.authenticated?"已连接 TaskOnward":"尚未登录";
  detail.textContent=data.mode==="shared088"
    ? (data.authenticated?"已连接 TaskOnward 正式服务。":"使用 TaskOnward 账号登录。")
    : (data.authenticated?"可以正常使用云端交接。":"首次使用请先登录一次。");
  continueCurrent.disabled=!data.authenticated;
  login.disabled=Boolean(data.authenticated);
  logout.disabled=!data.authenticated;
}
continueCurrent.addEventListener("click",async()=>{
  continueCurrent.disabled=true;
  message.textContent="正在读取当前 Chat…";
  const response=await send("POWER_LAB_COPY");
  message.textContent=response?.ok
    ? response.mode==="emergency"
      ? "已复制本地应急交接，未保存任务身份。"
      : "已保存并复制最近 "+response.count+" 条对话的续聊码。"
    : (response?.error||"续聊失败，请重试。");
  await refresh();
});
login.addEventListener("click",async()=>{
  login.disabled=true;
  message.textContent="正在打开登录…";
  const response=await send("POWER_LAB_AUTH_LOGIN");
  message.textContent=response?.ok?"登录完成。":(response?.error||"登录失败。");
  await refresh();
});
logout.addEventListener("click",async()=>{
  logout.disabled=true;
  const response=await send("POWER_LAB_AUTH_LOGOUT");
  message.textContent=response?.ok?"已退出。":(response?.error||"退出失败。");
  await refresh();
});
refresh().catch(()=>{
  auth.textContent="TaskOnward 暂不可用";
  detail.textContent="无法读取当前服务状态。";
  continueCurrent.disabled=true;
  login.disabled=true;
  logout.disabled=true;
});
