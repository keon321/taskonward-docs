// TaskOnward Power one-shot ChatGPT capture routines.
// Each collector is self-contained because chrome.scripting.executeScript
// serializes the injected function without module closures. Normal ChatGPT use
// never calls these functions; they run only after an explicit Power click.

async function collectChatGPTConversationApiOnDemand(conversationId) {
  const id = String(conversationId || "").trim();
  if (!id) return { ok: false, reason: "conversation_id_missing" };

  const MAX_RECENT_MESSAGES = 14;
  const MAX_MESSAGE_BYTES = 8 * 1024;
  const MAX_TOTAL_BYTES = 56 * 1024;

  function clip(text, maxBytes) {
    const value = String(text || "").trim();
    if (!value) return { text: "", truncated: false };
    const encoder = new TextEncoder();
    if (encoder.encode(value).byteLength <= maxBytes) {
      return { text: value, truncated: false };
    }
    let low = 0;
    let high = value.length;
    while (low < high) {
      const mid = Math.ceil((low + high) / 2);
      if (encoder.encode(value.slice(0, mid)).byteLength <= maxBytes) {
        low = mid;
      } else {
        high = mid - 1;
      }
    }
    return { text: value.slice(0, low).trim(), truncated: true };
  }

  function contentText(value) {
    if (typeof value === "string") return value;
    if (Array.isArray(value)) {
      return value.map(contentText).filter(Boolean).join("\n");
    }
    if (!value || typeof value !== "object") return "";
    if (Array.isArray(value.parts)) {
      return value.parts.map(contentText).filter(Boolean).join("\n");
    }
    if (typeof value.text === "string") return value.text;
    if (typeof value.content === "string") return value.content;
    if (Array.isArray(value.content)) {
      return value.content.map(contentText).filter(Boolean).join("\n");
    }
    if (value.content && typeof value.content === "object") {
      return contentText(value.content);
    }
    if (typeof value.value === "string") return value.value;
    return "";
  }

  function messageText(message) {
    return contentText(message?.content).trim();
  }

  function assistantComplete(message) {
    if (!message || typeof message !== "object") return false;
    if (message.end_turn === false) return false;
    const status = String(message.status || "").toLowerCase();
    return !(
      status.includes("in_progress") ||
      status.includes("stream") ||
      status.includes("interrupted")
    );
  }

  function witness(item) {
    const normalized = String(item?.content || "")
      .replace(/[\u200B-\u200D\uFEFF]/g, "")
      .replace(/\s+/g, " ")
      .trim();
    return {
      id: String(item?.id || ""),
      role: String(item?.role || ""),
      length: normalized.length,
      head: normalized.slice(0, 256),
      tail: normalized.slice(-256),
    };
  }

  try {
    let accessToken = "";
    let sessionReason = "";
    try {
      const sessionResponse = await fetch("/api/auth/session", {
        method: "GET",
        credentials: "include",
        cache: "no-store",
      });
      if (sessionResponse.ok) {
        const session = await sessionResponse.json();
        accessToken = String(session?.accessToken || "");
        if (!accessToken) sessionReason = "session_token_missing";
      } else {
        sessionReason = "session_http_" + sessionResponse.status;
      }
    } catch (error) {
      sessionReason =
        "session_fetch_failed:" + String(error?.name || "unknown");
    }

    const requestConversation = async (withBearer) => {
      const headers =
        withBearer && accessToken
          ? { Authorization: "Bearer " + accessToken }
          : undefined;
      return fetch(
        "/backend-api/conversation/" + encodeURIComponent(id),
        {
          method: "GET",
          credentials: "include",
          cache: "no-store",
          ...(headers ? { headers } : {}),
        }
      );
    };

    let authMode = accessToken ? "bearer" : "cookie";
    let response = await requestConversation(Boolean(accessToken));
    if (
      accessToken &&
      (response.status === 401 || response.status === 403)
    ) {
      authMode = "cookie_fallback";
      response = await requestConversation(false);
    }
    if (!response.ok) {
      return {
        ok: false,
        reason: "conversation_http_" + response.status,
        session_reason: sessionReason,
      };
    }

    const data = await response.json();
    const mapping =
      data?.mapping && typeof data.mapping === "object"
        ? data.mapping
        : {};

    let currentNodeId =
      typeof data?.current_node === "string" && mapping[data.current_node]
        ? data.current_node
        : null;

    if (!currentNodeId) {
      const leaves = Object.entries(mapping).filter(
        ([, node]) =>
          !Array.isArray(node?.children) || node.children.length === 0
      );
      if (leaves.length === 1) {
        currentNodeId = leaves[0][0];
      } else {
        return {
          ok: false,
          reason:
            leaves.length > 1
              ? "current_branch_ambiguous"
              : "current_node_missing",
          session_reason: sessionReason,
        };
      }
    }

    const branchNodes = [];
    const seen = new Set();
    let cursor = currentNodeId;
    while (cursor && mapping[cursor] && !seen.has(cursor)) {
      seen.add(cursor);
      branchNodes.push(mapping[cursor]);
      cursor =
        typeof mapping[cursor]?.parent === "string"
          ? mapping[cursor].parent
          : null;
    }
    branchNodes.reverse();

    const branchMessages = [];
    let hiddenMessagesSkipped = 0;
    for (const node of branchNodes) {
      const message = node?.message;
      const role = String(message?.author?.role || message?.role || "");
      if (role !== "user" && role !== "assistant") continue;

      const recipient = String(message?.recipient || "all");
      const visuallyHidden =
        message?.metadata?.is_visually_hidden_from_conversation === true;
      if ((recipient && recipient !== "all") || visuallyHidden) {
        hiddenMessagesSkipped += 1;
        continue;
      }

      const content = messageText(message);
      if (!content) continue;
      branchMessages.push({
        role,
        id: String(message?.id || node?.id || ""),
        content,
        complete:
          role === "assistant" ? assistantComplete(message) : true,
      });
    }

    if (!branchMessages.length) {
      return {
        ok: false,
        reason: "current_branch_empty",
        session_reason: sessionReason,
      };
    }

    const recentMessages = [];
    let truncated = branchMessages.length > MAX_RECENT_MESSAGES;
    for (const item of branchMessages.slice(-MAX_RECENT_MESSAGES)) {
      const clipped = clip(item.content, MAX_MESSAGE_BYTES);
      if (!clipped.text) continue;
      truncated ||= clipped.truncated;
      recentMessages.push({
        role: item.role,
        id: item.id,
        content: clipped.text,
        complete:
          item.role === "assistant"
            ? item.complete !== false && !clipped.truncated
            : true,
      });
    }

    const encoder = new TextEncoder();
    while (
      recentMessages.length > 1 &&
      encoder.encode(JSON.stringify(recentMessages)).byteLength >
        MAX_TOTAL_BYTES
    ) {
      recentMessages.shift();
      truncated = true;
    }

    const last = recentMessages.at(-1);
    return {
      ok: recentMessages.length > 0,
      generationInProgress:
        last?.role === "assistant" && last?.complete === false,
      recentMessages,
      recentMessagesTruncated: truncated,
      tailWitness: witness(branchMessages.at(-1)),
      diagnostic: {
        source: "chatgpt_conversation_api",
        auth_mode: authMode,
        session_reason: sessionReason,
        current_node: currentNodeId,
        branch_messages: branchMessages.length,
        hidden_messages_skipped: hiddenMessagesSkipped,
        captured_messages: recentMessages.length,
        adapter: "mapping_current_node_v2",
      },
    };
  } catch (error) {
    return {
      ok: false,
      reason:
        "api_fetch_failed:" +
        String(error?.name || error?.message || "unknown"),
    };
  }
}

function collectCurrentConversationOnDemand() {
  const MAX_RECENT_MESSAGES = 14;
  const MAX_MESSAGE_BYTES = 8 * 1024;
  const MAX_TOTAL_BYTES = 56 * 1024;

  function clip(text, maxBytes) {
    const value = String(text || "").trim();
    if (!value) return { text: "", truncated: false };
    const encoder = new TextEncoder();
    if (encoder.encode(value).byteLength <= maxBytes) {
      return { text: value, truncated: false };
    }
    let low = 0;
    let high = value.length;
    while (low < high) {
      const mid = Math.ceil((low + high) / 2);
      if (encoder.encode(value.slice(0, mid)).byteLength <= maxBytes) {
        low = mid;
      } else {
        high = mid - 1;
      }
    }
    return { text: value.slice(0, low).trim(), truncated: true };
  }

  function textOf(node) {
    return String(node?.innerText || node?.textContent || "").trim();
  }

  function queryAll(selector) {
    try {
      return Array.from(document.querySelectorAll(selector) || []);
    } catch {
      return [];
    }
  }

  function first(node, selectors) {
    for (const selector of selectors) {
      try {
        if (node?.matches?.(selector)) return node;
        const found = node?.querySelector?.(selector);
        if (found) return found;
      } catch {}
    }
    return null;
  }

  function attr(node, name) {
    try {
      return String(node?.getAttribute?.(name) || "").trim();
    } catch {
      return "";
    }
  }

  function roleFromSearchKey(value) {
    const key = String(value || "").toLowerCase();
    if (!key) return "";
    if (/(?:^|[:/_-])user(?:$|[:/_-])/.test(key)) return "user";
    if (/(?:^|[:/_-])assistant(?:$|[:/_-])/.test(key)) return "assistant";
    return "";
  }

  function semanticRole(node) {
    const directTurn = attr(node, "data-turn").toLowerCase();
    if (directTurn === "user" || directTurn === "assistant") return directTurn;

    const directRole = attr(node, "data-message-author-role").toLowerCase();
    if (directRole === "user" || directRole === "assistant") return directRole;

    const explicit = first(node, [
      '[data-message-author-role="user"]',
      '[data-message-author-role="assistant"]',
    ]);
    const nestedRole = attr(explicit, "data-message-author-role").toLowerCase();
    if (nestedRole === "user" || nestedRole === "assistant") return nestedRole;

    const ownSearchRole = roleFromSearchKey(
      attr(node, "data-chatgpt-search-unit-key"),
    );
    if (ownSearchRole) return ownSearchRole;

    const searchUnit = first(node, ["[data-chatgpt-search-unit-key]"]);
    return roleFromSearchKey(attr(searchUnit, "data-chatgpt-search-unit-key"));
  }

  function contentNodeFor(turn, role) {
    if (role === "user") {
      return first(turn, [
        '[data-message-author-role="user"]',
        ".user-message-bubble-color",
        '[data-chatgpt-search-unit-key$=":user"]',
        '[data-chatgpt-search-unit-key*=":user:"]',
        "[data-message-id]",
      ]);
    }
    if (role === "assistant") {
      return first(turn, [
        '[data-message-author-role="assistant"]',
        '[data-markdown-text-style="assistant-message"]',
        ".markdown",
        '[class*="prose"]',
        '[data-chatgpt-search-unit-key$=":assistant"]',
        '[data-chatgpt-search-unit-key*=":assistant:"]',
        "[data-message-id]",
      ]);
    }
    return null;
  }

  function stableTurnId(node, role, index, content) {
    const contentNode = contentNodeFor(node, role);
    const direct =
      attr(contentNode, "data-message-id") ||
      attr(node, "data-turn-id") ||
      attr(node, "data-message-id") ||
      attr(node, "data-turn-key") ||
      attr(node, "data-chatgpt-search-message-ids") ||
      attr(node, "data-testid");
    if (direct) return direct.slice(0, 200);

    let hash = 2166136261;
    const value =
      role + "\n" + String(index) + "\n" + String(content || "");
    for (let i = 0; i < value.length; i += 1) {
      hash ^= value.charCodeAt(i);
      hash = Math.imul(hash, 16777619);
    }
    return (
      "local_" +
      role +
      "_" +
      index +
      "_" +
      (hash >>> 0).toString(36)
    ).slice(0, 200);
  }

  function witness(id, role, raw) {
    const normalized = String(raw || "")
      .replace(/[\u200B-\u200D\uFEFF]/g, "")
      .replace(/\s+/g, " ")
      .trim();
    return {
      id: String(id || ""),
      role: String(role || ""),
      length: normalized.length,
      head: normalized.slice(0, 256),
      tail: normalized.slice(-256),
    };
  }

  function generationInProgress() {
    return Boolean(
      document.querySelector(
        '[data-testid="stop-button"],button[aria-label*="Stop"],button[aria-label*="stop"],button[aria-label*="停止"],button[title*="Stop"],button[title*="stop"],button[title*="停止"]'
      )
    );
  }

  const isGenerating = generationInProgress();
  const testIdTurns = queryAll("[data-testid^='conversation-turn-']");
  const dataTurnShells = queryAll('[data-turn="user"],[data-turn="assistant"]');
  const turnKeyShells = queryAll("[data-turn-key]");
  const searchUnits = queryAll("[data-chatgpt-search-unit-key]");
  const explicitTurns = [
    ...queryAll('[data-message-author-role="user"]'),
    ...queryAll('[data-message-author-role="assistant"]'),
  ];

  let turnContainers = [];
  let domFamily = "none";
  if (testIdTurns.length) {
    turnContainers = testIdTurns;
    domFamily = "conversation_turn_testid";
  } else if (dataTurnShells.length) {
    turnContainers = dataTurnShells;
    domFamily = "data_turn";
  } else if (turnKeyShells.length) {
    turnContainers = turnKeyShells;
    domFamily = "turn_key";
  } else if (searchUnits.length) {
    turnContainers = searchUnits;
    domFamily = "search_unit";
  } else if (explicitTurns.length) {
    turnContainers = explicitTurns;
    domFamily = "message_role";
  }

  turnContainers = turnContainers.filter(
    (node, index, all) => node && all.indexOf(node) === index,
  );

  const messages = [];
  let tailWitness = null;
  let truncated = false;
  let unknownRoleTurns = 0;
  let emptySemanticTurns = 0;

  for (let index = 0; index < turnContainers.length; index += 1) {
    const turn = turnContainers[index];
    const role = semanticRole(turn);
    if (role !== "user" && role !== "assistant") {
      unknownRoleTurns += 1;
      continue;
    }

    const contentNode = contentNodeFor(turn, role);
    if (!contentNode) {
      emptySemanticTurns += 1;
      continue;
    }

    const raw = textOf(contentNode);
    if (!raw) {
      emptySemanticTurns += 1;
      continue;
    }

    const clipped = clip(raw, MAX_MESSAGE_BYTES);
    if (!clipped.text) continue;
    truncated ||= clipped.truncated;

    const messageId = stableTurnId(turn, role, index, clipped.text);
    messages.push({
      role,
      id: messageId,
      content: clipped.text,
      complete: role === "assistant" ? !clipped.truncated : true,
    });
    tailWitness = witness(messageId, role, raw);
  }

  if (isGenerating) {
    const lastAssistant = [...messages]
      .reverse()
      .find((item) => item.role === "assistant");
    if (lastAssistant) lastAssistant.complete = false;
  }

  let recentMessages = messages.slice(-MAX_RECENT_MESSAGES);
  truncated ||= messages.length > recentMessages.length;
  const encoder = new TextEncoder();
  while (
    recentMessages.length > 1 &&
    encoder.encode(JSON.stringify(recentMessages)).byteLength >
      MAX_TOTAL_BYTES
  ) {
    recentMessages.shift();
    truncated = true;
  }

  const hasUser = recentMessages.some((item) => item.role === "user");
  const reason = recentMessages.length
    ? hasUser
      ? ""
      : "dom_no_user_turn"
    : turnContainers.length
      ? "dom_no_semantic_content"
      : "dom_no_turns";

  return {
    ok: recentMessages.length > 0 && hasUser,
    reason,
    generationInProgress: isGenerating,
    recentMessages,
    recentMessagesTruncated: truncated,
    tailWitness,
    diagnostic: {
      source: "dom_click_witness",
      adapter: "semantic_turns_v2",
      dom_family: domFamily,
      turn_containers: turnContainers.length,
      unknown_role_turns: unknownRoleTurns,
      empty_semantic_turns: emptySemanticTurns,
      captured_messages: recentMessages.length,
      captured_users: recentMessages.filter((item) => item.role === "user").length,
      captured_assistants: recentMessages.filter(
        (item) => item.role === "assistant",
      ).length,
    },
  };
}
function verifyResumeTokenOnDemand(expectedToken) {
  const token = String(expectedToken || "").trim();
  if (!token) return false;

  const userNodes = Array.from(
    document.querySelectorAll('[data-message-author-role="user"]')
  );
  if (
    userNodes.some((node) =>
      String(node?.textContent || "").includes(token)
    )
  ) {
    return true;
  }

  const turns = Array.from(
    document.querySelectorAll("[data-testid^='conversation-turn-']")
  );
  for (const turn of turns) {
    const explicitUser = turn.querySelector?.(
      '[data-message-author-role="user"]'
    );
    if (explicitUser) {
      if (String(explicitUser.textContent || "").includes(token)) {
        return true;
      }
      continue;
    }
    if (String(turn?.textContent || "").includes(token)) return true;
  }
  return false;
}
