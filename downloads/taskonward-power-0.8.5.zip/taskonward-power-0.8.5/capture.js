// TaskOnward Power one-shot ChatGPT capture routines.
// Loaded by the MV3 service worker only to provide self-contained functions
// for chrome.scripting.executeScript. No listeners, timers, storage, or network
// run from this file unless one of these functions is explicitly injected by
// a Power action.

async function collectChatGPTConversationApiOnDemand(conversationId) {
  const id = String(conversationId || "").trim();
  if (!id) return { ok: false, reason: "conversation_id_missing" };

  const MAX_USER_BYTES = 10 * 1024;
  const MAX_ASSISTANT_BYTES = 24 * 1024;
  const MAX_PENDING_USERS = 6;
  const MAX_ASSISTANT_TAIL = 4;
  const MAX_RECENT_MESSAGES = 14;
  const MAX_RECENT_MESSAGE_BYTES = 8 * 1024;
  const MAX_RECENT_TOTAL_BYTES = 56 * 1024;

  function clip(text, maxBytes) {
    const value = String(text || "").trim();
    if (!value) return { text: "", truncated: false };
    const encoder = new TextEncoder();
    if (encoder.encode(value).byteLength <= maxBytes) {
      return { text: value, truncated: false };
    }
    let low = 0;
    let high = value.length;
    while (low < high) {
      const mid = Math.ceil((low + high) / 2);
      if (encoder.encode(value.slice(0, mid)).byteLength <= maxBytes) low = mid;
      else high = mid - 1;
    }
    return { text: value.slice(0, low).trim(), truncated: true };
  }

  function partText(value) {
    if (typeof value === "string") return value;
    if (!value || typeof value !== "object") return "";
    if (typeof value.text === "string") return value.text;
    if (typeof value.content === "string") return value.content;
    if (Array.isArray(value.parts)) return value.parts.map(partText).filter(Boolean).join("\n");
    if (Array.isArray(value.content)) return value.content.map(partText).filter(Boolean).join("\n");
    return "";
  }

  function messageText(message) {
    const parts = Array.isArray(message?.content?.parts)
      ? message.content.parts
      : [];
    return parts.map(partText).filter(Boolean).join("\n").trim();
  }

  function assistantComplete(message) {
    if (!message || typeof message !== "object") return false;
    if (message.end_turn === false) return false;
    const status = String(message.status || "").toLowerCase();
    if (
      status.includes("in_progress") ||
      status.includes("stream") ||
      status.includes("interrupted")
    ) {
      return false;
    }
    return true;
  }

  try {
    const sessionResponse = await fetch("/api/auth/session", {
      method: "GET",
      credentials: "include",
      cache: "no-store",
    });
    if (!sessionResponse.ok) {
      return { ok: false, reason: "session_http_" + sessionResponse.status };
    }
    const session = await sessionResponse.json();
    const accessToken = String(session?.accessToken || "");
    if (!accessToken) {
      return { ok: false, reason: "session_token_missing" };
    }

    const response = await fetch(
      "/backend-api/conversation/" + encodeURIComponent(id),
      {
        method: "GET",
        credentials: "include",
        cache: "no-store",
        headers: {
          Authorization: "Bearer " + accessToken,
        },
      }
    );
    if (!response.ok) {
      return { ok: false, reason: "conversation_http_" + response.status };
    }

    const data = await response.json();
    const mapping = data?.mapping && typeof data.mapping === "object"
      ? data.mapping
      : {};
    let currentNodeId =
      typeof data?.current_node === "string" && mapping[data.current_node]
        ? data.current_node
        : null;

    if (!currentNodeId) {
      const leaves = Object.entries(mapping).filter(([, node]) =>
        !Array.isArray(node?.children) || node.children.length === 0
      );
      if (leaves.length === 1) currentNodeId = leaves[0][0];
      else {
        return {
          ok: false,
          reason: leaves.length > 1
            ? "current_branch_ambiguous"
            : "current_node_missing",
        };
      }
    }

    const branchNodes = [];
    const seen = new Set();
    let cursor = currentNodeId;
    while (cursor && mapping[cursor] && !seen.has(cursor)) {
      seen.add(cursor);
      branchNodes.push(mapping[cursor]);
      cursor =
        typeof mapping[cursor]?.parent === "string"
          ? mapping[cursor].parent
          : null;
    }
    branchNodes.reverse();

    const messages = [];
    for (const node of branchNodes) {
      const message = node?.message;
      const role = String(message?.author?.role || "");
      if (role !== "user" && role !== "assistant") continue;
      const content = messageText(message);
      if (!content) continue;
      messages.push({
        role,
        id: String(message?.id || node?.id || ""),
        content,
        assistantComplete:
          role === "assistant" ? assistantComplete(message) : true,
      });
    }

    if (!messages.length) {
      return { ok: false, reason: "current_branch_empty" };
    }

    const recentMessages = [];
    let recentMessagesTruncated =
      messages.length > MAX_RECENT_MESSAGES;
    for (const item of messages.slice(-MAX_RECENT_MESSAGES)) {
      const clipped = clip(item.content, MAX_RECENT_MESSAGE_BYTES);
      if (!clipped.text) continue;
      recentMessagesTruncated ||= clipped.truncated;
      recentMessages.push({
        role: item.role,
        content: clipped.text,
        complete:
          item.role === "assistant"
            ? item.assistantComplete !== false && !clipped.truncated
            : true,
      });
    }
    const encoder = new TextEncoder();
    while (
      recentMessages.length > 1 &&
      encoder.encode(JSON.stringify(recentMessages)).byteLength >
        MAX_RECENT_TOTAL_BYTES
    ) {
      recentMessages.shift();
      recentMessagesTruncated = true;
    }

    const userMessages = messages.filter((item) => item.role === "user");
    const selectedUsers = [
      ...(userMessages.length ? [userMessages[0]] : []),
      ...userMessages.slice(-MAX_PENDING_USERS),
    ].filter((item, index, all) => all.indexOf(item) === index);

    const pendingItems = [];
    for (let index = 0; index < selectedUsers.length; index += 1) {
      const item = selectedUsers[index];
      const clipped = clip(item.content, MAX_USER_BYTES);
      if (!clipped.text) continue;
      pendingItems.push({
        turnId: (item.id || "api_user_" + index).slice(0, 200),
        content: clipped.text,
        truncated: clipped.truncated,
        capturedAt: Date.now(),
      });
    }

    const assistants = messages.filter((item) => item.role === "assistant");
    const tailAssistants = assistants.slice(-MAX_ASSISTANT_TAIL);
    const assistantTailParts = [];
    let assistantTailPartial = false;
    for (let index = 0; index < tailAssistants.length; index += 1) {
      const item = tailAssistants[index];
      assistantTailParts.push(
        "[assistant-turn-" + (index + 1) + "]\n" + item.content
      );
      if (item.assistantComplete === false) assistantTailPartial = true;
    }
    const assistantTailClip = clip(
      assistantTailParts.join("\n\n"),
      MAX_ASSISTANT_BYTES
    );

    let latestAssistantIndex = -1;
    for (let index = messages.length - 1; index >= 0; index -= 1) {
      if (messages[index].role === "assistant") {
        latestAssistantIndex = index;
        break;
      }
    }

    let latestRound = null;
    if (latestAssistantIndex >= 0) {
      const assistant = messages[latestAssistantIndex];
      let user = null;
      for (let index = latestAssistantIndex - 1; index >= 0; index -= 1) {
        if (messages[index].role === "user") {
          user = messages[index];
          break;
        }
      }
      const userClip = clip(user?.content || "", MAX_USER_BYTES);
      const assistantClip = clip(assistant.content, MAX_ASSISTANT_BYTES);
      if (assistantClip.text) {
        latestRound = {
          user: userClip.truncated ? "" : userClip.text,
          assistant: assistantClip.text,
          complete: true,
          assistant_complete:
            assistant.assistantComplete !== false &&
            !assistantClip.truncated,
        };
      }
    }

    const tokenMatches = new Set();
    for (const item of userMessages) {
      const match = item.content.match(
        /TaskOnward\s*续聊码\s*[:：]\s*([A-Za-z0-9_-]+)/i
      );
      if (match?.[1]) tokenMatches.add(match[1]);
    }

    return {
      ok: true,
      generationInProgress:
        latestRound?.assistant_complete === false,
      captureMode: "api_current_branch",
      boundary: {
        type: tokenMatches.size === 1 ? "taskonward_resume" : "none",
        found: tokenMatches.size === 1,
        scan_truncated: false,
      },
      canonicalMarker:
        tokenMatches.size === 1
          ? {
              token: Array.from(tokenMatches)[0],
              laneId: null,
              savedVersion: null,
            }
          : null,
      canonicalMarkerAmbiguous: tokenMatches.size > 1,
      pendingUser: {
        boundary: tokenMatches.size === 1 ? "taskonward_resume" : "none",
        items: pendingItems,
        overflowed: userMessages.length > selectedUsers.length,
        bootstrap_truncated: userMessages.length > selectedUsers.length,
        capture_mode: "api_current_branch",
      },
      assistantTail: assistantTailClip.text
        ? {
            content: assistantTailClip.text,
            message_count: tailAssistants.length,
            generation_in_progress:
              assistantTailPartial || assistantTailClip.truncated,
          }
        : null,
      latestRound,
      recentMessages,
      recentMessagesTruncated,
      emergencyRecentContext: null,
      latestDialogue: latestRound
        ? {
            user: latestRound.user,
            assistant: latestRound.assistant,
            assistant_complete:
              latestRound.assistant_complete !== false,
            user_truncated: false,
            assistant_truncated: false,
          }
        : {
            user: userMessages[userMessages.length - 1]?.content || "",
            assistant: "",
            assistant_complete: false,
            user_truncated: false,
            assistant_truncated: false,
          },
      diagnostic: {
        source: "chatgpt_conversation_api",
        branch_messages: messages.length,
        user_turns: userMessages.length,
        assistant_turns: assistants.length,
        pending_user_items: pendingItems.length,
        canonical_marker_ambiguous: tokenMatches.size > 1,
        latest_assistant_complete:
          latestRound?.assistant_complete !== false,
      },
    };
  } catch (error) {
    return {
      ok: false,
      reason:
        error && typeof error === "object" && "name" in error
          ? String(error.name || "api_fetch_failed")
          : "api_fetch_failed",
    };
  }
}

function collectCurrentConversationOnDemand() {
  const LIMITS = {
    pendingUserTurns: 50,
    bootstrapRecentUserTurns: 6,
    bootstrapSeedUserTurns: 1,
    assistantTailMessages: 4,
    userTurnBytes: 10 * 1024,
    pendingTotalBytes: 20 * 1024,
    assistantTailBytes: 24 * 1024,
    latestAssistantBytes: 24 * 1024,
    recentMessages: 14,
    recentMessageBytes: 8 * 1024,
    recentTotalBytes: 56 * 1024,
  };

  function utf8ClipLocal(text, maxBytes) {
    const value = String(text || "").trim();
    if (!value) return { text: "", truncated: false };
    const encoder = new TextEncoder();
    const bytes = encoder.encode(value).byteLength;
    if (bytes <= maxBytes) return { text: value, truncated: false };
    let low = 0;
    let high = value.length;
    while (low < high) {
      const mid = Math.ceil((low + high) / 2);
      if (encoder.encode(value.slice(0, mid)).byteLength <= maxBytes) low = mid;
      else high = mid - 1;
    }
    return { text: value.slice(0, low).trim(), truncated: true };
  }

  function textOf(node) {
    return String(node?.textContent || "").trim();
  }

  function canonicalTurn(node) {
    return node?.closest?.("[data-testid^='conversation-turn-']") || node || null;
  }

  function stableTurnId(node, role, index, content) {
    const explicit = node?.matches?.("[data-message-author-role]")
      ? node
      : node?.querySelector?.("[data-message-author-role]");
    const direct =
      explicit?.getAttribute?.("data-message-id") ||
      node?.getAttribute?.("data-message-id") ||
      canonicalTurn(node)?.getAttribute?.("data-testid") ||
      "";
    if (direct) return String(direct).slice(0, 200);

    let hash = 2166136261;
    const value = role + "\n" + String(index) + "\n" + String(content || "");
    for (let i = 0; i < value.length; i += 1) {
      hash ^= value.charCodeAt(i);
      hash = Math.imul(hash, 16777619);
    }
    return (
      "local_" +
      role +
      "_" +
      index +
      "_" +
      (hash >>> 0).toString(36)
    ).slice(0, 200);
  }

  function looksLikeLocalEmergency(value) {
    const text = String(value || "");
    if (/TaskOnward\s*临时恢复编号\s*[:：]\s*[A-Za-z0-9_-]+/i.test(text)) {
      return true;
    }
    return /\[memory-v5-local-emergency\]/.test(text) && (
      /\[memory-v5-emergency-id:[^\]]+\]/.test(text) ||
      /@EmergencyId\s+\S+/.test(text) ||
      /【本地未同步用户请求】/.test(text) ||
      /这是本地(?:应急续聊|续聊恢复)包/.test(text)
    );
  }

  function parseCanonicalMarker(value) {
    const text = String(value || "");
    const brandedToken =
      text.match(/TaskOnward\s*续聊码\s*[:：]\s*([A-Za-z0-9_-]+)/i)?.[1] || "";
    if (brandedToken) {
      return {
        token: brandedToken,
        laneId: null,
        savedVersion: null,
        format: "taskonward_resume",
      };
    }

    if (
      !/(?:只)?使用已连接的\s*(?:TaskOnward|Memory V5 Beta)/i.test(text) ||
      !/(?:精确恢复(?:并锁定)?原任务线|精确恢复此任务)/.test(text)
    ) {
      return null;
    }
    const token =
      text.match(/\[memory-v5-handoff:([A-Za-z0-9_-]+)\]/)?.[1] || "";
    const laneId =
      text.match(/\[memory-v5-lane:(lane_[A-Za-z0-9_-]+)\]/)?.[1] || "";
    const versionRaw =
      text.match(/\[memory-v5-version:(\d+)\]/)?.[1] || "";
    const savedVersion = Number(versionRaw);
    if (!token || !laneId || !Number.isSafeInteger(savedVersion) || savedVersion < 1) {
      return null;
    }
    return { token, laneId, savedVersion, format: "legacy_memory_v5" };
  }

  function generationInProgress() {
    return Boolean(
      document.querySelector(
        '[data-testid="stop-button"],button[aria-label*="Stop"],button[aria-label*="stop"],button[aria-label*="停止"],button[title*="Stop"],button[title*="stop"],button[title*="停止"]'
      )
    );
  }

  const isGenerating = generationInProgress();

  const turnContainers = Array.from(
    document.querySelectorAll("[data-testid^='conversation-turn-']")
  );
  const explicitUserTurns = Array.from(
    document.querySelectorAll('[data-message-author-role="user"]')
  );
  const explicitAssistantTurns = Array.from(
    document.querySelectorAll('[data-message-author-role="assistant"]')
  );

  // ChatGPT can remove role attributes while leaving both user and Assistant
  // turns inside markdown/prose containers. Do not use prose as a role signal.
  // Explicit roles win; missing roles are inferred by dialogue alternation from
  // the nearest explicit anchor, or from the normal final Assistant turn.
  let userTurns = explicitUserTurns;
  let assistantTurns = explicitAssistantTurns;
  if (turnContainers.length) {
    const explicitUserByContainer = new Map(
      explicitUserTurns.map((node) => [canonicalTurn(node), node])
    );
    const explicitAssistantByContainer = new Map(
      explicitAssistantTurns.map((node) => [canonicalTurn(node), node])
    );
    const explicitRoles = turnContainers.map((turn) => {
      if (
        explicitUserByContainer.has(turn) ||
        turn.querySelector?.('[data-message-author-role="user"]')
      ) {
        return "user";
      }
      if (
        explicitAssistantByContainer.has(turn) ||
        turn.querySelector?.('[data-message-author-role="assistant"]')
      ) {
        return "assistant";
      }
      return "";
    });

    const inferredRoles = [...explicitRoles];
    for (let index = 0; index < inferredRoles.length; index += 1) {
      if (inferredRoles[index]) continue;

      let anchor = -1;
      for (let distance = 1; distance < inferredRoles.length; distance += 1) {
        const left = index - distance;
        const right = index + distance;
        if (left >= 0 && explicitRoles[left]) {
          anchor = left;
          break;
        }
        if (right < explicitRoles.length && explicitRoles[right]) {
          anchor = right;
          break;
        }
      }

      if (anchor >= 0) {
        const sameParity = Math.abs(index - anchor) % 2 === 0;
        inferredRoles[index] = sameParity
          ? explicitRoles[anchor]
          : explicitRoles[anchor] === "user"
            ? "assistant"
            : "user";
      } else {
        const distanceFromEnd = inferredRoles.length - 1 - index;
        inferredRoles[index] =
          distanceFromEnd % 2 === 0 ? "assistant" : "user";
      }
    }

    const discoveredUsers = [];
    const discoveredAssistants = [];
    for (let index = 0; index < turnContainers.length; index += 1) {
      const turn = turnContainers[index];
      if (!textOf(turn)) continue;
      const role = inferredRoles[index];
      if (role === "user") {
        discoveredUsers.push(
          explicitUserByContainer.get(turn) ||
          turn.querySelector?.('[data-message-author-role="user"]') ||
          turn
        );
      } else if (role === "assistant") {
        discoveredAssistants.push(
          explicitAssistantByContainer.get(turn) ||
          turn.querySelector?.('[data-message-author-role="assistant"]') ||
          turn.querySelector?.(".markdown") ||
          turn.querySelector?.('[class*="prose"]') ||
          turn
        );
      }
    }

    if (discoveredUsers.length) userTurns = discoveredUsers;
    if (discoveredAssistants.length) assistantTurns = discoveredAssistants;
  }
  // Identity boundaries are scanned across every user turn currently
  // present in the DOM. This is one-shot work only after an explicit Power
  // action, so correctness is preferred over an arbitrary historical cap.
  const scanStart = 0;

  let boundaryIndex = -1;
  let boundaryType = "none";
  let boundaryNode = null;

  // Resume identity must not depend on role classification. ChatGPT may render
  // role-less user content with the same markdown/prose containers used by
  // Assistant messages. Scan every mounted conversation turn for the opaque
  // TaskOnward marker first; role classification is only for payload capture.
  const canonicalMarkers = [];
  const markerNodes = turnContainers.length ? turnContainers : userTurns;
  for (let index = markerNodes.length - 1; index >= 0; index -= 1) {
    const marker = parseCanonicalMarker(textOf(markerNodes[index]));
    if (marker) canonicalMarkers.push({ ...marker, index });
  }

  for (let index = userTurns.length - 1; index >= scanStart; index -= 1) {
    const text = textOf(userTurns[index]);
    const marker = parseCanonicalMarker(text);
    if (boundaryIndex >= 0) continue;

    if (marker) {
      boundaryIndex = index;
      boundaryType = marker.format === "taskonward_resume"
        ? "taskonward_resume"
        : "legacy_handoff";
      boundaryNode = userTurns[index];
    } else if (/\[memory-control:sync:[A-Za-z0-9_-]+\]/.test(text)) {
      boundaryIndex = index;
      boundaryType = "legacy_save";
      boundaryNode = userTurns[index];
    } else if (looksLikeLocalEmergency(text)) {
      boundaryIndex = index;
      boundaryType = "memory_v5_local_emergency";
      boundaryNode = userTurns[index];
    }
  }

  const markerKeys = new Set(
    canonicalMarkers.map((item) => item.token)
  );
  const canonicalMarker = markerKeys.size === 1 ? canonicalMarkers[0] : null;
  const canonicalMarkerAmbiguous = markerKeys.size > 1;
  if (canonicalMarkerAmbiguous) {
    boundaryIndex = -1;
    boundaryType = "ambiguous_resume";
    boundaryNode = null;
  }

  let captureMode = "post_boundary";
  let sourceUsers = [];
  let bootstrapTruncated = false;

  if (boundaryIndex >= 0) {
    sourceUsers = userTurns.slice(boundaryIndex + 1);
  } else {
    captureMode = "bootstrap_recent";
    const recentUsers = userTurns.slice(-LIMITS.bootstrapRecentUserTurns);
    const seedUsers = userTurns.slice(0, LIMITS.bootstrapSeedUserTurns);
    sourceUsers = [...seedUsers, ...recentUsers.filter((node) => !seedUsers.includes(node))];
    bootstrapTruncated = userTurns.length > sourceUsers.length;
  }

  const overflowedPostBoundary =
    captureMode === "post_boundary" &&
    sourceUsers.length > LIMITS.pendingUserTurns;
  const selectedUsers = overflowedPostBoundary
    ? sourceUsers.slice(-LIMITS.pendingUserTurns)
    : sourceUsers.slice(0, LIMITS.pendingUserTurns);

  const pendingItems = [];
  let pendingBudgetOverflow = false;
  let pendingTurnTruncated = false;
  for (let index = 0; index < selectedUsers.length; index += 1) {
    const node = selectedUsers[index];
    const raw = textOf(node);
    const clipped = utf8ClipLocal(raw, LIMITS.userTurnBytes);
    if (!clipped.text) continue;
    const absoluteIndex = userTurns.indexOf(node);
    pendingTurnTruncated ||= clipped.truncated;
    pendingItems.push({
      turnId: stableTurnId(node, "user", absoluteIndex, clipped.text),
      content: clipped.text,
      truncated: clipped.truncated,
      capturedAt: Date.now(),
    });
  }

  const encoder = new TextEncoder();
  while (
    pendingItems.length > 0 &&
    encoder.encode(JSON.stringify(pendingItems)).byteLength >
      LIMITS.pendingTotalBytes
  ) {
    pendingBudgetOverflow = true;
    pendingItems.shift();
  }

  let selectedAssistants = assistantTurns;
  if (boundaryNode) {
    selectedAssistants = assistantTurns.filter((node) =>
      Boolean(
        boundaryNode.compareDocumentPosition(node) &
          Node.DOCUMENT_POSITION_FOLLOWING
      )
    );
  }
  selectedAssistants = selectedAssistants.slice(
    -LIMITS.assistantTailMessages
  );

  const assistantMessages = [];
  for (const node of selectedAssistants) {
    const value = textOf(node);
    if (value) assistantMessages.push(value);
  }

  let assistantTail = null;
  if (assistantMessages.length) {
    const joined = assistantMessages
      .map(
        (text, index) =>
          "[assistant-turn-" + (index + 1) + "]\n" + text
      )
      .join("\n\n");
    const clipped = utf8ClipLocal(joined, LIMITS.assistantTailBytes);
    if (clipped.text) {
      assistantTail = {
        content: clipped.text,
        message_count: assistantMessages.length,
        generation_in_progress: generationInProgress(),
      };
    }
  }

  const latestUser =
    userTurns.length > 0 ? userTurns[userTurns.length - 1] : null;
  let latestAssistant = null;
  if (latestUser) {
    for (
      let index = assistantTurns.length - 1;
      index >= 0;
      index -= 1
    ) {
      if (
        latestUser.compareDocumentPosition(assistantTurns[index]) &
        Node.DOCUMENT_POSITION_FOLLOWING
      ) {
        latestAssistant = assistantTurns[index];
        break;
      }
    }
  }

  const latestUserClip = utf8ClipLocal(
    textOf(latestUser),
    LIMITS.userTurnBytes
  );
  const latestAssistantClip = utf8ClipLocal(
    textOf(latestAssistant),
    LIMITS.latestAssistantBytes
  );

  // Capture the final completed dialogue round independently from role
  // classification. ChatGPT can omit or reshape role attributes, and user
  // turns may contain markdown/prose containers. The final two mounted
  // conversation-turns are the authoritative click-time tail when the reply
  // is complete.
  let latestRound = null;
  const nonEmptyTurnContainers = turnContainers.filter((node) => textOf(node));
  if (nonEmptyTurnContainers.length >= 2) {
    const userNode =
      nonEmptyTurnContainers[nonEmptyTurnContainers.length - 2];
    const assistantNode =
      nonEmptyTurnContainers[nonEmptyTurnContainers.length - 1];
    const lastIsExplicitUser = Boolean(
      assistantNode.querySelector?.('[data-message-author-role="user"]')
    );
    const previousIsExplicitAssistant = Boolean(
      userNode.querySelector?.('[data-message-author-role="assistant"]')
    );
    if (!lastIsExplicitUser && !previousIsExplicitAssistant) {
      const roundUser = utf8ClipLocal(
        textOf(userNode),
        LIMITS.userTurnBytes
      );
      const roundAssistant = utf8ClipLocal(
        textOf(assistantNode),
        LIMITS.latestAssistantBytes
      );
      if (
        roundUser.text &&
        roundAssistant.text &&
        !roundUser.truncated &&
        !roundAssistant.truncated
      ) {
        latestRound = {
          user: roundUser.text,
          assistant: roundAssistant.text,
          complete: true,
          ...(isGenerating ? { assistant_complete: false } : {}),
        };
      }
    }
  }
  if (
    !latestRound &&
    latestAssistantClip.text &&
    !latestAssistantClip.truncated
  ) {
    latestRound = {
      user:
        latestUserClip.text && !latestUserClip.truncated
          ? latestUserClip.text
          : "",
      assistant: latestAssistantClip.text,
      complete: true,
      ...(isGenerating ? { assistant_complete: false } : {}),
    };
  }

  // Long ChatGPT answers can virtualize the immediately preceding user turn
  // while keeping the final Assistant turn mounted. Preserve the final reply
  // instead of failing merely because that user node is no longer mounted.
  if (!latestRound && nonEmptyTurnContainers.length >= 1) {
    const lastNode =
      nonEmptyTurnContainers[nonEmptyTurnContainers.length - 1];
    const explicitlyUser = Boolean(
      lastNode.querySelector?.('[data-message-author-role="user"]')
    );
    const assistantSignature =
      lastNode.querySelector?.('[data-message-author-role="assistant"]') ||
      lastNode.querySelector?.('.markdown') ||
      lastNode.querySelector?.('[class*="prose"]') ||
      null;
    if (!explicitlyUser) {
      // Current ChatGPT builds can remove both role attributes and the older
      // markdown/prose wrappers from the final Assistant turn. Once generation
      // is complete, the last non-empty conversation-turn is the click-time
      // final reply unless it is explicitly marked as a user turn.
      const assistantNode = assistantSignature || lastNode;
      const mountedAssistant = utf8ClipLocal(
        textOf(assistantNode),
        LIMITS.latestAssistantBytes
      );
      if (mountedAssistant.text && !mountedAssistant.truncated) {
        latestRound = {
          user: "",
          assistant: mountedAssistant.text,
          complete: true,
          ...(isGenerating ? { assistant_complete: false } : {}),
        };
      }
    }
  }

  const recentRoleNodes = [
    ...userTurns.map((node) => ({ role: "user", node })),
    ...assistantTurns.map((node) => ({ role: "assistant", node })),
  ].sort((left, right) => {
    if (left.node === right.node) return 0;
    const position = left.node.compareDocumentPosition(right.node);
    return position & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1;
  });

  const recentMessages = [];
  let recentMessagesTruncated =
    recentRoleNodes.length > LIMITS.recentMessages;
  for (const item of recentRoleNodes.slice(-LIMITS.recentMessages)) {
    const clipped = utf8ClipLocal(
      textOf(item.node),
      LIMITS.recentMessageBytes
    );
    if (!clipped.text) continue;
    recentMessagesTruncated ||= clipped.truncated;
    recentMessages.push({
      role: item.role,
      content: clipped.text,
      complete:
        item.role === "assistant"
          ? !isGenerating && !clipped.truncated
          : true,
    });
  }
  while (
    recentMessages.length > 1 &&
    encoder.encode(JSON.stringify(recentMessages)).byteLength >
      LIMITS.recentTotalBytes
  ) {
    recentMessages.shift();
    recentMessagesTruncated = true;
  }

  return {
    generationInProgress: isGenerating,
    captureMode,
    boundary: {
      type: boundaryType,
      found: boundaryIndex >= 0,
      scan_truncated: scanStart > 0 && boundaryIndex < 0,
    },
    canonicalMarker: canonicalMarker
      ? {
          token: canonicalMarker.token,
          laneId: canonicalMarker.laneId || null,
          savedVersion: Number.isSafeInteger(canonicalMarker.savedVersion)
            ? canonicalMarker.savedVersion
            : null,
        }
      : null,
    canonicalMarkerAmbiguous,
    pendingUser: {
      boundary: boundaryType,
      items: pendingItems,
      overflowed:
        overflowedPostBoundary ||
        bootstrapTruncated ||
        pendingBudgetOverflow ||
        pendingTurnTruncated,
      bootstrap_truncated: bootstrapTruncated,
      capture_mode: captureMode,
    },
    assistantTail,
    latestRound,
    recentMessages,
    recentMessagesTruncated,
    emergencyRecentContext: null,
    latestDialogue: {
      user: latestUserClip.text,
      assistant: latestAssistantClip.text,
      assistant_complete: Boolean(latestAssistant),
      user_truncated: latestUserClip.truncated,
      assistant_truncated: latestAssistantClip.truncated,
    },
    diagnostic: {
      user_turns: userTurns.length,
      assistant_turns: assistantTurns.length,
      boundary_scan_start: scanStart,
      pending_user_items: pendingItems.length,
      bootstrap_truncated: bootstrapTruncated,
      post_boundary_overflow:
        overflowedPostBoundary ||
        (captureMode === "post_boundary" &&
          (pendingBudgetOverflow || pendingTurnTruncated)),
      pending_budget_overflow: pendingBudgetOverflow,
      pending_turn_truncated: pendingTurnTruncated,
      canonical_marker_ambiguous: canonicalMarkerAmbiguous,
    },
  };
}

function verifyResumeTokenOnDemand(expectedToken) {
  const token = String(expectedToken || "").trim();
  if (!token) return false;
  const userNodes = Array.from(
    document.querySelectorAll('[data-message-author-role="user"]')
  );
  if (userNodes.some((node) =>
    String(node?.textContent || "").includes(token)
  )) {
    return true;
  }
  const turns = Array.from(
    document.querySelectorAll("[data-testid^='conversation-turn-']")
  );
  for (const turn of turns) {
    const explicitUser = turn.querySelector?.(
      '[data-message-author-role="user"]'
    );
    if (explicitUser) {
      if (String(explicitUser.textContent || "").includes(token)) return true;
      continue;
    }
    if (String(turn?.textContent || "").includes(token)) return true;
  }
  return false;
}
