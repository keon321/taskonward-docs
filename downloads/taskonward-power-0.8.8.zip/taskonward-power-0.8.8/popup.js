function publicPopupError() {
  return "TaskOnward 暂时无法完成这次操作，请重试。";
}

function runtime(message) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(message, (response) => {
      if (chrome.runtime.lastError) {
        resolve({ ok: false, error: publicPopupError() });
        return;
      }
      resolve(response ?? { ok: false, error: publicPopupError() });
    });
  });
}

const auth = document.getElementById("auth");
const detail = document.getElementById("detail");
const message = document.getElementById("message");
const continueCurrent = document.getElementById("continue");
const login = document.getElementById("login");
const logout = document.getElementById("logout");
const version = document.getElementById("version");

version.textContent = "v" + chrome.runtime.getManifest().version;

async function refresh() {
  const result = await runtime({ type: "POWER_AUTH_STATUS" });
  if (!result?.ok) {
    auth.textContent = "TaskOnward 不可用";
    detail.textContent = publicPopupError();
    continueCurrent.disabled = true;
    login.disabled = false;
    logout.disabled = true;
    return;
  }

  if (!result.data.configured) {
    auth.textContent = "TaskOnward 尚未配置";
    detail.textContent = "当前 Beta 配置不可用。";
    continueCurrent.disabled = true;
    login.disabled = true;
    logout.disabled = true;
    return;
  }

  if (result.data.authenticated) {
    auth.textContent = "已连接 TaskOnward";
    detail.textContent = "可以在 ChatGPT 中正常使用。";
    continueCurrent.disabled = false;
    login.disabled = true;
    logout.disabled = false;
  } else {
    auth.textContent = "尚未登录";
    detail.textContent = "首次使用只需登录一次。";
    continueCurrent.disabled = true;
    login.disabled = false;
    logout.disabled = true;
  }
}

continueCurrent.addEventListener("click", async () => {
  continueCurrent.disabled = true;
  message.textContent = "正在读取当前 Chat…";
  const result = await runtime({ type: "POWER_POPUP_ACTIVATE" });
  if (!result?.ok) {
    message.textContent = publicPopupError();
    continueCurrent.disabled = false;
    return;
  }
  const data = result.data || {};
  message.textContent =
    data.toast ||
    data.title ||
    data.detail ||
    data.label ||
    (data.handoffCopied ? "续聊内容已复制。" : "TaskOnward 已处理当前 Chat。");
  continueCurrent.disabled = false;
});

login.addEventListener("click", async () => {
  login.disabled = true;
  message.textContent = "正在打开登录…";
  const result = await runtime({ type: "POWER_AUTH_LOGIN" });
  message.textContent = result?.ok
    ? "登录完成。"
    : publicPopupError();
  await refresh();
});

logout.addEventListener("click", async () => {
  logout.disabled = true;
  const result = await runtime({ type: "POWER_AUTH_LOGOUT" });
  message.textContent = result?.ok ? "已退出。" : publicPopupError();
  await refresh();
});

refresh().catch(() => {
  auth.textContent = "TaskOnward 不可用";
  detail.textContent = "状态读取失败。";
});
